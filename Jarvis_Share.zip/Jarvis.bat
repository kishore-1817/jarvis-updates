@echo off
setlocal
cd /d "%~dp0"
set "VENV=%~dp0.venv"
set "VPYW=%VENV%\Scripts\pythonw.exe"

if exist "%VPYW%" goto launch

echo ============================================
echo   Jarvis - first-time setup (one time only)
echo ============================================

py -3.11 -m venv "%VENV%" >nul 2>nul
if exist "%VPYW%" goto launch

python --version 2>&1 | findstr /b /c:"Python 3.11" >nul
if not errorlevel 1 python -m venv "%VENV%"
if exist "%VPYW%" goto launch

echo Python 3.11 not found. Installing it automatically (needs internet)...
winget install -e --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
    "%LocalAppData%\Programs\Python\Python311\python.exe" -m venv "%VENV%"
)
if exist "%VPYW%" goto launch

echo.
echo Could not set up Python automatically.
echo Install Python 3.11.9 from python.org (tick "Add python.exe to PATH"),
echo then double-click Jarvis.bat again.
pause
exit /b 1

:launch
start "" "%VPYW%" "%~dp0jarvis_app.py" %*
exit /b 0
