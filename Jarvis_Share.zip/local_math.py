"""
local_math.py -- arithmetic Jarvis can answer without any network call.

Extracted out of jarvis_up.py so the screen_vision package can reuse it
too (a circular import would result from importing it back from
jarvis_up.py, since jarvis_up.py is what imports screen_vision in the
first place).

Two entry points:
    try_math_command(t)     -- t is WORD-form ("14 plus 4"), the shape
                                voice commands arrive in after speech
                                recognition.
    try_math_from_symbols(t) -- t is SYMBOL-form ("14 + 4"), the shape
                                text extracted from a screenshot via
                                OCR actually looks like. Normalizes
                                symbols to words, then calls
                                try_math_command().
"""

import math
import operator
import re

_MATH_OPS = {
    "plus": operator.add,
    "added to": operator.add,
    "add": operator.add,
    "minus": operator.sub,
    "subtracted by": operator.sub,
    "subtract": operator.sub,
    "multiplied by": operator.mul,
    "times": operator.mul,
    "mul": operator.mul,
    "divided by": operator.truediv,
    "div": operator.truediv,
    "over": operator.truediv,
}
# Longest phrases first so alternation doesn't match "add" inside
# "added to" and leave a stray "ed to" unconsumed.
_MATH_OP_PATTERN = "|".join(re.escape(w) for w in sorted(_MATH_OPS, key=len, reverse=True))
_NUM = r"-?\d+(?:\.\d+)?"
_MATH_EXPR_RE = re.compile(
    r"^(?:what(?:'s| is) )?(" + _NUM + r")\s+(" + _MATH_OP_PATTERN + r")\s+(" + _NUM + r")\??$"
)
_SQRT_RE = re.compile(
    r"^(?:what(?:'s| is) )?(?:the )?(?:square root of|sqrt of) (" + _NUM + r")\??$"
)

# OCR reads the literal symbol on screen ("14 + 4"), not the spoken
# word -- this maps the common ones to the word-form _MATH_EXPR_RE
# above expects, so screen-read math reuses the exact same evaluator
# as voice math instead of a second implementation.
_SYMBOL_TO_WORD = {
    "+": "plus",
    "-": "minus",
    "−": "minus",   # unicode minus, shows up in some fonts/renders
    "x": "times",
    "×": "times",
    "*": "times",
    "/": "divided by",
    "÷": "divided by",
}
_SYMBOL_EXPR_RE = re.compile(
    r"^\s*(" + _NUM + r")\s*([+\-−x×*/÷])\s*(" + _NUM + r")\s*=?\s*\??\s*$"
)


def _fmt_num(n: float) -> str:
    """Speaks whole numbers as ints ('4', not '4.0') and otherwise
    rounds to 4 decimal places to keep long floats from being read
    aloud digit by digit."""
    if n == int(n):
        return str(int(n))
    return str(round(n, 4))


def try_math_command(t: str):
    """Returns a spoken-friendly answer string if t is word-form
    arithmetic ('14 plus 4', 'square root of 9') Jarvis can compute
    locally, or None if it isn't -- in which case the caller falls
    through to the LLM as before."""
    sqrt_match = _SQRT_RE.match(t)
    if sqrt_match:
        n = float(sqrt_match.group(1))
        if n < 0:
            return "I can't take the square root of a negative number."
        return f"The square root of {_fmt_num(n)} is {_fmt_num(math.sqrt(n))}."

    expr_match = _MATH_EXPR_RE.match(t)
    if expr_match:
        a_str, op_word, b_str = expr_match.groups()
        a, b = float(a_str), float(b_str)
        op_func = _MATH_OPS[op_word]
        if op_func is operator.truediv and b == 0:
            return "I can't divide by zero."
        return f"That's {_fmt_num(op_func(a, b))}."

    return None


def try_math_from_symbols(t: str):
    """Same as try_math_command(), but for SYMBOL-form text ('14 + 4',
    the shape OCR actually produces reading a screen) instead of
    word-form. Returns None if t doesn't look like simple arithmetic,
    same contract as try_math_command()."""
    match = _SYMBOL_EXPR_RE.match(t.strip())
    if not match:
        return None

    a_str, symbol, b_str = match.groups()
    word = _SYMBOL_TO_WORD.get(symbol)
    if word is None:
        return None

    return try_math_command(f"{a_str} {word} {b_str}")
