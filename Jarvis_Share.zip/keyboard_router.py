"""
Keyboard domain router -- owns "type <text>", common key shortcuts,
and resolves stored personal preferences before typing.
"""

from keyboard_control import type_text, press_keys
import memory

_QUICK_KEY_PHRASES = {
    "copy that": "ctrl c", "copy": "ctrl c",
    "paste that": "ctrl v", "paste": "ctrl v",
    "select all": "ctrl a",
    "undo that": "ctrl z", "undo": "ctrl z",
    "redo that": "ctrl y", "redo": "ctrl y",
    "switch window": "alt tab", "switch app": "alt tab", "switch apps": "alt tab",
    "press enter": "enter", "hit enter": "enter",
    "press escape": "esc", "press escape key": "esc",
}

_TYPE_META_PHRASES = (
    "it", "it again", "that", "that again", "this", "this again",
    "again", "the code", "the code again", "it once more",
)


def _resolve_text_to_type(raw_text: str):
    cleaned = raw_text.strip().lower().rstrip(".,!?")

    if cleaned in ("my email", "my email id", "my email address", "my mail id", "my personal mail id", "my personal email","my mail lady","my mail address","my email, lady","my melee address"):
        val = (memory.get_preference("personal mail id") or 
               memory.get_preference("email") or 
               memory.get_preference("personal email"))
        if val:
            return val, "your email address"

    if cleaned in ("my college email", "my college email id", "my college email address", "my college mail", "my college mail id", "my college mail address"):
        val = (memory.get_preference("college email") or 
               memory.get_preference("college email address") or 
               memory.get_preference("college mail id") or 
               memory.get_preference("college mail"))
        if val:
            return val, "your college email address"

    if cleaned in ("my mobile number", "my phone number", "my mobile", "my phone", "my number"):
        val = (memory.get_preference("mobile number") or 
               memory.get_preference("phone"))
        if val:
            return val, "your mobile number"

    if cleaned in ("my name", "my full name"):
        val = memory.get_preference("name")
        if val:
            return val, "your name"
        
    if cleaned in ("my address", "my home address", "my current address", "my residential address"):
        val = (memory.get_preference("home address") or 
               memory.get_preference("address") or 
               memory.get_preference("current address"))
        if val:
            return val, "your address"

    if cleaned.startswith("my "):
        key = cleaned[3:].strip()
        val = (memory.get_preference(key) or 
               memory.get_preference(key.replace("mail", "email")) or
               memory.get_preference(key.replace("email", "mail")) or
               memory.get_preference(key.replace(" id", "").replace(" address", "")))
        if val:
            return val, f"your {key}"

    return raw_text, None


def handle(t: str) -> str | None:
    if t.startswith("type "):
        text_to_type = t[len("type "):].strip()
        if not text_to_type:
            return "Type what?"

        if text_to_type in _TYPE_META_PHRASES:
            return None

        resolved_val, spoken_label = _resolve_text_to_type(text_to_type)
        if spoken_label:
            type_text(resolved_val)
            return f"I've typed {spoken_label} for you."
        return type_text(resolved_val)

    if t in _QUICK_KEY_PHRASES:
        return press_keys(_QUICK_KEY_PHRASES[t])

    if t.startswith("press "):
        keys_spoken = t[len("press "):].strip()
        if not keys_spoken:
            return "Press what?"
        return press_keys(keys_spoken)

    return None