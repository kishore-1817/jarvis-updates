"""
solver.py -- fast, honest problem solver for Jarvis (math / aptitude / puzzles / MCQ).

Why this file exists (from jarvis.log, 2026-11-14):
  * 504 DEADLINE_EXCEEDED x3, each wait ~40 s, retried in a ladder -> 71 s and 159 s.
  * flash-lite wrote its whole chain of thought as visible text, then guessed and
    said "CONFIDENCE: high". The guess was spoken as the answer.
  * Hotkey and voice command solved at the same time (no lock).

What this does differently:
  1. HARD total deadline (default 25 s, 40 s for seating/puzzle questions).
     No retry ladder: a failed call moves on, it never restarts the wait.
  2. Reasoning goes in the model's THINKING, not in the visible reply. The reply is
     capped to 3 short lines, so output is fast and cannot leak chain-of-thought.
  3. Hedging: if the main model has not answered after HEDGE_AFTER seconds, the backup
     model starts in parallel; first TRUSTED answer wins.
  4. Trust checks: an answer is rejected if it leaks reasoning ("wait,", "let's trust"),
     is not one of the options on screen, or has no ANSWER line. The model's own
     "CONFIDENCE: high" is NOT trusted for flash-lite.
  5. Screenshot downscaled to 1280 px wide before upload (smaller = faster).
  6. One solve at a time. A second request gets an instant "still working" reply.
  7. Honest failure: returns a clear message instead of a made-up answer.

Used from llm_brain.py:   import solver
    result = solver.solve(client, problem, from_screen, is_available=_is_available,
                          on_model_error=_note_model_error)
"""

import io
import re
import time
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

from google.genai import types

logger = logging.getLogger("jarvis")

# ---------------------------------------------------------------- settings
MAIN_MODEL = "gemini-3.5-flash"        # slow (15-18 s) but reasons well
FAST_MODEL = "gemini-3.5-flash-lite"   # ~2-3 s, fine for simple questions
BACKUP_MODEL = FAST_MODEL

DEADLINE_NORMAL = 25.0      # seconds, whole solve, maths / aptitude / MCQ
DEADLINE_PUZZLE = 40.0      # seconds, seating / ordering puzzles need real thinking
HEDGE_AFTER = 5.0           # start the 2nd model if the 1st has not answered by then
MAX_IMAGE_WIDTH = 1280
MAX_OUTPUT_TOKENS = 8192    # thinking tokens count toward this, so keep it high

CODING = "__CODING_QUESTION__"   # sentinel: caller should hand over to the code solver
BUSY_MSG = "I'm still working on the last question."
FAIL_MSG = "I couldn't solve that in time. Please try again."

_lock = threading.Lock()
_last = None  # (finished_at, key, result)

PUZZLE_WORDS = re.compile(
    r"\b(sits?|sitting|seated|seating|row|rows|facing|faces|opposite|neighbou?rs?|"
    r"floor|flat|circular|arrange\w*|rank|ranking|blood relation|direction|"
    r"puzzle|immediate (left|right)|between)\b", re.I)

PROMPT = (
    "You are an exact solver for aptitude, maths, pseudocode-output and logical-reasoning "
    "questions. Do ALL your working inside your private thinking. Check your result "
    "against every given constraint and against the options before answering.\n"
    "Rules: use ONLY the options that appear in the question; never invent options; "
    "never change a number, operator or word to make an option fit.\n"
    "VISIBLE REPLY FORMAT -- exactly these 4 lines, nothing else, no reasoning, "
    "no 'wait', no 'let me check', do NOT retype the question:\n"
    "OPTIONS: <only the answer options as shown, one line; or 'none shown' if the "
    "question has no options visible>\n"
    "ANSWER: <option letter/number and its text; if no options are shown, just the "
    "computed value; if options are shown but none matches: 'none of the options, my "
    "result is <value>'>\n"
    "CONFIDENCE: high or low  (low if any constraint is unverified or you guessed)\n"
    "KIND: puzzle if it is a seating/arrangement/ranking/blood-relation/direction "
    "puzzle with many linked clues, otherwise simple\n"
    "Special cases: if there is no question on screen reply only 'ANSWER: no question "
    "visible'. If the screen asks you to WRITE a program/function (not predict an "
    "output), reply only 'ANSWER: coding question'."
)

SCREEN_INSTRUCTION = (
    "Solve the question shown in this screenshot. Ignore everything else on screen "
    "(browser tabs, code editors, assistant windows)."
)

LEAK = re.compile(
    r"(\bwait[,.]|let'?s trust|let me (re)?check|let'?s (re)?check|hmm|actually,|"
    r"standard result|i('ll| will) guess)", re.I)


# ---------------------------------------------------------------- helpers
def grab_screen_part(max_width: int = MAX_IMAGE_WIDTH):
    """Screenshot of the primary monitor, downscaled, as a Gemini image part."""
    try:
        from PIL import ImageGrab, Image
        img = ImageGrab.grab().convert("RGB")
        if img.width > max_width:
            h = int(img.height * max_width / img.width)
            img = img.resize((max_width, h), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=80)
        data = buf.getvalue()
        logger.info(f"SOLVER screenshot {img.width}x{img.height} {len(data) // 1024} KB")
        return types.Part.from_bytes(data=data, mime_type="image/jpeg")
    except Exception as e:
        logger.warning(f"Screen capture for solver failed: {e!r}")
        return None


def _config(level: str, timeout_s: float):
    kwargs = dict(
        system_instruction=PROMPT,
        thinking_config=types.ThinkingConfig(thinking_level=level),
        max_output_tokens=MAX_OUTPUT_TOKENS,
    )
    http = {}
    try:
        http["timeout"] = int(max(timeout_s, 3.0) * 1000)
    except Exception:
        pass
    try:  # no hidden SDK retries: one attempt, then WE decide what to do
        http["retry_options"] = types.HttpRetryOptions(attempts=1)
    except Exception:
        pass
    if http:
        try:
            kwargs["http_options"] = types.HttpOptions(**http)
        except Exception:
            try:
                kwargs["http_options"] = types.HttpOptions(timeout=http.get("timeout"))
            except Exception:
                pass
    return types.GenerateContentConfig(**kwargs)


def _call(client, model, contents, level, timeout_s):
    """One single attempt. Returns reply text. Raises on error."""
    t0 = time.monotonic()
    resp = client.models.generate_content(
        model=model, contents=contents, config=_config(level, timeout_s))
    out = (resp.text or "").strip()
    logger.info(f"SOLVER_CALL model={model} level={level} took={time.monotonic() - t0:.1f}s")
    return out


def _parse(out: str):
    """-> (read_line, answer, confidence) or None if there is no ANSWER line."""
    ans = re.findall(r"ANSWER:\s*(.+)", out, flags=re.I)
    if not ans:
        return None
    read = re.findall(r"OPTIONS:\s*(.+)", out, flags=re.I)
    conf = re.findall(r"CONFIDENCE:\s*(high|low)", out, flags=re.I)
    return (read[0].strip() if read else ""), ans[-1].strip(), (conf[-1].lower() if conf else "low")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9.]+", " ", s.lower()).strip()


def _in_question(answer: str, read_line: str, problem: str) -> bool:
    """The chosen option must really appear in the question text. Catches invented options."""
    a = _norm(re.sub(r"^\(?[A-Ea-e1-5][).:]\s*", "", answer))   # drop a leading "B)" / "3."
    if not a:
        return False
    hay = _norm(read_line + " " + problem)
    return a in hay


def _trusted(out: str, model: str, problem: str, need_high: bool, final: bool):
    """-> (answer or None, reason). None = do not use this reply.
    final=True on the high-thinking pass: then even 'none of the options' is accepted."""
    if LEAK.search(out):
        return None, "reasoning leaked into reply"
    parsed = _parse(out)
    if not parsed:
        return None, "no ANSWER line"
    options, ans, conf = parsed
    low = ans.lower()
    if "no question visible" in low or "coding question" in low:
        return ans, "special"
    has_options = bool(options) and "none shown" not in options.lower() and len(options) > 2
    kind = re.findall(r"KIND:\s*(simple|puzzle)", out, flags=re.I)
    if model == FAST_MODEL and ((kind and kind[-1].lower() == "puzzle") or conf != "high"):
        return None, "fast model is not trusted on puzzles / when unsure"
    if need_high and conf != "high":
        return None, "model not confident"
    if "none of the options" in low:
        if has_options and not final:
            return None, "matched no option (will re-check at high thinking)"
        return ans, "ok"
    if has_options and not _in_question(ans, options, problem):
        return None, "answer is not one of the options shown"
    return ans, "ok"


def _looks_like_coding(text: str) -> bool:
    return bool(re.search(
        r"(class Solution|public static void main|def \w+\(|#include|"
        r"write (a )?(program|function|code)|leetcode|return the|time complexity)",
        text, re.I))


# ---------------------------------------------------------------- main entry
def solve(client, problem: str = "", from_screen: bool = False,
          is_available=None, on_model_error=None) -> str:
    """Returns the spoken reply. Never raises. Never takes longer than the deadline
    (plus a second or two of thread cleanup)."""
    global _last
    problem = (problem or "").strip()
    key = (bool(from_screen), problem)

    if _last and _last[1] == key and time.monotonic() - _last[0] < 15:
        logger.info("SOLVER reused answer from a few seconds ago")
        return _last[2]

    if not _lock.acquire(blocking=False):
        logger.info("SOLVER busy -> rejected second request")
        return BUSY_MSG
    try:
        return _solve_locked(client, problem, from_screen, key, is_available, on_model_error)
    except Exception as e:
        logger.error(f"Solver crashed: {e!r}", exc_info=True)
        return FAIL_MSG
    finally:
        _lock.release()


def _solve_locked(client, problem, from_screen, key, is_available, on_model_error):
    global _last
    t_start = time.monotonic()

    if from_screen:
        shot = grab_screen_part()
        if shot is not None:
            contents = [shot, SCREEN_INSTRUCTION]
        elif problem:
            contents = problem
        else:
            return "I couldn't capture the screen."
    elif problem:
        contents = problem
    else:
        return "I didn't get the question. Could you repeat it?"

    is_puzzle = bool(PUZZLE_WORDS.search(problem)) or from_screen
    # on-screen questions: we cannot know the type in advance, so start at "low" and
    # escalate; spoken puzzles go straight to "high" (low-thinking guesses puzzles).
    spoken_puzzle = (not from_screen) and bool(PUZZLE_WORDS.search(problem))
    level = "high" if spoken_puzzle else "low"
    deadline = t_start + (DEADLINE_PUZZLE if is_puzzle else DEADLINE_NORMAL)

    models = [m for m in (MAIN_MODEL, BACKUP_MODEL)
              if (is_available is None or is_available(m))]
    if not models:
        return "My solver models are unavailable right now."

    pool = ThreadPoolExecutor(max_workers=4)
    try:
        result = None
        escalated = level == "high"
        while result is None:
            remaining = deadline - time.monotonic()
            if remaining < 3:
                break
            ordered = sorted(models, key=lambda m: (m != FAST_MODEL) if level == "low"
                             else (m != MAIN_MODEL))
            result, escalate = _race(pool, client, ordered, contents, level, problem,
                                     remaining, need_high=(level == "low"),
                                     on_model_error=on_model_error)
            if result is None and level == "low" and not escalated and escalate:
                logger.info("SOLVER low pass not trusted -> high pass")
                level, escalated = "high", True
                continue
            break
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    total = time.monotonic() - t_start
    if result is None:
        logger.error(f"Solver gave up after {total:.1f}s")
        return FAIL_MSG

    logger.info(f"SOLVER done in {total:.1f}s level={level} answer={result!r}")
    if "no question visible" in result.lower():
        return "I don't see a question on your screen."
    if "coding question" in result.lower():
        return CODING
    if result.lower().startswith("none of the options"):
        spoken = result[0].upper() + result[1:]
    else:
        spoken = f"The answer is {result}"
    _last = (time.monotonic(), key, spoken)
    return spoken


def _race(pool, client, models, contents, level, problem, budget, need_high, on_model_error):
    final = (level == "high")
    """Run main model; hedge with backup after HEDGE_AFTER s. First trusted reply wins.
    -> (answer or None, worth_escalating)"""
    end = time.monotonic() + budget
    futures = {}
    started = []

    def start(model):
        started.append(model)
        futures[pool.submit(_call, client, model, contents, level,
                            max(end - time.monotonic(), 3.0))] = model

    start(models[0])
    hedge_at = time.monotonic() + HEDGE_AFTER
    saw_untrusted = False

    while futures and time.monotonic() < end:
        # start the backup when main is slow OR main already failed
        if len(started) < len(models) and (time.monotonic() >= hedge_at or not futures):
            start(models[len(started)])
        timeout = min(end - time.monotonic(),
                      max(hedge_at - time.monotonic(), 0.1) if len(started) < len(models) else 60)
        done, _ = wait(list(futures), timeout=max(timeout, 0.1), return_when=FIRST_COMPLETED)
        for f in done:
            model = futures.pop(f)
            try:
                out = f.result()
            except Exception as e:
                logger.warning(f"Solver failed on {model} (level={level}): {e!r}")
                if on_model_error:
                    try:
                        on_model_error(model, e)
                    except Exception:
                        pass
                if len(started) < len(models):
                    start(models[len(started)])     # main failed -> backup NOW, no waiting
                continue
            if not out:
                continue
            logger.info(f"SOLVER model={model} level={level}\n{out}")
            ans, why = _trusted(out, model, problem, need_high, final)
            if ans:
                return ans, False
            logger.info(f"SOLVER rejected {model} reply: {why}")
            saw_untrusted = True
    return None, saw_untrusted
