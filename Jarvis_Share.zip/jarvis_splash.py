"""
jarvis_splash.py -- tiny "Jarvis is starting" animation
=========================================================
Start_Jarvis_Silent.vbs launches this right before jarvis_up.py, so you get
instant feedback even though Jarvis itself runs hidden (pythonw).

It is a separate process: tkinter only, no extra packages, and it can never
slow down or break Jarvis. Same look as the HUD orb: a dark capsule with a
glowing orb and orbiting arcs. It shows "Starting...", then turns green with a
check mark ("Ready") and fades away.

POSITION
--------
By default it always appears at Jarvis' DEFAULT starting position (top-right,
the margins set in hud.py: HUD_MARGIN_RIGHT / HUD_MARGIN_TOP), and its orb sits
exactly where the HUD orb appears, so the hand-over from splash to HUD is
seamless. It never goes off-screen. Set FOLLOW_HUD_POSITION = True below if you
want it to appear wherever you last dragged the HUD instead.

HOW IT KNOWS JARVIS IS READY
----------------------------
jarvis_up.py calls signal_ready() once startup is finished (see README below).
That just creates a tiny file, jarvis_ready.flag, which the splash watches.
If nothing ever signals, the splash fades out by itself after MAX_SECONDS.

PERCENTAGE / PROGRESS BAR
-------------------------
The splash shows a progress bar and a live percentage. Without any extra work
it shows an estimated percentage that climbs smoothly (up to SIM_CAP) and
jumps to 100% when Jarvis signals ready. For a more honest number, call
signal_progress(pct) from jarvis_up.py at real milestones, e.g.:

    from jarvis_splash import signal_progress
    signal_progress(55)      # after Whisper loaded

    # in jarvis_up.py, right where Jarvis becomes ready for use:
    try:
        from jarvis_splash import signal_ready
        signal_ready()
    except Exception:
        pass
"""

import ctypes
import json
import math
import os
import re
import time

HERE = os.path.dirname(os.path.abspath(__file__))
READY_FLAG = os.path.join(HERE, "jarvis_ready.flag")
HUD_POS_FILE = os.path.join(HERE, "hud_position.json")
HUD_FILE = os.path.join(HERE, "hud.py")
PROGRESS_FILE = os.path.join(HERE, "jarvis_progress.json")

# ---------------------------------------------------------------- tunables
MAX_SECONDS = 30.0           # safety net: fade out even if Jarvis never signals
MIN_SHOW_SECONDS = 1.2       # never flash by faster than this
READY_HOLD_SECONDS = 0.8     # how long "Ready" stays before fading
FADE_IN_SECONDS = 0.25
FADE_OUT_SECONDS = 0.35
OPACITY = 0.95
FOLLOW_HUD_POSITION = False  # False: always the default start position (top-right)
                             # True: appear where you last dragged the HUD
SPLASH_HC_DP = 24.0          # half-height of the splash capsule, dp
FPS = 30
SIM_CAP = 85.0               # estimated % never goes past this until Jarvis is ready
SIM_TAU = 8.0                # seconds; bigger = estimate climbs more slowly

COLOR_LOADING = "#a78bfa"    # same purple as the HUD's THINKING state
COLOR_READY = "#4ade80"      # same green as the HUD's SUCCESS state
PANEL_BG = "#0b1220"
TEXT_COLOR = "#e5edf7"
FONT_FAMILY = "Segoe UI"
KEY = "#010203"              # becomes transparent; never used for drawing
WHITE = "#ffffff"

N_HALO = 7
HALO_R = tuple(0.99 - 0.49 * k / (N_HALO - 1) for k in range(N_HALO))
ARC_R, ARC_EXT, ARC_W = (0.92, 0.78, 0.64), (85, 60, 45), (2.2, 1.7, 1.3)
CORE = ((0.40, 0.0, 0.0), (0.30, -0.03, -0.04), (0.18, -0.06, -0.08))
SPEC = (0.065, -0.12, -0.14)


def signal_ready():
    """Tell the splash that Jarvis is up. Cheap, never raises, no tkinter."""
    try:
        with open(READY_FLAG, "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def signal_progress(pct):
    """Optional: report real startup progress (0-100). Cheap, never raises."""
    try:
        tmp = PROGRESS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"pct": float(pct), "ts": time.time()}, f)
        os.replace(tmp, PROGRESS_FILE)
    except Exception:
        pass


# ---------------------------------------------------------------- helpers
def _clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else hi if v > hi else v


def _ease(f):
    f = _clamp(f)
    return f * f * (3 - 2 * f)


def _rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _mix(a, b, f):
    (r1, g1, b1), (r2, g2, b2) = _rgb(a), _rgb(b)
    out = "#%02x%02x%02x" % (int(r1 + (r2 - r1) * f), int(g1 + (g2 - g1) * f),
                             int(b1 + (b2 - b1) * f))
    return "#020304" if out == KEY else out


def _dpi_aware():
    """Crisp drawing on high-DPI screens (this process only, not Jarvis)."""
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def _scale():
    try:
        return min(4.0, max(1.0, ctypes.windll.user32.GetDpiForSystem() / 96.0))
    except Exception:
        return 1.0


def _screen_width(root):
    try:
        w = ctypes.windll.user32.GetSystemMetrics(0)
        if w > 0:
            return w
    except Exception:
        pass
    return root.winfo_screenwidth()


def _screen_height(root):
    try:
        h = ctypes.windll.user32.GetSystemMetrics(1)
        if h > 0:
            return h
    except Exception:
        pass
    return root.winfo_screenheight()


def _work_right(root, fallback):
    """Right edge of the usable screen area (what the HUD orb uses too)."""
    try:
        from ctypes import wintypes
        r = wintypes.RECT()
        if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0) and r.right > fallback * 0.5:
            return r.right
    except Exception:
        pass
    return fallback


def _hud_numbers():
    """(orb size, right margin, top margin) in dp, read from hud.py's own config so the
    splash always matches the HUD. Plain text read: no import, nothing can break."""
    vals = {"ORB_SIZE": 48.0, "HUD_MARGIN_RIGHT": 28.0, "HUD_MARGIN_TOP": 28.0}
    try:
        with open(HUD_FILE, "r", encoding="utf-8") as f:
            text = f.read(30000)
        for name in vals:
            m = re.search(r"^%s\s*=\s*([0-9]+(?:\.[0-9]+)?)" % name, text, re.M)
            if m:
                vals[name] = float(m.group(1))
    except Exception:
        pass
    return vals["ORB_SIZE"], vals["HUD_MARGIN_RIGHT"], vals["HUD_MARGIN_TOP"]


def _hud_anchor():
    """Window margins (right, top, in dp) that put the splash ORB exactly where the HUD
    orb appears. Default start position, unless FOLLOW_HUD_POSITION is on."""
    orb, right, top = _hud_numbers()
    if FOLLOW_HUD_POSITION:
        try:
            with open(HUD_POS_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            right, top = float(d["right"]), float(d["top"])
        except Exception:
            pass
    delta = (orb / 2.0 + 5.0) - SPLASH_HC_DP     # HUD capsule half-height minus the splash's
    return right + delta, top + delta


def _click_through(root):
    """Click-through, never takes focus, hidden from Alt+Tab, always on top."""
    if os.name != "nt":
        return
    try:
        from ctypes import wintypes
        u = ctypes.WinDLL("user32", use_last_error=True)
        u.GetParent.argtypes = [wintypes.HWND]
        u.GetParent.restype = wintypes.HWND
        u.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
        u.GetWindowLongW.restype = ctypes.c_long
        u.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
        u.SetWindowLongW.restype = ctypes.c_long
        u.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, wintypes.UINT]
        u.SetWindowPos.restype = wintypes.BOOL
        root.update_idletasks()
        hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
        style = u.GetWindowLongW(hwnd, -20)                      # GWL_EXSTYLE
        style |= 0x00080000 | 0x00000020 | 0x00000080 | 0x08000000
        style &= ~0x00040000                                     # not APPWINDOW
        u.SetWindowLongW(hwnd, -20, style)
        u.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0020)
    except Exception:
        pass


# ---------------------------------------------------------------- the splash
class Splash:
    def __init__(self):
        _dpi_aware()
        import tkinter as tk
        import tkinter.font as tkfont
        self.root = root = tk.Tk()
        root.withdraw()
        root.overrideredirect(True)
        root.configure(bg=KEY)

        s = self.s = _scale()
        self.R, self.Hc = 18 * s, SPLASH_HC_DP * s             # orb radius, capsule half-height
        self.W, self.H = int(196 * s + 4), int(2 * self.Hc + 4)
        self.cx, self.cy, self.left = self.W - 2 - self.Hc, 2 + self.Hc, 2.0
        right, top = _hud_anchor()
        sw, sh = _screen_width(root), _screen_height(root)
        x = int(_work_right(root, sw) - right * s - self.W)
        y = int(top * s)
        x = max(0, min(x, sw - self.W))               # never off-screen, wherever it is
        y = max(0, min(y, sh - self.H))
        root.geometry("%dx%d+%d+%d" % (self.W, self.H, x, y))
        for opt, val in (("-topmost", True), ("-transparentcolor", KEY), ("-alpha", 0.02)):
            try:
                root.attributes(opt, val)
            except Exception:
                pass
        self.cv = tk.Canvas(root, width=self.W, height=self.H, bg=KEY, highlightthickness=0, bd=0)
        self.cv.pack()
        self.fb = tkfont.Font(root=root, family=FONT_FAMILY, size=-round(10 * s), weight="bold")
        self.fs = tkfont.Font(root=root, family=FONT_FAMILY, size=-round(12 * s))

        self._col = None
        self._ready_shown = False
        self.wall0 = time.time()
        self.real = 0.0              # last real % reported by jarvis_up.py
        self.pct = 0.0               # % currently displayed (eased)
        self._pct_shown = -1
        self._last_read = 0.0
        self._last_t = 0.0
        self._build()
        root.deiconify()
        _click_through(root)
        self.t0 = time.monotonic()
        self.ready_at = self.leave_at = None
        self._tick()

    # ---- one-time item creation (frames only move / recolour them) ----------
    def _circle(self, item, x, y, r):
        self.cv.coords(item, x - r, y - r, x + r, y + r)

    def _build(self):
        cv, s, cx, cy, R, Hc = self.cv, self.s, self.cx, self.cy, self.R, self.Hc

        def oval(fill):
            return cv.create_oval(0, 0, 1, 1, fill=fill, outline="")

        def pill(r, fill):
            a, b = oval(fill), oval(fill)
            c = cv.create_rectangle(0, 0, 1, 1, fill=fill, outline="")
            lx = self.left + Hc
            self._circle(a, lx, cy, r)
            self._circle(b, cx, cy, r)
            cv.coords(c, lx, cy - r, cx, cy + r)
            return (a, b, c)

        self.border = pill(Hc, KEY)
        pill(Hc - max(1.0, 1.4 * s), PANEL_BG)
        self.halo = [oval(KEY) for _ in range(N_HALO)]
        self.ripple = cv.create_oval(0, 0, 1, 1, fill="", outline=KEY,
                                     width=max(1.0, 1.4 * s), state="hidden")
        self.arcs = []
        for rel, ext, w in zip(ARC_R, ARC_EXT, ARC_W):
            r = R * rel
            self.arcs.append(cv.create_arc(cx - r, cy - r, cx + r, cy + r, start=0, extent=ext,
                                           style="arc", outline=KEY, width=max(1.0, w * s)))
        self.core = [oval(KEY) for _ in CORE]
        self.spec = oval(KEY)
        pts = ((-0.15, 0.00), (-0.05, 0.11), (0.16, -0.12))
        self.check = cv.create_line(*[v for dx, dy in pts for v in (cx + dx * R, cy + dy * R)],
                                    width=max(2.0, 2.4 * s), capstyle="round", joinstyle="round",
                                    fill=WHITE, state="hidden")
        tx = self.left + 22 * s
        self.bar_x0, self.bar_x1 = tx, cx - R - 8 * s
        self.bar_y, self.bar_h = cy + 15 * s, max(2.0, 3 * s)
        self.t_brand = cv.create_text(tx, cy - 11 * s, text="JARVIS", anchor="w",
                                      font=self.fb, fill=TEXT_COLOR)
        self.t_stat = cv.create_text(tx, cy + 2 * s, text="Starting", anchor="w",
                                     font=self.fs, fill=TEXT_COLOR)
        self.t_pct = cv.create_text(self.bar_x1, cy + 2 * s, text="0%", anchor="e",
                                    font=self.fb, fill=TEXT_COLOR)
        self.bar_track = cv.create_line(self.bar_x0, self.bar_y, self.bar_x1, self.bar_y,
                                        width=self.bar_h, capstyle="round", fill=KEY)
        self.bar_fill = cv.create_line(self.bar_x0, self.bar_y, self.bar_x0, self.bar_y,
                                       width=self.bar_h, capstyle="round", fill=KEY,
                                       state="hidden")

    def _recolor(self, col):
        cv = self.cv
        self._col = col
        for k, item in enumerate(self.halo):
            cv.itemconfigure(item, fill=_mix(PANEL_BG, col, 0.05 + 0.50 * k / (N_HALO - 1)))
        for item, c in zip(self.core, (_mix(PANEL_BG, col, 0.75), col, _mix(col, WHITE, 0.42))):
            cv.itemconfigure(item, fill=c)
        cv.itemconfigure(self.spec, fill=_mix(col, WHITE, 0.88))
        for arc, f in zip(self.arcs, (1.0, 0.88, 0.74)):
            cv.itemconfigure(arc, outline=_mix("#000000", col, f))
        cv.itemconfigure(self.t_brand, fill=_mix(col, WHITE, 0.35))
        cv.itemconfigure(self.t_pct, fill=_mix(col, WHITE, 0.35))
        cv.itemconfigure(self.bar_track, fill=_mix(PANEL_BG, col, 0.18))
        cv.itemconfigure(self.bar_fill, fill=col)

    # ---- progress -----------------------------------------------------------------
    def _read_real(self, now):
        """Poll the optional progress file ~10x/s (ignores stale files)."""
        if now - self._last_read < 0.1:
            return
        self._last_read = now
        try:
            with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            if float(d.get("ts", 0)) >= self.wall0 - 10:
                self.real = max(self.real, _clamp(float(d["pct"]), 0.0, 99.0))
        except Exception:
            pass

    def _update_progress(self, t, ready):
        dt = max(0.0, t - self._last_t)
        self._last_t = t
        if ready:
            target, rate = 100.0, 10.0
        else:
            self._read_real(time.monotonic())
            sim = SIM_CAP * (1.0 - math.exp(-t / SIM_TAU))     # estimated, never > SIM_CAP
            target, rate = max(sim, self.real), 5.0
        self.pct = max(self.pct, self.pct + (target - self.pct) * min(1.0, dt * rate))
        shown = 100 if (ready and self.pct >= 99.5) else min(99, int(self.pct))
        if shown != self._pct_shown:
            self._pct_shown = shown
            self.cv.itemconfigure(self.t_pct, text="%d%%" % shown)
        fx = self.bar_x0 + (self.bar_x1 - self.bar_x0) * _clamp(self.pct / 100.0)
        if fx - self.bar_x0 >= self.bar_h:
            self.cv.coords(self.bar_fill, self.bar_x0, self.bar_y, fx, self.bar_y)
            self.cv.itemconfigure(self.bar_fill, state="normal")

    # ---- one animation frame ----------------------------------------------------
    def _frame(self, t, rt):
        """t = seconds since start, rt = seconds since 'ready' (None while loading)."""
        cv, cx, cy, R = self.cv, self.cx, self.cy, self.R
        if rt is None:
            col = COLOR_LOADING
            b = 0.5 - 0.5 * math.cos(2 * math.pi * t / 1.6)               # slow breathing
            bloom = max(0.0, 1.0 - t / 0.4) ** 2                            # little pop at start
            base = 360.0 * t / 1.8
            for arc, ang in zip(self.arcs, ((-base) % 360, (base * 1.5) % 360, (-base * 2.2) % 360)):
                cv.itemconfigure(arc, start=ang)
            cv.itemconfigure(self.t_stat, text="Starting" + "." * (int(t * 2.5) % 4))
        else:
            f = _clamp(rt / 0.30)
            col = _mix(COLOR_LOADING, COLOR_READY, _ease(f))
            f2 = _clamp(rt / 0.50)
            b, bloom = math.sin(math.pi * f2), 0.0
            if not self._ready_shown:
                self._ready_shown = True
                for arc in self.arcs:
                    cv.itemconfigure(arc, state="hidden")
                cv.itemconfigure(self.check, state="normal")
                cv.itemconfigure(self.t_stat, text="Ready")
            if f2 < 1.0:
                self._circle(self.ripple, cx, cy, R * (0.36 + 0.62 * f2))
                cv.itemconfigure(self.ripple, state="normal",
                                 outline=_mix(PANEL_BG, col, 0.85 * (1.0 - f2) ** 1.3))
            else:
                cv.itemconfigure(self.ripple, state="hidden")
        if col != self._col:
            self._recolor(col)
        self._update_progress(t, rt is not None)
        hs = 0.74 + 0.26 * b + 0.22 * bloom
        for item, rel in zip(self.halo, HALO_R):
            self._circle(item, cx, cy, R * rel * hs)
        cs = (0.92 + 0.12 * b) * (1.0 + 0.18 * bloom)
        for item, (rr, dx, dy) in zip(self.core, CORE):
            self._circle(item, cx + dx * R * cs, cy + dy * R * cs, R * rr * cs)
        rr, dx, dy = SPEC
        self._circle(self.spec, cx + dx * R * cs, cy + dy * R * cs, R * rr * cs)
        edge = _mix(PANEL_BG, col, 0.26 + 0.22 * b)
        for item in self.border:
            cv.itemconfigure(item, fill=edge)

    # ---- timeline: loading -> ready -> fade out -> close ------------------------------
    def _tick(self):
        try:
            now = time.monotonic()
            t = now - self.t0
            if self.leave_at is None:
                if self.ready_at is None:
                    if t >= MIN_SHOW_SECONDS and os.path.exists(READY_FLAG):
                        self.ready_at = now
                    elif t >= MAX_SECONDS:
                        self.leave_at = now
                elif now - self.ready_at >= READY_HOLD_SECONDS:
                    self.leave_at = now
            a = OPACITY * _ease(t / FADE_IN_SECONDS)
            if self.leave_at is not None:
                out = (now - self.leave_at) / FADE_OUT_SECONDS
                if out >= 1.0:
                    return self.close()
                a *= 1.0 - _ease(out)
            self.root.attributes("-alpha", _clamp(a, 0.02, 1.0))
            self._frame(t, None if self.ready_at is None else now - self.ready_at)
            self.root.after(int(1000 / FPS), self._tick)
        except Exception:
            self.close()

    def close(self):
        try:
            self.root.destroy()
        except Exception:
            pass


def main():
    try:
        Splash().root.mainloop()
    except Exception:
        pass
    finally:
        for stale in (READY_FLAG, PROGRESS_FILE):   # leave no stale signal for next launch
            try:
                os.remove(stale)
            except OSError:
                pass


if __name__ == "__main__":
    main()
