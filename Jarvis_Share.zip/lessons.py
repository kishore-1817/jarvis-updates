"""
Lessons -- Jarvis's "notebook of mistakes".

When you correct Jarvis ("no, maximize WhatsApp", "I said close WhatsApp"),
this module writes down what you said, what Jarvis did, and what you
actually wanted. Before the next Gemini call, the few lessons that look
related to the new command are added to the prompt, so Gemini sees
"you got this wrong before" instead of repeating the mistake.

How it hooks in (3 tiny calls, all failure-proof -- nothing in here can
crash Jarvis, every public function swallows its own errors):

    jarvis_up.handle_command():
        lessons.begin_turn(text)            # is this a correction of the last turn?
        ... normal dispatch ...
        lessons.end_turn(text, _last_spoken)  # save the lesson, remember this turn
    llm_brain.ask_llm():
        lessons.prompt_block(text)          # text to put in front of the prompt

The table lives in the SAME jarvis_memory.db as notes/todos/preferences,
but is created and managed here so memory.py doesn't need to change.

LIMIT: lessons only steer what GEMINI decides. A command that one of
Jarvis's built-in keyword rules catches first never reaches Gemini, so
a lesson can't change that (that's what "learned shortcuts" is for).
"""

import logging
import re
import sqlite3
import threading
import time
from contextlib import closing
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("jarvis")

# If memory.py exposes its DB path under a common name we use it;
# otherwise jarvis_memory.db next to this file. Set DB_PATH here to force one.
DB_PATH = None

CORRECTION_WINDOW_SECONDS = 90   # a correction must follow the last turn within this
MAX_LESSONS = 200                # oldest, least-repeated lessons are pruned past this
MAX_IN_PROMPT = 4                # lessons shown to Gemini per question

_lock = threading.Lock()
_last = None          # {"said", "did", "t"} -- the previous turn
_correction = None    # set by begin_turn() when the current text corrects _last

# "no, ...", "I said ...", "I meant ...", "not that", "that's wrong" ...
# ("no thanks", "no problem" etc. are NOT corrections.)
_CORRECTION_RE = re.compile(
    r"^(?:no\b(?![\s,.!]*(?:thanks|thank you|problem|need|worries|that'?s all|nothing))"
    r"|nope\b|not that\b|that'?s (?:not|wrong|incorrect)\b|that is (?:not|wrong)\b"
    r"|wrong\b|i (?:said|meant|asked)\b|i didn'?t (?:say|mean|ask)\b"
    r"|what i (?:said|meant)\b)",
    re.IGNORECASE,
)

_FILLER = {
    "no", "nope", "not", "that", "that's", "thats", "wrong", "incorrect",
    "i", "said", "meant", "mean", "asked", "ask", "didn't", "didnt", "say",
    "what", "is", "it", "its", "it's", "the", "a", "an", "to", "of", "you",
    "my", "me", "please", "just", "i'm", "am", "was", "do", "did", "and",
    "for", "in", "on", "at", "this", "so", "but", "want", "wanted", "need",
}
_WORD_RE = re.compile(r"[a-z0-9']+")


def _tokens(text: str) -> set:
    return {w for w in _WORD_RE.findall((text or "").lower()) if w not in _FILLER and len(w) > 1}


def _db_path() -> str:
    if DB_PATH:
        return str(DB_PATH)
    try:
        import memory
        for name in ("DB_PATH", "DB_FILE", "DATABASE", "DB_NAME", "DB"):
            v = getattr(memory, name, None)
            if v:
                return str(v)
    except Exception:
        pass
    return str(Path(__file__).parent / "jarvis_memory.db")


def _connect():
    conn = sqlite3.connect(_db_path(), timeout=5)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS lessons (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               said TEXT NOT NULL,      -- what the user originally said
               did TEXT NOT NULL,       -- what Jarvis replied/did
               wanted TEXT NOT NULL,    -- the user's correction
               times INTEGER NOT NULL DEFAULT 1,
               created_at TEXT NOT NULL,
               last_seen TEXT NOT NULL
           )"""
    )
    return conn


# ---------------------------------------------------------------- saving
def _save(said: str, did: str, wanted: str) -> None:
    now = datetime.now().isoformat(timespec="seconds")
    with _lock, closing(_connect()) as conn, conn:
        row = conn.execute(
            "SELECT id FROM lessons WHERE lower(said)=? AND lower(wanted)=?",
            (said.lower(), wanted.lower()),
        ).fetchone()
        if row:   # same mistake again -> just count it
            conn.execute(
                "UPDATE lessons SET times=times+1, last_seen=? WHERE id=?", (now, row[0])
            )
        else:
            conn.execute(
                "INSERT INTO lessons (said, did, wanted, created_at, last_seen) "
                "VALUES (?,?,?,?,?)",
                (said, did, wanted, now, now),
            )
        # keep the notebook small: drop the oldest, least-repeated extras
        conn.execute(
            "DELETE FROM lessons WHERE id IN (SELECT id FROM lessons "
            "ORDER BY times DESC, last_seen DESC LIMIT -1 OFFSET ?)",
            (MAX_LESSONS,),
        )
    logger.info(f"LESSON saved: said={said!r} did={did!r} wanted={wanted!r}")


# ------------------------------------------------------------ turn hooks
def begin_turn(text: str) -> None:
    """Call BEFORE dispatching a command: decides if `text` is the user
    correcting Jarvis's previous answer."""
    global _correction
    try:
        _correction = None
        prev = _last
        if not prev or time.time() - prev["t"] > CORRECTION_WINDOW_SECONDS:
            return
        if prev["did"].rstrip().endswith("?"):
            return  # Jarvis asked a question, so "no ..." is an answer, not a correction
        if not _CORRECTION_RE.match((text or "").strip()):
            return
        _correction = {"said": prev["said"], "did": prev["did"], "wanted": text.strip()}
    except Exception as e:
        logger.warning(f"lessons.begin_turn failed: {e!r}")


def end_turn(text: str, spoken: str) -> None:
    """Call AFTER the command ran: saves the lesson (if this turn was a
    correction with real content) and remembers this turn for next time."""
    global _last, _correction
    try:
        c = _correction
        _correction = None
        # a bare "no" / "wrong" has nothing to learn from -- need real words
        if c and len(_tokens(c["wanted"])) >= 2:
            _save(c["said"][:200], c["did"][:200], c["wanted"][:200])
        _last = {"said": text or "", "did": spoken or "", "t": time.time()}
    except Exception as e:
        logger.warning(f"lessons.end_turn failed: {e!r}")


# -------------------------------------------------------------- reading
def relevant(text: str, limit: int = MAX_IN_PROMPT) -> list:
    """Lessons that share meaningful words with `text`, best first."""
    want = _tokens(text)
    if not want:
        return []
    with _lock, closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT said, did, wanted, times, last_seen FROM lessons"
        ).fetchall()
    scored = []
    for said, did, wanted, times, last_seen in rows:
        overlap = len(want & (_tokens(said) | _tokens(wanted)))
        if overlap:
            scored.append((overlap, times, last_seen, said, did, wanted))
    scored.sort(reverse=True)
    return [
        f'- User said "{s[:80]}", you replied "{d[:80]}", they corrected you: "{w[:100]}"'
        for _, _, _, s, d, w in scored[:limit]
    ]


def prompt_block(text: str) -> str:
    """Text to put in front of the Gemini prompt ("" if there's nothing)."""
    try:
        parts = []
        c = _correction
        if c:
            parts.append(
                f'The user is correcting your previous reply. They said "{c["said"][:120]}", '
                f'you replied "{c["did"][:120]}", and now they say "{c["wanted"][:160]}". '
                "Fix it -- do what they actually want."
            )
        lessons = relevant(text)
        if lessons:
            parts.append(
                "Past corrections from this user (hints only, never mention them aloud). "
                "Don't repeat these mistakes:\n" + "\n".join(lessons)
            )
        return ("\n".join(parts) + "\n\n") if parts else ""
    except Exception as e:
        logger.warning(f"lessons.prompt_block failed: {e!r}")
        return ""
