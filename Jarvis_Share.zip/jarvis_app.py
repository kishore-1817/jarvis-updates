"""
Jarvis App v3 - one double-click does everything.

First run (automatic): checks internet + disk, installs packages, asks for your Gemini key
(and tests it), downloads the Whisper speech models.
Every run: closes stray old Jarvis copies, shows the splash, starts jarvis_up.py, streams its log.
Self-healing: installs missing modules, restarts after crashes (up to 3 quick crashes).
Extras: Launch with Windows (waits 15 s for the PC to settle), health check, edit .env,
desktop shortcut, copy log, update from a new zip (keeps your personal files).

Keep this file + Jarvis.bat in the same folder as jarvis_up.py.
"""
import ast
import hashlib
import json
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, simpledialog, ttk

ROOT = Path(__file__).resolve().parent
ENTRY = "jarvis_up.py"
SPLASH = "jarvis_splash.py"
FLAG = ROOT / "jarvis_ready.flag"
APP_NAME = "JarvisApp"
SETTINGS = ROOT / "jarvis_app_settings.json"
APP_LOG = ROOT / "jarvis_app.log"
VERSION_FILE = ROOT / "jarvis_version.txt"
CONFIG_FILE = ROOT / "update_config.json"
DEPS_STAMP = ROOT / ".venv" / ".jarvis_deps_stamp"
MODELS_STAMP = ROOT / ".venv" / ".jarvis_models_ok"
WHISPER_MODELS = ("base.en", "small.en")
MIN_FREE_GB = 3
AUTOSTART_DELAY = 15
MAX_QUICK_CRASHES = 3

PYW = Path(sys.executable)
PYC = PYW.with_name("python.exe") if PYW.name.lower() == "pythonw.exe" else PYW
NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

SKIP_DIRS = {".venv", "venv", "models", "__pycache__", ".git", "node_modules", "build", "dist",
             "TOOLS", "DOCS", "form_chrome_profile", "tts_cache"}
# files an update zip must never overwrite (personal / per-PC)
KEEP_ON_UPDATE = {".env", "contacts.py", "corrections.py", "form_profile.txt", "app_paths.json",
                  "credentials.json", "brain_state.json", "jarvis_app_settings.json",
                  "hud_settings.json", "jarvis_progress.json", "gemini_api_key.txt"}
KEEP_PATTERNS = ("token", "hud_position")
KEEP_SUFFIXES = (".db", ".log")

PIP_MAP = {
    "whisper": "openai-whisper", "cv2": "opencv-python", "PIL": "pillow", "yaml": "pyyaml",
    "dotenv": "python-dotenv", "speech_recognition": "SpeechRecognition", "serial": "pyserial",
    "sklearn": "scikit-learn", "bs4": "beautifulsoup4",
    "google.generativeai": "google-generativeai", "google.genai": "google-genai",
    "google.oauth2": "google-auth", "google.auth": "google-auth",
    "googleapiclient": "google-api-python-client", "google_auth_oauthlib": "google-auth-oauthlib",
    "google_auth_httplib2": "google-auth-httplib2",
    "win32com": "pywin32", "win32api": "pywin32", "win32gui": "pywin32", "win32con": "pywin32",
    "win32clipboard": "pywin32", "win32process": "pywin32", "pythoncom": "pywin32",
    "pywintypes": "pywin32", "faster_whisper": "faster-whisper", "edge_tts": "edge-tts",
    "screen_brightness_control": "screen-brightness-control", "send2trash": "send2trash",
    "dateutil": "python-dateutil", "attr": "attrs",
}


def pip_name(module: str) -> str:
    parts = module.split(".")
    for i in range(len(parts), 0, -1):
        key = ".".join(parts[:i])
        if key in PIP_MAP:
            return PIP_MAP[key]
    return parts[0]


def scan_imports():
    stdlib = set(getattr(sys, "stdlib_module_names", ()))
    local, files = set(), []
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        local.update(dn)
        for f in fn:
            if f.endswith(".py"):
                local.add(f[:-3])
                files.append(Path(dp) / f)
    found = set()
    for f in files:
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="ignore"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            mods = []
            if isinstance(node, ast.Import):
                mods = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                mods = [node.module]
                if node.module == "google":  # "from google import genai" -> google.genai
                    mods = [f"google.{a.name}" for a in node.names]
            for m in mods:
                top = m.split(".")[0]
                if top in stdlib or top in local or top.startswith("_") or m == "google":
                    continue
                found.add(pip_name(m))
    return sorted(found)


# ---------- settings / .env ----------
def load_settings():
    try:
        return json.loads(SETTINGS.read_text())
    except Exception:
        return {"autorun": True}


def save_settings(d):
    try:
        SETTINGS.write_text(json.dumps(d, indent=2))
    except Exception:
        pass


def env_has_gemini_key():
    p = ROOT / ".env"
    if not p.exists():
        return (ROOT / "gemini_api_key.txt").exists()
    for line in p.read_text(errors="ignore").splitlines():
        line = line.strip()
        if line.startswith("GEMINI_API_KEY="):
            v = line.split("=", 1)[1].strip()
            return bool(v) and not v.lower().startswith("paste")
    return False


def write_gemini_key(key: str):
    p = ROOT / ".env"
    if not p.exists():
        ex = ROOT / ".env.example"
        p.write_text(ex.read_text(errors="ignore") if ex.exists() else "GEMINI_API_KEY=\n")
    lines, done = p.read_text(errors="ignore").splitlines(), False
    for i, line in enumerate(lines):
        if line.strip().startswith("GEMINI_API_KEY="):
            lines[i] = f"GEMINI_API_KEY={key}"
            done = True
    if not done:
        lines.append(f"GEMINI_API_KEY={key}")
    p.write_text("\n".join(lines) + "\n")


def check_gemini_key(key: str):
    """True = valid, False = rejected, None = could not reach Google."""
    try:
        url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + key
        with urllib.request.urlopen(url, timeout=12) as r:
            return r.status == 200
    except urllib.error.HTTPError as e:
        return False if e.code in (400, 401, 403) else None
    except Exception:
        return None


def local_version():
    try:
        return int(VERSION_FILE.read_text().strip())
    except Exception:
        return 0


def update_url():
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig")).get("url", "").strip()
    except Exception:
        return ""


def _url_ok(u):
    return u.startswith("https://") or u.startswith(("http://127.0.0.1", "http://localhost"))


def _open(url, timeout):
    sep = "&" if "?" in url else "?"
    req = urllib.request.Request(url + sep + "t=" + str(int(time.time())),
                                 headers={"User-Agent": "JarvisUpdater"})
    return urllib.request.urlopen(req, timeout=timeout)


def fetch_update_info(url):
    """Returns the info dict of a NEWER version, or None if up to date. Raises on errors."""
    if not _url_ok(url):
        raise ValueError("update address must start with https://")
    with _open(url, 15) as r:
        info = json.loads(r.read().decode("utf-8-sig"))
    if int(info["version"]) > local_version() and info.get("zip"):
        return info
    return None


def download_file(url, dest, sha256=None):
    if not _url_ok(url):
        raise ValueError("download address must start with https://")
    h = hashlib.sha256()
    with _open(url, 90) as r, open(dest, "wb") as out:
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            h.update(chunk)
            out.write(chunk)
    if sha256 and h.hexdigest().lower() != sha256.lower():
        raise ValueError("the download did not match its checksum - wait a few minutes and try again")


def online():
    for host in (("pypi.org", 443), ("generativelanguage.googleapis.com", 443)):
        try:
            socket.create_connection(host, timeout=6).close()
            return True
        except OSError:
            continue
    return False


# ---------- Windows autostart ----------
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def autostart_enabled():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, APP_NAME)
            return True
    except Exception:
        return False


def set_autostart(on: bool):
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        if on:
            winreg.SetValueEx(k, APP_NAME, 0, winreg.REG_SZ,
                              f'"{PYW}" "{Path(__file__).resolve()}" --autostart')
        else:
            try:
                winreg.DeleteValue(k, APP_NAME)
            except FileNotFoundError:
                pass
    try:  # avoid a double start if the old install_autostart.ps1 shortcut exists
        old = Path(os.environ["APPDATA"]) / r"Microsoft\Windows\Start Menu\Programs\Startup\Jarvis.lnk"
        if on and old.exists():
            old.unlink()
    except Exception:
        pass


def make_desktop_shortcut():
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut("
          "[Environment]::GetFolderPath('Desktop')+'\\Jarvis.lnk');"
          f"$s.TargetPath='{PYW}';$s.Arguments='\"{Path(__file__).resolve()}\"';"
          f"$s.WorkingDirectory='{ROOT}';"
          + (f"$s.IconLocation='{ROOT / 'jarvis.ico'}';" if (ROOT / "jarvis.ico").exists() else "")
          + "$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], creationflags=NOWIN)


def apply_update_zip(zip_path, root):
    """Extract a Jarvis zip over `root`, keeping personal / per-PC files. Returns file count."""
    count = 0
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        top = None
        if ENTRY not in names:  # zip wraps everything in one folder
            for n in names:
                if n.count("/") == 1 and n.endswith("/" + ENTRY):
                    top = n.split("/")[0]
        for n in names:
            rel = n
            if top:
                if not n.startswith(top + "/"):
                    continue
                rel = n[len(top) + 1:]
            parts = Path(rel).parts
            if not parts or ".." in parts or Path(rel).is_absolute() or parts[0] in SKIP_DIRS:
                continue
            base = parts[-1]
            dest = Path(root) / rel
            keep = ((base in KEEP_ON_UPDATE and len(parts) == 1) or base.endswith(KEEP_SUFFIXES)
                    or any(base.startswith(k) for k in KEEP_PATTERNS))
            if keep and dest.exists():
                continue
            if base == "jarvis_app.py" and len(parts) == 1:
                dest = Path(root) / "jarvis_app.py.new"
            dest.parent.mkdir(parents=True, exist_ok=True)
            with z.open(n) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
            count += 1
    new_app = Path(root) / "jarvis_app.py.new"
    if new_app.exists():
        os.replace(new_app, Path(root) / "jarvis_app.py")
    return count


def kill_stray_jarvis():
    """Close any other running Jarvis (old hidden copies fight over the microphone)."""
    ps = (r"Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and "
          r"$_.CommandLine -match 'jarvis_up\.py|jarvis_splash\.py' } | "
          r"ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], creationflags=NOWIN,
                       timeout=20, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class App:
    def __init__(self, autostart_flag: bool, lock=None):
        self.autostart_flag = autostart_flag
        self.settings = load_settings()
        self.q = queue.Queue()
        self.log_lock = threading.Lock()
        self.proc = None
        self.splash = None
        self.stopping = False
        self.retries = 0
        self.crashes = 0
        self.started_at = 0.0
        self.ready = False
        self.busy = False
        self.hidden = False
        try:
            if APP_LOG.exists() and APP_LOG.stat().st_size > 1_000_000:
                APP_LOG.write_text("")
        except Exception:
            pass

        r = self.root = tk.Tk()
        r.title(f"Jarvis v{local_version()}")
        r.geometry("820x560")
        r.configure(bg="#0b1220")
        try:
            r.iconbitmap(str(ROOT / "jarvis.ico"))
        except Exception:
            pass
        r.protocol("WM_DELETE_WINDOW", self.on_close)

        top = self.top = tk.Frame(r, bg="#0b1220")
        top.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(top, text="JARVIS", fg="#38bdf8", bg="#0b1220",
                 font=("Segoe UI", 20, "bold")).pack(side="left")
        self.status_lbl = tk.Label(top, text="Starting...", fg="#fbbf24", bg="#0b1220",
                                   font=("Segoe UI", 11, "bold"))
        self.status_lbl.pack(side="right")

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("J.Horizontal.TProgressbar", troughcolor="#1e293b", background="#38bdf8",
                        borderwidth=0, thickness=6)
        self.bar = ttk.Progressbar(r, mode="indeterminate", style="J.Horizontal.TProgressbar")
        # the bar only appears while something is installing/downloading

        btns = tk.Frame(r, bg="#0b1220")
        btns.pack(fill="x", padx=14, pady=2)
        self.b_start = self._btn(btns, "Start", self.start_async)
        self.b_stop = self._btn(btns, "Stop", self.stop)
        self.b_restart = self._btn(btns, "Restart", self.restart)
        self._btn(btns, "Health check", self.health_check)
        self._btn(btns, "Edit .env", self.edit_env)
        self._btn(btns, "Folder", lambda: os.startfile(ROOT))
        self._btn(btns, "Quit Jarvis", self.quit_all)
        btns2 = tk.Frame(r, bg="#0b1220")
        btns2.pack(fill="x", padx=14, pady=(2, 4))
        self._btn(btns2, "Desktop shortcut", self.shortcut)
        self._btn(btns2, "Copy log", self.copy_log)
        self._btn(btns2, "Check for updates", lambda: threading.Thread(
            target=self.check_updates, args=(True,), daemon=True).start())
        self._btn(btns2, "Update from zip", self.update_from_zip)
        self._btn(btns2, "Reinstall", self.reinstall)

        opts = tk.Frame(r, bg="#0b1220")
        opts.pack(fill="x", padx=14, pady=2)
        self.v_autorun = tk.BooleanVar(value=self.settings.get("autorun", True))
        self.v_win = tk.BooleanVar(value=autostart_enabled())
        self.v_min = tk.BooleanVar(value=self.settings.get("minimize_when_ready", True))
        for text, var, cmd in (("Start Jarvis when this app opens", self.v_autorun, self.save_opts),
                               ("Hide this window when Jarvis is ready", self.v_min, self.save_opts),
                               ("Launch with Windows", self.v_win, self.toggle_win)):
            tk.Checkbutton(opts, text=text, variable=var, command=cmd, fg="#e2e8f0", bg="#0b1220",
                           selectcolor="#0b1220", activebackground="#0b1220",
                           activeforeground="#e2e8f0").pack(side="left", padx=(0, 16))

        self.logbox = scrolledtext.ScrolledText(r, bg="#050a14", fg="#cbd5e1", font=("Consolas", 9),
                                                relief="flat", wrap="word")
        self.logbox.pack(fill="both", expand=True, padx=14, pady=(6, 12))
        self.logbox.configure(state="disabled")

        self._set_buttons(False)
        r.after(100, self.pump)
        if autostart_flag:
            r.withdraw()
            self.hidden = True
        if lock is not None:
            threading.Thread(target=self._listen, args=(lock,), daemon=True).start()
        threading.Thread(target=self.setup, daemon=True).start()

    # ---------- UI helpers ----------
    def _btn(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, bg="#1e293b", fg="#e2e8f0", relief="flat",
                      activebackground="#334155", activeforeground="#fff", padx=9, pady=4)
        b.pack(side="left", padx=(0, 6))
        return b

    def _set_buttons(self, running):
        self.b_start.config(state="disabled" if running or not self.ready or self.busy else "normal")
        self.b_stop.config(state="normal" if running else "disabled")
        self.b_restart.config(state="normal" if running else "disabled")

    def log(self, s):
        try:
            with self.log_lock, open(APP_LOG, "a", encoding="utf-8", errors="replace") as f:
                f.write(time.strftime("%H:%M:%S ") + s + "\n")
        except Exception:
            pass
        self.q.put(("log", s))

    def status(self, s, color):
        self.q.put(("status", (s, color)))

    def set_busy(self, on):
        self.busy = on
        self.q.put(("busy", on))

    def pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "log":
                    self.logbox.configure(state="normal")
                    self.logbox.insert("end", val + "\n")
                    if int(self.logbox.index("end-1c").split(".")[0]) > 3000:
                        self.logbox.delete("1.0", "500.0")
                    self.logbox.see("end")
                    self.logbox.configure(state="disabled")
                elif kind == "status":
                    self.status_lbl.config(text=val[0], fg=val[1])
                elif kind == "buttons":
                    self._set_buttons(val)
                elif kind == "busy":
                    if val:
                        self.bar.pack(fill="x", padx=14, pady=(0, 6), after=self.top)
                        self.bar.start(12)
                    else:
                        self.bar.stop()
                        self.bar.pack_forget()
                elif kind == "minimize":
                    if self.v_min.get():
                        self.root.withdraw()      # fully hidden: no window, no taskbar button
                        self.hidden = True
                elif kind == "restore":
                    self.root.deiconify()
                    self.root.lift()
                    try:
                        self.root.focus_force()
                    except Exception:
                        pass
                    self.hidden = False
                elif kind == "update_prompt":
                    self.root.deiconify()
                    self.hidden = False
                    notes = val.get("notes") or ""
                    if messagebox.askyesno("Jarvis update",
                                           f"A new version is available (v{val['version']}, you have "
                                           f"v{local_version()}).\n\n{notes}\n\nUpdate now? Your key, "
                                           "contacts and memory are kept."):
                        threading.Thread(target=self._download_and_update, args=(val,),
                                         daemon=True).start()
                elif kind == "askkey":
                    self.root.deiconify()
                    self.hidden = False
                    k = simpledialog.askstring(
                        "Jarvis setup",
                        val["prompt"] + "\n\nGet a free key at https://aistudio.google.com/apikey\n"
                        "(Leave empty to add it later with 'Edit .env'.)", parent=self.root)
                    val["key"] = (k or "").strip()
                    val["event"].set()
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def save_opts(self):
        self.settings["autorun"] = self.v_autorun.get()
        self.settings["minimize_when_ready"] = self.v_min.get()
        save_settings(self.settings)

    def toggle_win(self):
        try:
            set_autostart(self.v_win.get())
            self.log("Launch with Windows: " + ("ON" if self.v_win.get() else "OFF"))
        except Exception as e:
            self.log(f"Could not change startup setting: {e}")
            self.v_win.set(autostart_enabled())

    def shortcut(self):
        def go():
            make_desktop_shortcut()
            self.log("Desktop shortcut created.")
        threading.Thread(target=go, daemon=True).start()

    def edit_env(self):
        p = ROOT / ".env"
        if not p.exists():
            ex = ROOT / ".env.example"
            p.write_text(ex.read_text(errors="ignore") if ex.exists() else "GEMINI_API_KEY=\n")
        subprocess.Popen(["notepad", str(p)])

    def copy_log(self):
        text = self.logbox.get("1.0", "end").strip().splitlines()[-300:]
        self.root.clipboard_clear()
        self.root.clipboard_append("\n".join(text))
        self.log("Last lines copied to the clipboard - paste them into a message.")

    def health_check(self):
        def go():
            chk = ROOT / "check_setup.py"
            if not chk.exists():
                self.log("check_setup.py not found.")
                return
            self.log("--- health check ---")
            p = subprocess.Popen([str(PYC), "-u", str(chk)], cwd=ROOT, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                 errors="replace", creationflags=NOWIN)
            for line in p.stdout:
                self.log(line.rstrip())
            p.wait()
        threading.Thread(target=go, daemon=True).start()

    # ---------- update from zip ----------
    def update_from_zip(self):
        path = filedialog.askopenfilename(title="Choose the new Jarvis zip",
                                          filetypes=[("Zip files", "*.zip")])
        if not path:
            return
        if not messagebox.askyesno("Update Jarvis",
                                   "Apply this zip over the current Jarvis?\n\nYour .env, contacts, "
                                   "memory and tokens are kept. Jarvis will stop and this app will restart."):
            return
        threading.Thread(target=self._do_update, args=(path,), daemon=True).start()

    def check_updates(self, manual=False):
        url = update_url()
        if not url:
            if manual:
                self.log("Updates are not set up in this copy (update_config.json has no address).")
            return
        try:
            info = fetch_update_info(url)
        except Exception as e:
            if manual:
                self.log(f"Could not check for updates: {e}")
            return
        if not info:
            if manual:
                self.log(f"Jarvis is up to date (version {local_version()}).")
            return
        if self.autostart_flag and not manual:
            self.log(f"Update available: version {info['version']}. Click 'Check for updates' to install.")
            return
        self.q.put(("update_prompt", info))

    def _download_and_update(self, info):
        try:
            self.status("Downloading update...", "#fbbf24")
            self.set_busy(True)
            tmp = Path(tempfile.gettempdir()) / "jarvis_update.zip"
            download_file(info["zip"], tmp, info.get("sha256"))
            self._do_update(str(tmp), version=info["version"])
        except Exception as e:
            self.set_busy(False)
            self.status("Update failed", "#f87171")
            self.log(f"Update failed: {e}")

    def _do_update(self, path, version=None):
        try:
            self.stop()
            time.sleep(1.5)
            self.status("Updating...", "#fbbf24")
            self.set_busy(True)
            count = apply_update_zip(path, ROOT)
            if version is not None:
                VERSION_FILE.write_text(str(version))
            try:
                DEPS_STAMP.unlink()
            except FileNotFoundError:
                pass
            self.log(f"Update applied ({count} files). Restarting the app...")
            time.sleep(1)
            cmd = f'timeout /t 2 /nobreak >nul & start "" "{PYW}" "{ROOT / "jarvis_app.py"}"'
            subprocess.Popen(cmd, shell=True, creationflags=NOWIN)
            os._exit(0)
        except Exception as e:
            self.set_busy(False)
            self.status("Update failed", "#f87171")
            self.log(f"Update failed: {e!r}")

    # ---------- setup ----------
    def pip(self, args):
        p = subprocess.Popen([str(PYC), "-m", "pip", "install", "--disable-pip-version-check", *args],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                             cwd=ROOT, creationflags=NOWIN)
        for line in p.stdout:
            line = line.rstrip()
            if line.startswith(("Collecting", "Successfully", "ERROR")):
                self.log(line)
        return p.wait()

    def install_packages(self, pkgs):
        failed = []
        if not pkgs:
            return failed
        if self.pip(pkgs) == 0:
            return failed
        self.log("Bulk install failed - retrying one by one...")
        for p in pkgs:
            if self.pip([p]) != 0:
                self.log(f"  (could not install {p})")
                failed.append(p)
        return failed

    def ask_key(self, prompt):
        holder = {"event": threading.Event(), "prompt": prompt, "key": ""}
        self.q.put(("askkey", holder))
        holder["event"].wait()
        return holder["key"]

    def preflight(self):
        free = shutil.disk_usage(ROOT).free / 1e9
        if free < MIN_FREE_GB:
            self.q.put(("restore", None))
            self.status("Not enough disk space", "#f87171")
            self.log(f"Only {free:.1f} GB free on this drive; Jarvis setup needs about {MIN_FREE_GB} GB. "
                     "Free some space, then click Reinstall.")
            return False
        if not online():
            self.q.put(("restore", None))
            self.status("No internet", "#f87171")
            self.log("Cannot reach the internet. Connect to Wi-Fi, then click Reinstall.")
            return False
        return True

    def setup(self):
        try:
            if not (ROOT / ENTRY).exists():
                self.q.put(("restore", None))
                self.status(f"{ENTRY} not found", "#f87171")
                self.log(f"Put this app in the same folder as {ENTRY}. Current folder: {ROOT}")
                return
            self.set_busy(True)

            req = ROOT / "requirements.txt"
            req_text = req.read_text(errors="ignore") if req.exists() else ""
            extras = scan_imports()
            sig = hashlib.sha256((req_text + "\n" + "\n".join(extras)).encode()).hexdigest()
            need_deps = not DEPS_STAMP.exists() or DEPS_STAMP.read_text() != sig
            need_models = not MODELS_STAMP.exists()

            if (need_deps or need_models) and not self.preflight():
                self.set_busy(False)
                return

            if need_deps:
                self.status("Step 1/3: installing packages (5-15 min the first time)...", "#fbbf24")
                failed = []
                if req.exists():
                    self.log("Installing requirements.txt ...")
                    if self.pip(["-r", str(req)]) != 0:
                        self.log("requirements.txt had errors - installing one by one instead.")
                        names = [re.split(r"[=<>!~ ]", l.strip())[0] for l in req_text.splitlines()
                                 if l.strip() and not l.startswith("#")]
                        failed += self.install_packages(names)
                self.log("Checking packages your code imports ...")
                failed += self.install_packages(extras)
                if failed:
                    self.log("Some packages failed: " + ", ".join(failed) +
                             ". Check your internet, then click Reinstall.")
                else:
                    DEPS_STAMP.write_text(sig)

            if not env_has_gemini_key():
                self.status("Step 2/3: waiting for your Gemini key...", "#fbbf24")
                self.set_busy(False)
                prompt = "Paste your free Gemini API key."
                for _ in range(3):
                    key = self.ask_key(prompt)
                    if not key:
                        self.log("No Gemini key entered. Use 'Edit .env' to add GEMINI_API_KEY=... later.")
                        break
                    verdict = check_gemini_key(key)
                    if verdict is False:
                        prompt = "That key was rejected by Google. Please paste it again."
                        self.log("Gemini key rejected - asking again.")
                        continue
                    write_gemini_key(key)
                    self.log("Gemini key saved to .env" +
                             ("" if verdict else " (could not verify it - no connection to Google)"))
                    break
                self.set_busy(True)

            if not MODELS_STAMP.exists():
                self.status("Step 3/3: downloading speech models (first time only)...", "#fbbf24")
                self.log("Downloading Whisper models: " + ", ".join(WHISPER_MODELS))
                code = ("from faster_whisper import WhisperModel;"
                        f"[WhisperModel(m, device='cpu', compute_type='int8') for m in {WHISPER_MODELS!r}];"
                        "print('speech models ready')")
                p = subprocess.Popen([str(PYC), "-c", code], cwd=ROOT, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                                     errors="replace", creationflags=NOWIN)
                for line in p.stdout:
                    if line.strip():
                        self.log(line.rstrip()[:200])
                if p.wait() == 0:
                    MODELS_STAMP.write_text("ok")
                else:
                    self.log("Model download failed (check internet). It will retry on the next launch.")

            self.set_busy(False)
            self.ready = True
            self.status("Ready", "#34d399")
            self.q.put(("buttons", False))
            threading.Thread(target=self.check_updates, daemon=True).start()
            if self.v_autorun.get():
                if self.autostart_flag:
                    for s in range(AUTOSTART_DELAY, 0, -1):
                        self.status(f"Waiting for Windows to settle... {s}s", "#fbbf24")
                        time.sleep(1)
                self.start()
        except Exception as e:
            self.set_busy(False)
            self.q.put(("restore", None))
            self.status("Setup error", "#f87171")
            self.log(f"Setup error: {e!r}")

    def reinstall(self):
        for s in (DEPS_STAMP, MODELS_STAMP):
            try:
                s.unlink()
            except FileNotFoundError:
                pass
        self.stop()
        self.ready = False
        self.q.put(("buttons", False))
        threading.Thread(target=self.setup, daemon=True).start()

    # ---------- run / stop ----------
    def start_async(self):
        threading.Thread(target=self.start, daemon=True).start()

    def start(self):
        if self.proc or not self.ready:
            return
        self.stopping = False
        self.status("Starting Jarvis...", "#fbbf24")
        kill_stray_jarvis()
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONUTF8="1")
        try:
            FLAG.unlink()
        except FileNotFoundError:
            pass
        if (ROOT / SPLASH).exists():
            try:
                self.splash = subprocess.Popen([str(PYW), SPLASH], cwd=ROOT, env=env,
                                               creationflags=NOWIN)
            except Exception:
                self.splash = None
        self.started_at = time.time()
        self.proc = subprocess.Popen([str(PYC), "-u", ENTRY], cwd=ROOT, env=env,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding="utf-8", errors="replace",
                                     creationflags=NOWIN)
        self.status("Jarvis running", "#34d399")
        self.q.put(("buttons", True))
        self.log("--- Jarvis started ---")
        threading.Thread(target=self._watch, args=(self.proc,), daemon=True).start()

    def _kill(self, p):
        if p and p.poll() is None:
            subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], creationflags=NOWIN,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _watch(self, p):
        missing = None
        hidden = False
        for line in p.stdout:
            line = line.rstrip()
            self.log(line)
            if not hidden and ("voice assistant ready" in line.lower() or FLAG.exists()):
                hidden = True
                self.q.put(("minimize", None))
            m = re.search(r"No module named '([\w\.]+)'", line)
            if m:
                missing = m.group(1)
        code = p.wait()
        self.proc = None
        self._kill(self.splash)
        self.q.put(("buttons", False))
        ran = time.time() - self.started_at
        if self.stopping:
            self.status("Stopped", "#94a3b8")
            self.log("--- Jarvis stopped ---")
            return
        if missing and self.retries < 5:
            self.retries += 1
            pkg = pip_name(missing)
            self.status(f"Installing missing module: {pkg}", "#fbbf24")
            self.log(f"Missing module '{missing}' -> installing {pkg} and restarting...")
            self.install_packages([pkg])
            self.start()
            return
        if code == 0:
            self.status("Jarvis exited", "#94a3b8")
            self.log("--- Jarvis exited normally ---")
            if self.hidden:
                os._exit(0)
            return
        # crashed
        self.crashes = 0 if ran > 60 else self.crashes + 1
        if self.crashes <= MAX_QUICK_CRASHES:
            self.log(f"--- Jarvis crashed (code {code}). Restarting automatically "
                     f"({self.crashes}/{MAX_QUICK_CRASHES}) ---")
            self.status("Restarting after a crash...", "#fbbf24")
            time.sleep(3)
            self.start()
        else:
            self.status("Jarvis keeps crashing", "#f87171")
            self.q.put(("restore", None))
            self.log("--- Jarvis crashed several times in a row. Click 'Copy log' and send it to "
                     "whoever gave you Jarvis, or try 'Health check'. ---")

    def stop(self):
        if not self.proc:
            return
        self.stopping = True
        self._kill(self.proc)
        self._kill(self.splash)

    def restart(self):
        def go():
            self.stop()
            time.sleep(1.5)
            self.crashes = 0
            self.start()
        threading.Thread(target=go, daemon=True).start()

    def _listen(self, lock):
        while True:
            try:
                conn, _ = lock.accept()
                conn.close()
                self.q.put(("restore", None))
            except Exception:
                return

    def quit_all(self):
        self.stop()
        self.root.after(300, lambda: os._exit(0))


def _on_close(self):
    if self.proc:
        self.root.withdraw()              # Jarvis keeps running, window disappears completely
        self.hidden = True
        return
    if self.busy and not messagebox.askyesno("Jarvis", "Setup is still running.\n\nQuit anyway?"):
        return
    self.root.destroy()
    os._exit(0)


App.on_close = _on_close


def single_instance():
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 47653))
        s.listen(5)
        return s
    except OSError:
        try:  # Jarvis is already running: ask that copy to show its window
            c = socket.create_connection(("127.0.0.1", 47653), timeout=2)
            c.sendall(b"show")
            c.close()
        except OSError:
            pass
        return None


if __name__ == "__main__":
    lock = single_instance()
    if lock is None:
        sys.exit(0)
    App("--autostart" in sys.argv, lock).root.mainloop()
