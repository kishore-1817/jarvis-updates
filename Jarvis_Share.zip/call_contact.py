"""
call_contact.py — WhatsApp calling automation for Jarvis (Store app version).

Uses the exact selectors confirmed earlier with Accessibility Insights
for Windows:
    - Sidebar search box:  Name="Search or start a new chat", ControlType=Edit
    - Voice call button:   Name="Voice call",                  ControlType=Button

KEY LESSON LEARNED — WhatsApp has TWO different things named "Search":
  1. The sidebar contact search (what we want) — sits on the LEFT side
     of the window, small x-coordinate.
  2. An in-chat "search messages" button in the header of whatever
     chat is currently open — sits on the RIGHT side, next to Voice
     call / Video call. Same title ("Search"), completely different
     purpose. An earlier version of this script grabbed #2 by mistake,
     which meant nothing ever got typed into the real search, the chat
     never changed, and it called whoever's chat was already open.
Fix: we disambiguate by screen position (left side = sidebar), and we
VERIFY the target contact's name actually appears in the header before
clicking Call — we never blindly trust that Enter opened the right chat.

IMPORTANT — why WhatsApp briefly appears in the foreground:
WhatsApp's search box is a React/WebView component that only reacts to
real keystrokes, not UIA's programmatic set_edit_text(). Windows only
delivers real simulated keystrokes to the foreground window, so we
bring WhatsApp forward just long enough to search and call, then
restore whatever window you were using before.

RESOLVED BUG (typing didn't land): pywinauto's type_keys() consistently
failed to deliver keystrokes into WhatsApp's sidebar search box — clicks
landed correctly (has_keyboard_focus() == True) but no characters ever
registered, confirmed via both get_value() and UIA TextPattern reads,
with no exception raised. A standalone raw-SendInput test (ctypes +
user32.SendInput, KEYEVENTF_UNICODE) bypassing pywinauto's key-sending
path entirely DID land text in the same box. So typing (and the
DOWN/ENTER navigation) now goes through _send_text()/_send_vk() in this
file instead of search_box.type_keys() — do not revert to type_keys()
for this control without re-confirming it actually works.

Usage (standalone test):
    python call_contact.py Joe

Integration into jarvis.py:
    from call_contact import call_contact
    ...
    if t.startswith("call "):
        name = t[len("call "):].strip()
        speak(f"Calling {name} on WhatsApp")
        call_contact(name)
"""

import sys
import time
import ctypes
from pywinauto import Application

try:
    import win32gui
    HAVE_WIN32GUI = True
except ImportError:
    HAVE_WIN32GUI = False

SCRIPT_VERSION = "r10-delegates-to-send_message"

# How far from the left edge of the WhatsApp window still counts as
# "sidebar" (vs. the chat area/header on the right) — as a fraction of
# total window width. Used to tell the two same-named "Search" controls
# apart, and to tell the sidebar chat list apart from the chat header.
SIDEBAR_WIDTH_FRACTION = 0.4

# ---------------------------------------------------------------------
# Raw SendInput helpers -- see the RESOLVED BUG note above for why
# these exist instead of pywinauto's type_keys()/send_keys().
# ---------------------------------------------------------------------
_KEYEVENTF_UNICODE = 0x0004
_KEYEVENTF_KEYUP = 0x0002
_INPUT_KEYBOARD = 1


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort),
        ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _INPUT(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_ulong),
        ("ki", _KEYBDINPUT),
        ("padding", ctypes.c_ubyte * 8),
    ]


def _send_char(ch, pause=0.03):
    """Send a single Unicode character as a raw SendInput keystroke,
    bypassing pywinauto's type_keys() entirely (see note above)."""
    extra = ctypes.c_ulong(0)
    down = _INPUT(type=_INPUT_KEYBOARD,
                  ki=_KEYBDINPUT(0, ord(ch), _KEYEVENTF_UNICODE, 0, ctypes.pointer(extra)))
    up = _INPUT(type=_INPUT_KEYBOARD,
                ki=_KEYBDINPUT(0, ord(ch), _KEYEVENTF_UNICODE | _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra)))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(down), ctypes.sizeof(_INPUT))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(up), ctypes.sizeof(_INPUT))
    time.sleep(pause)


def _send_text(text, pause=None):
    for ch in text:
        _send_char(ch, pause) if pause is not None else _send_char(ch)


_VK_BACK = 8
_VK_RETURN = 13
_VK_CONTROL = 17
_VK_DOWN = 40
_VK_A = 65


def _send_vk(vk_code, pause=0.03):
    """Send a raw virtual-key press (no Unicode flag) — used for
    non-character keys like Down/Enter that SendInput needs sent as
    actual key codes rather than Unicode characters."""
    extra = ctypes.c_ulong(0)
    down = _INPUT(type=_INPUT_KEYBOARD,
                  ki=_KEYBDINPUT(vk_code, 0, 0, 0, ctypes.pointer(extra)))
    up = _INPUT(type=_INPUT_KEYBOARD,
                ki=_KEYBDINPUT(vk_code, 0, _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra)))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(down), ctypes.sizeof(_INPUT))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(up), ctypes.sizeof(_INPUT))
    time.sleep(pause)


def _send_ctrl_a(pause=0.03):
    """Send Ctrl+A (select all) as raw SendInput key-down/key-up pairs,
    used to select any leftover text in the search box before clearing
    it — the earlier single-key _send_vk() can't express modifier
    combos."""
    extra = ctypes.c_ulong(0)
    ctrl_down = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(_VK_CONTROL, 0, 0, 0, ctypes.pointer(extra)))
    a_down = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(_VK_A, 0, 0, 0, ctypes.pointer(extra)))
    a_up = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(_VK_A, 0, _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra)))
    ctrl_up = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(_VK_CONTROL, 0, _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra)))
    for inp in (ctrl_down, a_down, a_up, ctrl_up):
        ctypes.windll.user32.SendInput(1, ctypes.pointer(inp), ctypes.sizeof(_INPUT))
    time.sleep(pause)


def _clear_search_box(pause=0.03):
    """Select-all + Backspace to empty out whatever's currently in the
    focused search box. WhatsApp's search box carries over leftover
    text from the previous search (its accessible Name reflects the
    current text, not a fixed placeholder), which breaks the next
    lookup by title="Search or start a new chat" — clearing before
    every search avoids that entirely."""
    _send_ctrl_a(pause)
    _send_vk(_VK_BACK, pause)


def _visible_matches(win, max_left=None, min_left=None, **criteria):
    """Return descendants matching criteria that are actually visible
    on screen with a real bounding rectangle, optionally restricted to
    a horizontal region (used to tell the sidebar apart from the
    chat header, since WhatsApp reuses the same element titles for
    unrelated buttons in each)."""
    matches = []
    try:
        candidates = win.descendants(**criteria)
    except Exception:
        candidates = []
    for cand in candidates:
        try:
            rect = cand.rectangle()
            if not cand.is_visible():
                continue
            if rect.width() <= 0 or rect.height() <= 0:
                continue
            if max_left is not None and rect.left > max_left:
                continue
            if min_left is not None and rect.left < min_left:
                continue
            matches.append(cand)
        except Exception:
            continue
    return matches


def _read_search_box_text(search_box):
    """Try to read the search box's current text via two different UIA
    patterns, since WhatsApp's WebView/React edit control has been
    observed to not sync ValuePattern (get_value()) correctly. Returns
    a tuple (value_pattern_text, text_pattern_text) — either may be an
    error string starting with '<' if that method failed."""
    try:
        value_text = search_box.get_value()
    except Exception as e:
        value_text = f"<couldn't read via get_value: {e}>"

    try:
        text_pattern = search_box.iface_text
        doc_range = text_pattern.DocumentRange
        text_pattern_text = doc_range.GetText(-1)
    except Exception as e:
        text_pattern_text = f"<TextPattern failed: {e}>"

    return value_text, text_pattern_text


def call_contact(contact, timeout=10):
    """Voice-call a WhatsApp contact.

    Now uses the SAME pipeline as sending a message (send_message.py):
    auto-launches WhatsApp if it's closed, searches the name, opens whatever
    result is on top (no header/name verification), then clicks "Voice call".
    The imports below are deliberately inside the function: send_message.py
    imports the helpers at the top of THIS file, so importing it at module
    level here would be circular. The old verified implementation is kept as
    _call_contact_legacy() below.
    """
    from send_message import call_whatsapp_contact
    return call_whatsapp_contact(contact)


def _call_contact_legacy(contact, timeout=10):
    print(f"[call_contact] Script version: {SCRIPT_VERSION}")

    original_hwnd = None
    if HAVE_WIN32GUI:
        try:
            original_hwnd = win32gui.GetForegroundWindow()
        except Exception:
            original_hwnd = None

    try:
        app = Application(backend="uia").connect(title_re=".*WhatsApp.*")
        win = app.top_window()
        print(f"[call_contact] Connected to window: '{win.window_text()}'")
    except Exception as e:
        print(f"[call_contact] Could not connect to WhatsApp — is it open? ({e})")
        return False

    try:
        win.set_focus()
        time.sleep(0.15)

        win_rect = win.rectangle()
        sidebar_cutoff = win_rect.left + int(win_rect.width() * SIDEBAR_WIDTH_FRACTION)
        print(f"[call_contact] Window rect: {win_rect} — sidebar cutoff at x={sidebar_cutoff}")

        # Sidebar search box: prefer the exact known name, fall back to
        # any Edit control left of the cutoff, and if even that comes
        # up empty, dump every visible Edit control (any position) so
        # you can see what WhatsApp is actually showing right now.
        search_candidates = _visible_matches(
            win, max_left=sidebar_cutoff,
            title="Search or start a new chat", control_type="Edit",
        )
        if not search_candidates:
            search_candidates = _visible_matches(win, max_left=sidebar_cutoff, control_type="Edit")

        if not search_candidates:
            all_search_boxes = _visible_matches(win, control_type="Edit")
            positions = [c.rectangle() for c in all_search_boxes]
            print(f"[call_contact] Sidebar search box not found left of x={sidebar_cutoff}. "
                  f"All visible Edit controls (any position): {positions}")
            print("[call_contact] If that list is also empty, WhatsApp is likely not on the "
                  "Chats screen right now (e.g. stuck on a call-ended overlay, a permission "
                  "popup, or a different tab) — check the window manually and retry.")
            return False

        search_box = search_candidates[0]
        print(f"[call_contact] Using search box at {search_box.rectangle()}, "
              f"is_enabled={search_box.is_enabled()}")

        box_rect = search_box.rectangle()
        center_x = (box_rect.left + box_rect.right) // 2
        center_y = (box_rect.top + box_rect.bottom) // 2

        contact_lower = contact.strip().lower()
        landed = False
        after_value = after_textpattern = ""

        for attempt in range(2):
            settle = 0.15 if attempt == 0 else 0.4
            key_pause = 0.02 if attempt == 0 else 0.05

            search_box.click_input(coords=(center_x - box_rect.left, center_y - box_rect.top))
            time.sleep(settle)

            try:
                has_focus = search_box.has_keyboard_focus()
            except Exception as e:
                has_focus = f"<check failed: {e}>"

            if has_focus is not True:
                print(f"[call_contact] Click didn't focus the box (attempt {attempt + 1}) — "
                      f"trying set_focus() + double-click fallback")
                try:
                    search_box.set_focus()
                except Exception as e:
                    print(f"[call_contact] set_focus() failed: {e}")
                time.sleep(0.1)
                try:
                    search_box.double_click_input(coords=(center_x - box_rect.left, center_y - box_rect.top))
                except Exception as e:
                    print(f"[call_contact] double_click_input() fallback failed: {e}")
                time.sleep(0.15)

            try:
                _clear_search_box(pause=key_pause)
            except Exception as e:
                print(f"[call_contact] Clearing search box raised an exception: {e}")
            time.sleep(0.05)

            try:
                _send_text(contact, pause=key_pause)
            except Exception as e:
                print(f"[call_contact] Raw SendInput typing raised an exception: {e}")

            time.sleep(0.25 if attempt == 0 else 0.5)

            after_value, after_textpattern = _read_search_box_text(search_box)
            landed = (contact_lower in after_value.lower()) or (contact_lower in after_textpattern.lower())

            if landed:
                break
            print(f"[call_contact] Typing didn't land on attempt {attempt + 1} "
                  f"(get_value='{after_value}', TextPattern='{after_textpattern}')"
                  f"{' — retrying' if attempt == 0 else ''}")

        print(f"[call_contact] Landed check — {landed}")

        if not landed:
            print(f"[call_contact] Typed text did not land in the box after retrying "
                  f"(expected '{contact}', get_value='{after_value}', TextPattern='{after_textpattern}'). "
                  f"Aborting.")
            return False

        time.sleep(0.2)
        _send_vk(_VK_DOWN)
        time.sleep(0.15)
        _send_vk(_VK_RETURN)
        time.sleep(0.6)

        # Verify the chat that actually opened matches the contact we
        # searched for -- scan the header area (right of the sidebar
        # cutoff) for the contact's name before doing anything
        # irreversible. Never trust that Enter opened the right chat.
        header_confirmed = False
        header_texts_seen = []

        for ctrl_type in ("Text", "Button"):
            for cand in _visible_matches(win, min_left=sidebar_cutoff, control_type=ctrl_type):
                try:
                    txt = cand.window_text()
                except Exception:
                    txt = ""
                if txt and txt not in header_texts_seen:
                    header_texts_seen.append(txt)
                if txt and contact_lower in txt.lower():
                    header_confirmed = True
                    break
            if header_confirmed:
                break

        if not header_confirmed:
            print(f"[call_contact] Aborting — after searching '{contact}', the chat header "
                  f"doesn't show that name. Header shows: {header_texts_seen[:15]}")
            print("[call_contact] This means Enter didn't open the right chat — refusing to "
                  "call to avoid contacting the wrong person.")
            return False

        print(f"[call_contact] Confirmed chat header matches '{contact}'.")

        call_candidates = _visible_matches(win, min_left=sidebar_cutoff, title="Voice call", control_type="Button")
        if not call_candidates:
            print(f"[call_contact] Header confirmed for '{contact}' but no visible Voice call button found.")
            return False

        call_candidates[0].click_input()
        print(f"[call_contact] Call initiated to '{contact}'.")
        return True

    finally:
        if HAVE_WIN32GUI and original_hwnd:
            try:
                time.sleep(0.2)
                win32gui.SetForegroundWindow(original_hwnd)
            except Exception as e:
                print(f"[call_contact] (Couldn't restore previous window — {e})")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python call_contact.py <contact name>")
        sys.exit(1)
    name = " ".join(sys.argv[1:])
    result = call_contact(name)
    print("Done." if result else "Failed — see messages above.")
