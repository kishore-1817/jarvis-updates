"""
pipeline.py -- the actual escalation logic: L0 -> L1 -> (math | action
| L2 | L3). See the package's __init__.py for the two public entry
points this file backs.

Escalation order, cheapest first:
    L0  window info               (instant, local, always)
    L1  local OCR                 (fast, local, always -- no network)
        -> simple math on the OCR text?      answer locally, STOP
        -> (copy_screen_text call)           clipboard, STOP, no Gemini
        -> OCR text substantial enough?      L2, Gemini TEXT only
        -> otherwise (icons/layout/images)   L3, Gemini VISION

This directly targets the "20 seconds for reading '14 + 4' off the
screen" problem the old implementation had: that case now resolves at
the math check, zero network calls, no image ever sent anywhere.

NOTE: the safety/sensitive-window check (planned: gate L2 and L3 since
those are the tiers that actually send data to Gemini) is deliberately
NOT implemented yet -- explicitly deferred per instruction, pure focus
on speed for this pass. The tiering here is already structured so that
check can slot in as one guard clause before the L2/L3 calls whenever
it's built.
"""

from . import cache
from clipboard_control import set_clipboard_text
from local_math import try_math_from_symbols
from . import explain, vision

# Below this many characters, OCR text is treated as "not enough to
# answer from" and escalates straight to vision instead of attempting
# a text-only answer that would likely be wrong/unhelpful.
MIN_TEXT_LENGTH_FOR_L2 = 10

# Question phrasing that implies the answer needs actual visual
# understanding (an icon's appearance, a color, a layout) rather than
# just the text present -- forces L3 even if OCR found plenty of text.
_VISUAL_KEYWORDS = ("icon", "image", "picture", "logo", "color", "colour",
                     "button", "look like", "layout", "where is the")


def _try_local_math(ocr_text: str):
    """Checks each line of the OCR text independently (not the whole
    blob at once) against the math pattern, since a real screen often
    has surrounding UI text (title bars, menus) alongside the actual
    expression -- checking line by line is far more likely to isolate
    a clean match than requiring the entire OCR result to be just math."""
    for line in ocr_text.splitlines():
        result = try_math_from_symbols(line)
        if result is not None:
            return result
    return None


def _needs_vision(ocr_text: str, question: str) -> bool:
    if len(ocr_text.strip()) < MIN_TEXT_LENGTH_FOR_L2:
        return True
    q = question.lower()
    return any(kw in q for kw in _VISUAL_KEYWORDS)


def handle_screen_request(question: str = "") -> str:
    """The general screen Q&A entry point: L0 -> L1 -> math shortcut ->
    L2 or L3. Returns a spoken-friendly answer string."""
    screenshot, ocr_text, _window = cache.get_capture_and_text()

    math_answer = _try_local_math(ocr_text)
    if math_answer is not None:
        return math_answer

    if _needs_vision(ocr_text, question):
        return vision.ask_about_image(screenshot, question)

    return explain.ask_about_text(ocr_text, question)


def copy_screen_text() -> str:
    """The action tier: OCR the screen and copy the extracted text
    directly to the clipboard. No Gemini call at all -- this is the
    fastest possible path for 'copy the text from my screen' style
    requests."""
    _screenshot, ocr_text, _window = cache.get_capture_and_text()

    if not ocr_text.strip():
        return "I didn't find any text on the screen to copy."

    success = set_clipboard_text(ocr_text)
    return ("Copied the visible text to your clipboard." if success
            else "I found text on screen but couldn't copy it to the clipboard.")
