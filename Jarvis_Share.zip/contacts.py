﻿"""
contacts.py -- YOUR names for Jarvis's WhatsApp commands (optional).

Needs the Microsoft Store version of WhatsApp. Leave both empty to skip.
"""

# Exact names as saved in WhatsApp, e.g. ["Mom", "John Smith"]
KNOWN_CONTACTS = []

# What Jarvis hears (lowercase) -> name to search in WhatsApp,
# e.g. {"mum": "Mom", "jon": "John Smith"}
CONTACT_ALIASES = {}
