"""
Automatic installed-app discovery for the Jarvis voice assistant.

Builds a name -> launch-command map from three sources and caches it to
app_paths.json next to this file:

  1. Start Menu shortcuts (.lnk). If the shortcut points at an .exe we
     launch that (plus arguments). Anything else -- .bat, .url, .msc,
     "advertised" shortcuts with no resolvable target -- is launched by
     opening the shortcut itself, so it is no longer silently skipped.
  2. The "App Paths" registry key.
  3. Store/UWP and many desktop apps via PowerShell's Get-StartApps.

Run `python app_finder.py` to rebuild and see how many apps each source
found, or `python app_finder.py "some app"` to also see what a spoken
name would resolve to.
"""

import difflib
import json
import os
import re
import subprocess
import winreg
from pathlib import Path

import win32com.client

CACHE_FILE = Path(__file__).parent / "app_paths.json"

START_MENU_DIRS = [
    Path(r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs"),
    Path.home() / r"AppData\Roaming\Microsoft\Windows\Start Menu\Programs",
]

_UWP_PREFIX = "explorer.exe shell:AppsFolder"


def _is_junk(name: str) -> bool:
    return "uninstall" in name


def _scan_start_menu() -> dict:
    shell = win32com.client.Dispatch("WScript.Shell")
    apps = {}
    for base in START_MENU_DIRS:
        if not base.exists():
            continue
        for lnk in base.rglob("*.lnk"):
            name = lnk.stem.lower()
            if _is_junk(name):
                continue
            try:
                shortcut = shell.CreateShortcut(str(lnk))
                target = shortcut.Targetpath
                args = shortcut.Arguments
                if target and target.lower().endswith(".exe"):
                    command = f'"{target}"'
                    if args:
                        command += f" {args}"
                else:
                    # Not a plain exe (bat/url/msc/advertised shortcut):
                    # just open the shortcut itself, Windows resolves it.
                    command = f'start "" "{lnk}"'
                apps[name] = command
            except Exception:
                continue
    return apps


def _scan_app_paths_registry() -> dict:
    apps = {}
    key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(hive, key_path) as key:
                i = 0
                while True:
                    try:
                        subkey_name = winreg.EnumKey(key, i)
                        i += 1
                    except OSError:
                        break
                    try:
                        with winreg.OpenKey(key, subkey_name) as subkey:
                            path, _ = winreg.QueryValueEx(subkey, "")
                    except OSError:
                        continue
                    path = os.path.expandvars(str(path).strip())
                    if not path:
                        continue
                    if not path.startswith('"') and Path(path).exists():
                        path = f'"{path}"'
                    name = re.sub(r"\.exe$", "", subkey_name.lower())
                    if not _is_junk(name):
                        apps[name] = path
        except FileNotFoundError:
            continue
    return apps


def _scan_uwp_apps() -> dict:
    """Get-StartApps lists Store apps AND most desktop apps with a Start
    entry. Forced to UTF-8 and given a generous timeout: with the old
    15s timeout / locale encoding, a slow PowerShell start or one app
    name with a non-ASCII character made the whole scan return nothing."""
    apps = {}
    ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
          "Get-StartApps | ConvertTo-Json -Compress")
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=90,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return apps
        data = json.loads(result.stdout)
        if isinstance(data, dict):
            data = [data]
        for entry in data:
            name = (entry.get("Name") or "").strip().lower()
            app_id = (entry.get("AppID") or "").strip()
            if name and app_id and not _is_junk(name):
                apps[name] = f"{_UWP_PREFIX}\\{app_id}"
    except Exception:
        pass
    return apps


def _read_cache() -> dict:
    try:
        return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def build_app_index() -> dict:
    """Merge order: Get-StartApps first, then registry, then Start Menu
    (wins on conflicts). If the Get-StartApps scan comes back empty
    (timeout etc.), keep the Store/UWP entries from the previous cache
    instead of wiping them."""
    old = _read_cache()
    uwp = _scan_uwp_apps()
    if not uwp:
        uwp = {k: v for k, v in old.items() if v.startswith(_UWP_PREFIX)}

    apps = {}
    apps.update(uwp)
    apps.update(_scan_app_paths_registry())
    apps.update(_scan_start_menu())

    tmp = CACHE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(apps, indent=2), encoding="utf-8")
    tmp.replace(CACHE_FILE)
    return apps


def load_app_index() -> dict:
    if CACHE_FILE.exists():
        data = _read_cache()
        if data:
            return data
    return build_app_index()


def _words(s: str) -> list:
    return re.findall(r"[a-z0-9]+", s.lower())


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _contains_seq(haystack: list, needle: list) -> bool:
    n = len(needle)
    return n > 0 and any(haystack[i:i + n] == needle
                         for i in range(len(haystack) - n + 1))


def find_app_path(spoken_name: str, apps: dict):
    """Resolve a spoken name to a launch command. Whole-WORD matching
    only, so short names can't hijack longer ones ("arcade" no longer
    opens Arc, "codecademy" no longer opens VS Code). Order:
      1. exact name
      2. same name ignoring spaces/punctuation
      3. spoken words appear inside an app name ("blender" ->
         "blender 5.2.1.0"); the shortest such name wins
      4. an app name appears inside what was said ("claude desktop" ->
         "claude"); the longest such name wins
      5. close spelling (difflib >= 0.8) on the normalized names
    """
    q = spoken_name.lower().strip()
    if not q:
        return None
    if q in apps:
        return apps[q]

    nq = _norm(q)
    q_words = _words(q)
    norm_map = {}
    for name in apps:
        norm_map.setdefault(_norm(name), name)

    if nq in norm_map:
        return apps[norm_map[nq]]

    inside = [n for n in apps if _contains_seq(_words(n), q_words)]
    if inside:
        return apps[min(inside, key=len)]

    contained = [n for n in apps if _contains_seq(q_words, _words(n))]
    if contained:
        return apps[max(contained, key=len)]

    close = difflib.get_close_matches(nq, list(norm_map), n=1, cutoff=0.8)
    if close:
        return apps[norm_map[close[0]]]
    return None


if __name__ == "__main__":
    import sys

    uwp, reg, sm = _scan_uwp_apps(), _scan_app_paths_registry(), _scan_start_menu()
    print(f"Get-StartApps: {len(uwp)}   App Paths: {len(reg)}   Start Menu: {len(sm)}")
    if not uwp:
        print("WARNING: Get-StartApps returned nothing (timeout/blocked?).")
    index = build_app_index()
    print(f"Total indexed: {len(index)}")
    for q in sys.argv[1:]:
        print(f"{q!r} -> {find_app_path(q, index)}")
        for src, d in (("Get-StartApps", uwp), ("App Paths", reg), ("Start Menu", sm)):
            hits = [n for n in d if q.lower() in n]
            print(f"   in {src}: {hits[:5] or 'no'}")
