"""
file_commands.py -- file/folder-related voice command matching.

Part of the Command Router refactor (see command_router.py): this
module owns ONLY the "which phrase means what" matching for file and
folder commands. The actual file-system mechanics (copy/move/rename/
delete/create/find/list, plus the pending-confirmation flow for
destructive actions) still live in file_manager.py -- this file is
purely the voice-command layer on top of it.

ORDER WITHIN THIS DOMAIN MATTERS, same as it did before extraction:
more specific patterns (drive destinations, "delete X folder", "find
all X in Y") are checked before their more general siblings ("copy X
to Y", generic "delete X", generic "find X"), so the specific ones
don't get shadowed. This is the exact same relative order these
checks ran in inside jarvis_up.py's old dispatcher -- only WHERE the
code lives changed, not the priority between these patterns.

NOT included here (still in jarvis_up.py, other domains not yet
migrated): weather, keyboard control, WhatsApp call/message, app
open/close, media, web search, time/date. None of those share a
trigger word with anything in this file ("find ", "copy X to Y",
"open my/the file X", etc.), so migrating only these file-related
checks doesn't change behavior for anything else.
"""

import re

from file_manager import (
    FOLDERS, resolve_folder_key,
    copy_or_move_file, copy_or_move_to_path_command,
    rename_command, delete_folder_command, delete_command,
    create_folder_command, duplicate_command, show_location_command,
    list_files_command, search_folder_command, find_command, open_command,
)

_COPY_MOVE_RE = re.compile(r"(copy|move) (.+?) to (?:the )?(\w+)$")
_COPY_MOVE_DRIVE_RE = re.compile(r"(copy|move) (.+?) to (?:the )?([a-z] drive.*)$")
_OPEN_FILE_RE = re.compile(r"^open (?:my |the file |file )(.+)$")
_RENAME_FILE_RE = re.compile(r"rename (.+?) to (.+)$")
_DELETE_FOLDER_RE = re.compile(r"delete (?:the )?(.+?) folder$")
_DELETE_FILE_RE = re.compile(r"delete (?:my |the )?(.+)$")
_CREATE_FOLDER_RE = re.compile(r"create (?:a )?folder (?:called |named )?(.+?)(?: in (\w+))?$")
_DUPLICATE_RE = re.compile(r"(?:make a copy of|duplicate) (?:my |the )?(.+)$")
_SHOW_LOCATION_RE1 = re.compile(r"show me where (?:my |the )?(.+?) is$")
_SHOW_LOCATION_RE2 = re.compile(r"where is (?:my |the )?(.+)$")
_LIST_FILES_RE = re.compile(r"(?:what files are in|list files in|what's in) (?:my |the )?(\w+)$")
_SEARCH_EXT_RE = re.compile(r"find all (\w+?) in (?:my |the )?(\w+)$")
_FIND_FILE_RE = re.compile(r"find (?:my |the )?(.+)$")


def try_handle(t: str, speak) -> bool:
    """Checks `t` (the lowercased, stripped transcript) against every
    file/folder command this domain knows.

    Returns True and calls speak(...) if handled. Returns False
    (without calling speak at all) if this domain doesn't recognize
    the phrase, so the router can try the next domain -- or fall back
    to whatever hasn't been migrated out of jarvis_up.py yet.
    """
    # "open my resume" / "open the file resume" / "open file report.pdf"
    # -- requires one of these explicit markers so it never shadows
    # "open chrome" or "open downloads" (app/folder intent), which stay
    # in jarvis_up.py's own "open " handling.
    open_file_match = _OPEN_FILE_RE.match(t)
    if open_file_match:
        speak(open_command(open_file_match.group(1).strip()))
        return True

    # "copy/move <file> to <drive> drive <folder>" -- arbitrary
    # destination, always confirmed (see file_manager.py for why).
    drive_match = _COPY_MOVE_DRIVE_RE.match(t)
    if drive_match:
        action, filename, spoken_dest = drive_match.groups()
        speak(copy_or_move_to_path_command(filename, spoken_dest, move=(action == "move")))
        return True

    # "copy/move <file> to <folder>" -- known folder (desktop, etc.)
    copy_match = _COPY_MOVE_RE.match(t)
    if copy_match:
        action, filename, spoken_dest = copy_match.groups()
        dest_key = resolve_folder_key(spoken_dest)
        if dest_key in FOLDERS:
            speak(copy_or_move_file(filename, dest_key, move=(action == "move")))
        else:
            speak(f"I don't recognize the folder {spoken_dest}. "
                  f"I know: {', '.join(FOLDERS.keys())}.")
        return True

    # "rename <old> to <new>" -- tries a file match first, falls back
    # to a folder match, so this one pattern covers both.
    rename_match = _RENAME_FILE_RE.match(t)
    if rename_match:
        old_name, new_name = rename_match.groups()
        speak(rename_command(old_name.strip(), new_name.strip()))
        return True

    # "delete the <name> folder" -- checked before the generic file
    # delete below, since it's the more specific pattern.
    delete_folder_match = _DELETE_FOLDER_RE.match(t)
    if delete_folder_match:
        speak(delete_folder_command(delete_folder_match.group(1).strip()))
        return True

    # "delete <name>" -- generic file delete.
    delete_file_match = _DELETE_FILE_RE.match(t)
    if delete_file_match:
        speak(delete_command(delete_file_match.group(1).strip()))
        return True

    # "create a folder called <name>" / "... in <parent>"
    create_folder_match = _CREATE_FOLDER_RE.match(t)
    if create_folder_match:
        name, parent = create_folder_match.groups()
        speak(create_folder_command(name.strip(), parent or "desktop"))
        return True

    # "make a copy of <name>" / "duplicate <name>"
    duplicate_match = _DUPLICATE_RE.match(t)
    if duplicate_match:
        speak(duplicate_command(duplicate_match.group(1).strip()))
        return True

    # "show me where <name> is" / "where is <name>"
    show_loc_match = _SHOW_LOCATION_RE1.match(t) or _SHOW_LOCATION_RE2.match(t)
    if show_loc_match:
        speak(show_location_command(show_loc_match.group(1).strip()))
        return True

    # "what files are in <folder>" / "list files in <folder>"
    list_files_match = _LIST_FILES_RE.match(t)
    if list_files_match:
        speak(list_files_command(list_files_match.group(1).strip()))
        return True

    # "find all <ext> in <folder>" -- checked before the generic "find"
    # below, since it's the more specific pattern.
    search_ext_match = _SEARCH_EXT_RE.match(t)
    if search_ext_match:
        ext, folder = search_ext_match.groups()
        speak(search_folder_command(ext, folder.strip()))
        return True

    # "find <name>" -- generic file find, checked last since it's the
    # most general pattern in this domain (matches almost anything
    # starting with "find").
    find_match = _FIND_FILE_RE.match(t)
    if find_match:
        speak(find_command(find_match.group(1).strip()))
        return True

    return False
