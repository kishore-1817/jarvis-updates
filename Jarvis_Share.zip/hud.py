"""
hud.py -- Jarvis "Ambient Core" HUD
====================================

A small, optional, click-through widget that tells you what Jarvis is doing
without looking at the CMD window. How it LOOKS is a switchable theme that
lives in hud_animations.py (orb / wave / none). THIS file owns the window,
the state machine, the threads and the API Jarvis talks to.

Default theme "orb": a dark capsule with a glowing orb and a thin vertical
line near the top-right of the screen:

        +------------------------+
        |  JARVIS          ( o ) |      <- capsule: label + orb
        |  Listening...          |         (collapses to just the orb
        +------------------------+          a moment after the label)
                            |
                            |             <- thin line (a pulse travels
                            |                down it while EXECUTING)

DESIGN (why it is cheap)
------------------------
* Tkinter + a few Win32 calls via ctypes. No new dependencies.
* The window is only ~300x300 px (not full screen) and is created once.
* The HUD thread BLOCKS on a queue: in STANDBY it does nothing at all
  (plus one optional 1 s wake-up to pump Windows messages, see HEARTBEAT).
* All animation moves a few pre-created canvas items. No images, no
  per-frame allocation, 15-24 fps only while a state is animating.
* Visual only: Jarvis never waits for the HUD (calls just enqueue a message).

PUBLIC API (non-blocking, never raises)
---------------------------------------
    hud.start()                         # once, at startup
    hud.set_state("EXECUTING", "Opening Chrome...")
    hud.speaking_start() / speaking_end()
    hud.executing_begin(msg) / executing_end()
    hud.wrap_tool(fn)                   # EXECUTING while an action runs
    hud.stop()                          # automatic at exit
"""

import atexit
import functools
import inspect
import json
import logging
import math
import os
import queue
import threading
import time

log = logging.getLogger("jarvis.hud")

# =====================================================================
# CONFIGURATION  (the only place with tunable numbers)
# =====================================================================
HUD_ENABLED = True             # False -> Jarvis runs with no HUD at all
HUD_DEBUG = False              # True -> tiny "STATE / MESSAGE" line near the widget
HUD_OPACITY = 0.92             # overall opacity multiplier, 0.0 - 1.0
ANIMATION_SPEED = 1.0          # 1.0 normal, 0.5 half speed, 2.0 double

ORB_SIZE = 48                  # orb diameter in dp (96-dpi pixels): 35-60 looks right
HUD_MARGIN_RIGHT = 28          # distance from the right screen edge, dp
HUD_MARGIN_TOP = 28            # distance from the top screen edge, dp
LINE_LENGTH = 190              # length of the vertical line under the orb, dp
TARGET_MONITOR = "primary"     # v1: only the primary monitor is supported

HUD_THEME = "orb"              # "orb" | "wave" | "none"  (a saved choice in hud_settings.json wins)
HUD_THEME_HOTKEY = "ctrl+alt+t"  # cycle themes. "" = disable the hotkey
THEMES = ("orb", "wave", "none")  # cycle order

# Wave Dock theme
WAVE_WIDTH = 300               # dock width, dp
WAVE_BARS = 13                 # number of bars
WAVE_MARGIN_BOTTOM = 36        # distance above the taskbar, dp

HUD_MOVE_HOTKEY = "ctrl+alt+h" # press, drag the widget, let go. "" = disable the hotkey
MOVE_MODE_SECONDS = 12         # move mode cancels itself after this long without a drag
REMEMBER_POSITION = True       # save the dragged position to hud_position.json
RESTORE_SAVED_POSITION = False # False -> every start uses the default spots (wave: bottom-middle,
                               # orb: top-right). True -> start where you last dragged it.

STATUS_TEXT_ENABLED = True     # show messages such as "Opening Chrome..."
MINI_INDICATOR_ENABLED = True  # show the small "JARVIS" name above the message
STATUS_TEXT_SECONDS = 2.5      # how long a normal message stays before the capsule shrinks

HEARD_TEXT_ENABLED = True      # brief "what Jarvis heard" bubble under the widget
HEARD_TEXT_SECONDS = 1.5       # how long it stays
HEARD_TEXT_MAX_CHARS = 40      # longer phrases are cut with "..."

MIN_EXECUTING_SECONDS = 0.4    # EXECUTING stays visible at least this long (visual only,
                               # never blocks Jarvis). 0 = off.
FADE_SECONDS = 0.22            # fade between STANDBY and active
HEARTBEAT_SECONDS = 1.0        # idle wake-up just to pump Windows messages (no drawing).
                               # None = block forever (zero wake-ups).
WATCHDOG_SECONDS = 180         # a non-standby state with no update this long -> STANDBY

SUCCESS_SECONDS = 0.40
ERROR_SECONDS = 1.00
INTERRUPTED_SECONDS = 0.35

# --- visual style: change the look here ------------------------------
COLORS = {
    "STANDBY":      "#6b95c9",
    "LISTENING":    "#38bdf8",
    "THINKING":     "#a78bfa",
    "EXECUTING":    "#fbbf24",
    "SPEAKING":     "#2dd4bf",
    "SUCCESS":      "#4ade80",
    "CONFIRMATION": "#fb923c",
    "ERROR":        "#f87171",
    "INTERRUPTED":  "#cbd5e1",
    "MOVE":         "#93c5fd",
}
PANEL_BG = "#0b1220"           # capsule / orb backdrop
TEXT_COLOR = "#e5edf7"
FONT_FAMILY = "Segoe UI"
KEY_COLOR = "#010203"          # becomes fully transparent; never used for drawing


# =====================================================================
# STATE DEFINITIONS  (central, data-only)
# =====================================================================
# kind: static | breathe | speak | orbit | flow | fade | blink | collapse
# duration set -> transient state (plays once, then returns)
# sticky       -> its message never auto-hides
def _spec(kind, alpha=(0.96, 0.96), period=1.0, fps=20, duration=None,
          text=None, sticky=False, ripple=0):
    return {"kind": kind, "alpha": alpha, "period": period, "fps": fps,
            "duration": duration, "text": text, "sticky": sticky, "ripple": ripple}


STATES = {
    "STANDBY":      _spec("static",   alpha=(0.45, 0.45), fps=30),
    "LISTENING":    _spec("breathe",  period=3.2, fps=20, ripple=2, text="Listening..."),
    "THINKING":     _spec("orbit",    period=1.8, fps=24, text="Thinking..."),
    "EXECUTING":    _spec("flow",     period=1.1, fps=24, text="Working..."),
    "SPEAKING":     _spec("speak",    period=0.9, fps=24, text="Speaking..."),
    "SUCCESS":      _spec("fade",     fps=24, duration=SUCCESS_SECONDS),
    "CONFIRMATION": _spec("breathe",  period=1.2, fps=20, ripple=1, text="Confirm?", sticky=True),
    "ERROR":        _spec("blink",    fps=24, duration=ERROR_SECONDS, text="Error"),
    "INTERRUPTED":  _spec("collapse", fps=24, duration=INTERRUPTED_SECONDS),
    "MOVE":         _spec("breathe",  period=1.6, fps=30, ripple=1, text="Drag me, then let go",
                          sticky=True),
}
for _n, _s in STATES.items():
    _s["name"] = _n                # themes look states up by name


# =====================================================================
# PURE HELPERS  (no Tk, easy to test)
# =====================================================================
def _clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else hi if v > hi else v


def _rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _mix(a, b, f):
    """Colour between a (f=0) and b (f=1)."""
    (r1, g1, b1), (r2, g2, b2) = _rgb(a), _rgb(b)
    out = "#%02x%02x%02x" % (int(r1 + (r2 - r1) * f), int(g1 + (g2 - g1) * f),
                             int(b1 + (b2 - b1) * f))
    return "#020304" if out == KEY_COLOR else out


def _dim(c, f):
    return _mix("#000000", c, f)


def _ease(f):
    f = _clamp(f)
    return f * f * (3 - 2 * f)


# =====================================================================
# WINDOWS HELPERS  (private DLL handles: we never touch Jarvis' ctypes.windll)
# =====================================================================
_WS_EX_LAYERED = 0x00080000
_WS_EX_TRANSPARENT = 0x00000020     # click-through
_WS_EX_TOOLWINDOW = 0x00000080      # hidden from Alt+Tab
_WS_EX_NOACTIVATE = 0x08000000      # never takes focus
_WS_EX_APPWINDOW = 0x00040000
_GWL_EXSTYLE = -20
_SWP_FLAGS = 0x0001 | 0x0002 | 0x0010 | 0x0020   # NOSIZE|NOMOVE|NOACTIVATE|FRAMECHANGED


def _user32():
    import ctypes
    return ctypes.WinDLL("user32", use_last_error=True)


def _enable_thread_dpi_awareness():
    """Make ONLY the HUD thread per-monitor DPI aware, so the rest of Jarvis
    (screen capture, pyautogui, ...) keeps its current coordinate behaviour."""
    if os.name != "nt":
        return
    try:
        import ctypes
        fn = _user32().SetThreadDpiAwarenessContext
        fn.restype = ctypes.c_void_p
        fn.argtypes = [ctypes.c_void_p]
        fn(ctypes.c_void_p(-4))          # PER_MONITOR_AWARE_V2
    except Exception as e:
        log.debug("HUD: thread DPI awareness unavailable: %r", e)


def _screen_size(root):
    if os.name == "nt":
        try:
            u = _user32()
            w, h = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
            if w > 0 and h > 0:
                return w, h
        except Exception:
            pass
    return root.winfo_screenwidth(), root.winfo_screenheight()


def _dpi_scale(root):
    try:
        if os.name == "nt":
            dpi = _user32().GetDpiForSystem()
        else:
            dpi = root.winfo_fpixels("1i")
        return min(4.0, max(1.0, dpi / 96.0))
    except Exception:
        return 1.0


def _work_area(sw, sh):
    """Screen minus the taskbar: (left, top, right, bottom)."""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            r = wintypes.RECT()
            if _user32().SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0):   # SPI_GETWORKAREA
                return r.left, r.top, r.right, r.bottom
        except Exception:
            pass
    return 0, 0, sw, sh


def _apply_click_through(root):
    """Click-through, no-focus, hidden from Alt+Tab, always on top."""
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes
    u = _user32()
    u.GetParent.argtypes = [wintypes.HWND]
    u.GetParent.restype = wintypes.HWND
    u.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    u.GetWindowLongW.restype = ctypes.c_long
    u.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    u.SetWindowLongW.restype = ctypes.c_long
    u.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                               ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u.SetWindowPos.restype = wintypes.BOOL

    root.update_idletasks()
    hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
    style = u.GetWindowLongW(hwnd, _GWL_EXSTYLE)
    style |= (_WS_EX_LAYERED | _WS_EX_TRANSPARENT | _WS_EX_TOOLWINDOW | _WS_EX_NOACTIVATE)
    style &= ~_WS_EX_APPWINDOW
    u.SetWindowLongW(hwnd, _GWL_EXSTYLE, style)
    u.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0, _SWP_FLAGS)   # HWND_TOPMOST
    return (u, hwnd)


_POS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hud_position.json")
_SWP_NOZORDER_FLAGS = 0x0001 | 0x0002 | 0x0010 | 0x0020 | 0x0004


def _parse_hotkey(combo):
    """'ctrl+alt+h' -> (modifier flags, virtual-key code) or None."""
    mods, vk = 0, None
    for part in str(combo).lower().replace(" ", "").split("+"):
        if part in ("ctrl", "control"):
            mods |= 0x0002
        elif part == "alt":
            mods |= 0x0001
        elif part == "shift":
            mods |= 0x0004
        elif part in ("win", "windows"):
            mods |= 0x0008
        elif len(part) == 1 and part.isalnum():
            vk = ord(part.upper())
        elif part.startswith("f") and part[1:].isdigit() and 1 <= int(part[1:]) <= 24:
            vk = 0x70 + int(part[1:]) - 1
    return (mods, vk) if (vk is not None and mods) else None


def _hotkey_loop(hotkeys, post, holder):
    """Runs in its own tiny thread: blocks in GetMessage (zero CPU) until a
    global hotkey is pressed, then posts its command to the HUD.
    hotkeys = [("ctrl+alt+h", ("move",)), ("ctrl+alt+t", ("theme_next",))]"""
    try:
        import ctypes
        from ctypes import wintypes
        u = _user32()
        u.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
        u.RegisterHotKey.restype = wintypes.BOOL
        u.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
        u.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
        u.GetMessageW.restype = ctypes.c_int
        holder["tid"] = ctypes.WinDLL("kernel32").GetCurrentThreadId()
        registered = {}
        for i, (combo, cmd) in enumerate(hotkeys):
            parsed = _parse_hotkey(combo) if combo else None
            if not parsed:
                if combo:
                    log.warning("HUD: invalid hotkey %r ignored", combo)
                continue
            hid = 0x4A56 + i
            if u.RegisterHotKey(None, hid, parsed[0] | 0x4000, parsed[1]):   # 0x4000 = no auto-repeat
                registered[hid] = cmd
                log.info("HUD hotkey registered: %s -> %s", combo, cmd[0])
            else:
                log.warning("HUD: could not register hotkey %r (used by another app?); "
                            "change it in hud.py", combo)
        if not registered:
            return
        msg = wintypes.MSG()
        try:
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == 0x0312 and msg.wParam in registered:      # WM_HOTKEY
                    post(registered[msg.wParam])
        finally:
            for hid in registered:
                u.UnregisterHotKey(None, hid)
    except Exception:
        log.exception("HUD hotkey thread failed (hotkeys unavailable)")


# =====================================================================
# OVERLAY HOST  (owns the ONE Tk window; delegates all drawing to a theme)
# =====================================================================
_SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hud_settings.json")


def _load_settings():
    try:
        with open(_SETTINGS_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_settings(**kw):
    try:
        d = _load_settings()
        d.update(kw)
        with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception as e:
        log.warning("HUD: could not save settings: %r", e)


class _Overlay:
    def __init__(self, notify=None):
        _enable_thread_dpi_awareness()
        import tkinter as tk
        self.root = tk.Tk()
        root = self.root
        root.withdraw()
        root.overrideredirect(True)
        root.configure(bg=KEY_COLOR)
        self.sw, self.sh = _screen_size(root)
        self.scale = _dpi_scale(root)
        self.notify = notify or (lambda cmd: None)
        self.alpha_set = -1.0
        self.theme = None
        self.theme_name = None
        self._win = None

        root.geometry("1x1+0+0")
        for opt, val in (("-topmost", True), ("-transparentcolor", KEY_COLOR), ("-alpha", 0.02)):
            try:
                root.attributes(opt, val)
            except Exception as e:                   # e.g. non-Windows: keep going
                log.debug("HUD: window attribute %s unsupported: %r", opt, e)
        self.cv = tk.Canvas(root, width=1, height=1, bg=KEY_COLOR, highlightthickness=0, bd=0)
        self.cv.pack()
        self.cv.bind("<ButtonPress-1>", lambda e: self._fwd("on_press", e))
        self.cv.bind("<B1-Motion>", lambda e: self._fwd("on_motion", e))
        self.cv.bind("<ButtonRelease-1>", lambda e: self._fwd("on_release", e))

        root.deiconify()
        try:
            self._win = _apply_click_through(root)
        except Exception as e:
            log.warning("HUD: could not make window click-through: %r", e)

        wanted = _load_settings().get("theme") or HUD_THEME
        if wanted not in THEMES:
            wanted = "orb"
        try:
            self.load_theme(wanted)
        except Exception:
            log.exception("HUD: theme %r failed to load; falling back to orb", wanted)
            self.load_theme("orb")
        root.update()
        log.info("HUD ready: theme=%s, dpi scale %.2f", self.theme_name, self.scale)
        try:   # shows up in the Jarvis launcher log: handy if the orb ever starts in the wrong place
            print("HUD: screen %dx%d, work area %s, scale %.2f, window at (%d,%d) size %dx%d" % (
                self.sw, self.sh, _work_area(self.sw, self.sh), self.scale,
                root.winfo_x(), root.winfo_y(), root.winfo_width(), root.winfo_height()), flush=True)
        except Exception:
            pass

    # ---- services for themes ---------------------------------------------
    def set_window_alpha(self, a):
        a = min(1.0, max(0.02, a))
        if abs(a - self.alpha_set) < 0.008 and a not in (0.02, 1.0):
            return
        self.alpha_set = a
        try:
            self.root.attributes("-alpha", a)
        except Exception:
            pass

    def set_geometry(self, x, y, w, h):
        self.root.geometry("%dx%d+%d+%d" % (w, h, x, y))
        self.cv.configure(width=w, height=h)

    def move_window(self, x, y):
        self.root.geometry("+%d+%d" % (x, y))

    def window_xy(self):
        return self.root.winfo_x(), self.root.winfo_y()

    def work_area(self):
        return _work_area(self.sw, self.sh)

    def raise_topmost(self):
        if self._win is None:
            return
        try:
            from ctypes import wintypes
            u, hwnd = self._win
            u.SetWindowPos(hwnd, wintypes.HWND(-1), 0, 0, 0, 0, _SWP_FLAGS)
        except Exception:
            pass

    def set_clickthrough(self, on):
        if self._win is None:
            return
        try:
            from ctypes import wintypes
            u, hwnd = self._win
            style = u.GetWindowLongW(hwnd, _GWL_EXSTYLE)
            style = (style | _WS_EX_TRANSPARENT) if on else (style & ~_WS_EX_TRANSPARENT)
            u.SetWindowLongW(hwnd, _GWL_EXSTYLE, style)
            u.SetWindowPos(hwnd, wintypes.HWND(0), 0, 0, 0, 0, _SWP_NOZORDER_FLAGS)
        except Exception as e:
            log.warning("HUD: could not toggle click-through: %r", e)

    # ---- themes -------------------------------------------------------------
    def load_theme(self, name):
        import hud_animations                       # lazy: hud.py is fully loaded by now
        new = hud_animations.THEMES[name](self)
        x, y, w, h = new.window_rect()
        if self.theme is not None:
            self.theme.destroy()
        self.cv.delete("all")
        self.theme, self.theme_name = None, None
        self.alpha_set = -1.0
        self.set_window_alpha(0.02)
        self.set_geometry(x, y, w, h)
        self.set_clickthrough(True)
        new.build()
        self.theme, self.theme_name = new, name
        _STATUS["theme"] = name

    def switch_theme(self, name=None):
        """Switch to `name` (or the next one). Returns True on success. A broken
        theme is rolled back to the previous one; Jarvis never notices."""
        order = list(THEMES)
        if name is None:
            i = order.index(self.theme_name) if self.theme_name in order else -1
            name = order[(i + 1) % len(order)]
        if name not in order:
            return False
        if name == self.theme_name:
            return True
        prev = self.theme_name
        try:
            self.load_theme(name)
        except Exception:
            log.exception("HUD: theme %r failed; keeping %r", name, prev)
            try:
                self.load_theme(prev or "orb")
            except Exception:
                log.exception("HUD: could not restore theme %r", prev)
            return False
        upd = {"theme": name}
        if name != "none":
            upd["last_visible"] = name
        elif prev and prev != "none":
            upd["last_visible"] = prev              # so "show animation" can bring it back
        _save_settings(**upd)
        log.info("HUD theme switched: %s -> %s", prev, name)
        return True

    # ---- the "view" interface the state machine talks to ----------------
    def _fwd(self, method, e):
        th = self.theme
        if th is not None:
            getattr(th, method)(e)

    def show_state(self, name, spec, text, now):
        self.theme.show_state(name, spec, text, now)

    def set_message(self, text, now):
        self.theme.set_message(text, now)

    def frame(self, spec, t, now):
        self.theme.frame(spec, t, now)

    def busy(self):
        return self.theme.busy()

    def fps(self, spec):
        return self.theme.fps(spec)

    def show_heard(self, text, now):
        self.theme.show_heard(text, now)

    def hide_heard(self):
        self.theme.hide_heard()

    def set_movable(self, on):
        self.theme.set_movable(on)

    def can_move(self):
        return bool(self.theme and self.theme.movable)

    def reset_position(self):
        self.theme.reset_position()

    def pump(self):
        self.root.update()

    def close(self):
        try:
            self.root.destroy()
        except Exception:
            pass
        self.root = None


# =====================================================================
# STATE MACHINE  (pure logic; talks to a "view" object)
# =====================================================================
class _Machine:
    def __init__(self, view, clock=time.monotonic):
        self.view = view
        self.clock = clock
        self.state = "STANDBY"
        self.spec = STATES["STANDBY"]
        self.base = "STANDBY"          # last steady (non-transient) state
        self.pending = None            # steady request held back during a transient/hold
        self.entered = clock()
        self.next_frame = 0.0
        self.transient_until = None    # transient playing, or EXECUTING minimum-hold
        self.hold = False              # True when transient_until is an EXECUTING hold
        self.msg_until = None
        self.watchdog_at = None
        self.heard_until = None
        self.cur_text = None
        self.moving = False
        self.move_until = None
        self.move_before = "STANDBY"
        self.before_speaking = "STANDBY"
        self.before_exec = "STANDBY"
        self.exec_depth = 0
        view.show_state("STANDBY", self.spec, None, self.entered)

    # -- commands from Jarvis -----------------------------------------
    def handle(self, cmd):
        op = cmd[0]
        if op == "state":
            self.request(cmd[1], cmd[2])
        elif op == "theme":
            self._switch_theme(cmd[1])
        elif op == "theme_next":
            self._switch_theme(None)
        elif op == "theme_show":
            self._show_animation()
        elif op == "move":
            self._toggle_move()
        elif op == "move_done":
            self._end_move(self.clock())
        elif op == "reset_pos":
            self.view.reset_position()
        elif op == "heard":
            if HEARD_TEXT_ENABLED and cmd[1]:
                self.view.show_heard(cmd[1], self.clock())
                self.heard_until = self.clock() + HEARD_TEXT_SECONDS
        elif op == "speak_on":
            if self.state != "SPEAKING":
                b = self._logical_base()
                if b == "EXECUTING":            # speech began during an action / its hold
                    b = self.before_exec
                elif b == "SPEAKING":
                    b = "STANDBY"
                self.before_speaking = b
            self.request("SPEAKING", None)
        elif op == "speak_off":
            self._restore(self.before_speaking, only_if="SPEAKING")
        elif op == "exec_on":
            if self.exec_depth == 0:
                b = self._logical_base()
                self.before_exec = b if b != "EXECUTING" else "THINKING"
            self.exec_depth += 1
            if self.hold:                       # a new action arrived during the minimum hold
                self.hold, self.transient_until, self.pending = False, None, None
            self.request("EXECUTING", cmd[1])
        elif op == "exec_off":
            self.exec_depth = max(0, self.exec_depth - 1)
            if self.exec_depth == 0:
                self._restore(self.before_exec, only_if="EXECUTING")

    def _logical_base(self):
        """The steady state Jarvis is 'really' in (looks through move mode)."""
        if self.moving:
            if self.pending and self.pending[0] not in ("SPEAKING", "EXECUTING"):
                return self.pending[0]
            return self.move_before
        return self.base

    def _switch_theme(self, name):
        now = self.clock()
        if self.moving:
            self._end_move(now)
        if not self.view.switch_theme(name):
            return
        self.next_frame = now
        self.view.show_state(self.state, self.spec, self.cur_text, now)     # redraw in the new look
        if self.state == "STANDBY":
            self.request("SUCCESS")                                         # brief preview flash

    def _show_animation(self):
        """Bring back the theme that was on screen before it was hidden."""
        last = _load_settings().get("last_visible")
        if last not in THEMES or last == "none":
            last = HUD_THEME if HUD_THEME in THEMES and HUD_THEME != "none" else "orb"
        self._switch_theme(last)

    def _toggle_move(self):
        now = self.clock()
        if self.moving:
            self._end_move(now)
            return
        if not self.view.can_move():
            return                                   # e.g. the 'none' theme has nothing to drag
        b = self.base
        self.move_before = "STANDBY" if b in ("SPEAKING", "EXECUTING", "MOVE") else b
        self.moving = True
        self.move_until = now + MOVE_MODE_SECONDS
        self.pending, self.transient_until, self.hold = None, None, False
        self._enter("MOVE", None, now)
        self.view.set_movable(True)

    def _end_move(self, now):
        if not self.moving:
            return
        self.moving = False
        self.move_until = None
        self.view.set_movable(False)
        name, msg = self.pending or (self.move_before, None)
        self.pending = None
        self._enter(name, msg, now)

    def _restore(self, target, only_if):
        now = self.clock()
        if self.moving:                      # while dragging, Jarvis' updates just queue up
            if self.pending is not None and self.pending[0] == only_if:
                self.pending = (target, None)
            return
        if self.transient_until is not None:
            # a flash/hold is playing: just remember where to go afterwards
            if self.pending is None or self.pending[0] == only_if:
                self.pending = (target, None)
        elif self.state == only_if:
            if only_if == "EXECUTING" and MIN_EXECUTING_SECONDS > 0:
                remaining = self.entered + MIN_EXECUTING_SECONDS - now
                if remaining > 0:               # visual only: nothing in Jarvis waits
                    self.pending = (target, None)
                    self.transient_until = now + remaining
                    self.hold = True
                    return
            self.request(target, None)

    def request(self, name, message=None):
        spec = STATES.get(name)
        if spec is None:
            log.warning("HUD: unknown state %r ignored", name)
            return
        now = self.clock()
        steady = spec["duration"] is None
        if name == "MOVE":
            return                                   # only the hotkey / hud.move_mode() starts it
        if self.moving:
            if steady:
                self.pending = (name, message)       # applied when move mode ends
            return
        if name == "STANDBY" and self.state == "STANDBY":
            return                                   # Jarvis re-sends this while idle
        if steady and name != "CONFIRMATION" and self.transient_until is not None:
            self.pending = (name, message)           # let the flash/hold finish first
            return
        if steady and name == self.state:
            self._show_message(message if message is not None else spec["text"], now, spec)
            return
        self._enter(name, message, now)

    def _enter(self, name, message, now):
        spec = STATES[name]
        self.state, self.spec = name, spec
        self.entered = now
        self.next_frame = now
        self.hold = False
        if spec["duration"] is not None:
            self.transient_until = now + spec["duration"]
            self.watchdog_at = None
        else:
            self.transient_until = None
            self.base = name
            self.pending = None
            self.watchdog_at = None if name == "STANDBY" else now + WATCHDOG_SECONDS
        text = message if message is not None else spec["text"]
        self.cur_text = text
        self.msg_until = None if (spec["sticky"] or not text or spec["duration"] is not None) \
            else now + STATUS_TEXT_SECONDS
        if name == "STANDBY":
            self.heard_until = None
        if HUD_DEBUG:
            log.info("HUD STATE: %s MESSAGE: %s", name, text)
        self.view.show_state(name, spec, text, now)

    def _show_message(self, text, now, spec):
        self.cur_text = text
        self.msg_until = None if (spec["sticky"] or not text) else now + STATUS_TEXT_SECONDS
        self.view.set_message(text, now)

    # -- time-driven work ---------------------------------------------
    def wait_time(self):
        """Seconds until the next thing needs doing, or None if nothing does."""
        now = self.clock()
        c = []
        if self.spec["kind"] != "static" or self.view.busy():
            c.append(self.next_frame - now)
        for deadline in (self.transient_until, self.msg_until, self.watchdog_at, self.heard_until,
                         self.move_until):
            if deadline is not None:
                c.append(deadline - now)
        return max(0.0, min(c)) if c else None

    def tick(self):
        now = self.clock()
        if self.transient_until is not None and now >= self.transient_until:
            if self.pending is not None:
                name, msg = self.pending
            else:
                name, msg = (self.base if self.base in ("STANDBY", "LISTENING", "THINKING",
                                                        "CONFIRMATION") else "STANDBY"), None
            self.pending = None
            self.transient_until = None
            self.hold = False
            self._enter(name, msg, now)
            return
        if self.move_until is not None and now >= self.move_until:
            self._end_move(now)
            return
        if self.heard_until is not None and now >= self.heard_until:
            self.heard_until = None
            self.view.hide_heard()
        if self.msg_until is not None and now >= self.msg_until:
            self.msg_until = None
            self.cur_text = None
            self.view.set_message(None, now)
        if self.watchdog_at is not None and now >= self.watchdog_at:
            log.warning("HUD watchdog: %s unchanged for %ss -> STANDBY", self.state, WATCHDOG_SECONDS)
            self._enter("STANDBY", None, now)
            return
        if (self.spec["kind"] != "static" or self.view.busy()) and now >= self.next_frame:
            self.view.frame(self.spec, now - self.entered, now)
            self.next_frame = now + 1.0 / self.view.fps(self.spec)


# =====================================================================
# MANAGER  (owns the HUD thread; the only thing Jarvis talks to)
# =====================================================================
class _Manager:
    def __init__(self):
        self._q = queue.SimpleQueue()
        self._ready = threading.Event()
        self._ok = False
        self._hk = {}
        self._thread = threading.Thread(target=self._run, name="jarvis-hud", daemon=True)

    def start(self):
        self._thread.start()
        self._ready.wait(timeout=5.0)
        keys = [(HUD_MOVE_HOTKEY, ("move",)), (HUD_THEME_HOTKEY, ("theme_next",))]
        if self._ok and os.name == "nt" and any(k for k, _ in keys):
            try:
                threading.Thread(target=_hotkey_loop, args=(keys, self.post, self._hk),
                                 name="jarvis-hud-hotkey", daemon=True).start()
            except Exception:
                log.exception("HUD: could not start the hotkey thread")
        return self._ok

    def post(self, cmd):
        if self._ok:
            self._q.put(cmd)

    def stop(self):
        try:
            tid = self._hk.get("tid")
            if tid and os.name == "nt":
                _user32().PostThreadMessageW(tid, 0x0012, 0, 0)       # WM_QUIT ends the hotkey thread
        except Exception:
            pass
        if self._ok:
            self._q.put(("stop",))
            self._thread.join(timeout=2.0)

    def _run(self):
        view = machine = None
        try:
            view = _Overlay(notify=self._q.put)
            machine = _Machine(view)
            self._ok = True
        except Exception:
            log.exception("HUD failed to initialise; Jarvis continues without it")
            self._ready.set()
            if view is not None:
                view.close()
            return
        self._ready.set()

        failures = 0
        try:
            while True:
                timeout = machine.wait_time()
                if timeout is None:
                    timeout = HEARTBEAT_SECONDS          # may be None -> block forever
                try:
                    cmd = self._q.get(timeout=timeout)
                except queue.Empty:
                    cmd = None
                try:
                    while cmd is not None:
                        if cmd[0] == "stop":
                            return
                        machine.handle(cmd)
                        try:
                            cmd = self._q.get_nowait()
                        except queue.Empty:
                            cmd = None
                    machine.tick()
                    view.pump()
                    failures = 0
                except Exception:
                    failures += 1
                    log.exception("HUD loop error (%d)", failures)
                    if failures >= 5:
                        log.error("HUD disabled after repeated errors")
                        return
        finally:
            self._ok = False
            try:
                if view is not None:
                    view.close()
            finally:
                # Tk objects must die in THIS thread. Themes and the host reference each
                # other (a cycle), so drop them and collect here; otherwise Python frees
                # them later in the main thread and Tcl aborts the process at exit
                # ("Tcl_AsyncDelete: async handler deleted by the wrong thread").
                view = machine = None
                import gc
                gc.collect()


_manager = None


# =====================================================================
# PUBLIC API  (safe to call from any thread, never raises)
# =====================================================================
def start():
    """Start the HUD thread. Returns True if the overlay is running."""
    global _manager
    if not HUD_ENABLED or _manager is not None:
        return _manager is not None
    try:
        m = _Manager()
        if m.start():
            _manager = m
            atexit.register(stop)
            return True
        log.warning("HUD not running (see earlier error); Jarvis continues normally")
    except Exception:
        log.exception("HUD start failed")
    return False


def stop():
    global _manager
    m, _manager = _manager, None
    try:
        if m:
            m.stop()
    except Exception:
        pass


def _post(cmd):
    try:
        m = _manager
        if m:
            m.post(cmd)
    except Exception:
        pass


def set_state(state, message=None):
    _post(("state", str(state).upper(), message))


def success():
    set_state("SUCCESS")


_THEME_WORDS = (("wave dock", "wave"), ("equalizer", "wave"), ("wave", "wave"), ("dock", "wave"),
                ("bars", "wave"), ("orb", "orb"), ("core", "orb"), ("ball", "orb"), ("capsule", "orb"),
                ("none", "none"), ("invisible", "none"), ("hidden", "none"), ("nothing", "none"))


_STATUS = {"theme": None}


def current_theme():
    """Name of the theme on screen ('orb', 'wave', 'none') or None."""
    return _STATUS.get("theme")


def theme_names():
    return list(THEMES)


def resolve_theme(text):
    """'wave dock' / 'the orb one' -> 'wave' / 'orb' (None if unknown)."""
    import re
    t = str(text).lower()
    for word, name in _THEME_WORDS:
        if re.search(r"\b" + word + r"\b", t):
            return name
    return None


def set_theme(name):
    """Switch the look: 'orb', 'wave' or 'none' (words like 'wave dock' work too)."""
    n = resolve_theme(name)
    if n:
        _post(("theme", n))
    return n


def next_theme():
    _post(("theme_next",))


def hide():
    """Make the HUD invisible (the 'none' theme). Jarvis itself is unaffected."""
    _post(("theme", "none"))


def show():
    """Bring back whatever theme was visible before hide()."""
    _post(("theme_show",))


def move_mode():
    """Toggle move mode (same as the hotkey): drag the widget, then let go."""
    _post(("move",))


def reset_position():
    """Put the widget back at the default position and forget the saved one."""
    _post(("reset_pos",))


def heard(text):
    """Show what Jarvis recognised, briefly. Visual only."""
    _post(("heard", str(text)))


def speaking_start():
    _post(("speak_on",))


def speaking_end():
    _post(("speak_off",))


def executing_begin(message=None):
    _post(("exec_on", message))


def executing_end():
    _post(("exec_off",))


# =====================================================================
# TOOL WRAPPING  (EXECUTING + friendly message while an action really runs)
# =====================================================================
_MESSAGES = {
    "open_app": "Opening {name}...", "open_app_tool": "Opening {name}...",
    "close_app": "Closing {name}...", "close_app_tool": "Closing {name}...",
    "is_app_installed_tool": "Checking apps...", "app_count_tool": "Checking apps...",
    "open_folder_tool": "Opening {name}...", "open_file_tool": "Opening {name}...",
    "find_file_tool": "Searching files...", "search_folder_tool": "Searching files...",
    "show_file_location_tool": "Searching files...", "list_files_tool": "Listing files...",
    "move_or_copy_file_tool": "Moving files...", "copy_or_move_to_path_tool": "Moving files...",
    "rename_file_tool": "Renaming file...", "duplicate_file_tool": "Copying file...",
    "create_folder_tool": "Creating folder...", "delete_file_tool": "Deleting file...",
    "delete_folder_tool": "Deleting folder...",
    "take_screenshot": "Taking screenshot...", "take_screenshot_tool": "Taking screenshot...",
    "ask_about_screen_tool": "Looking at your screen...", "copy_screen_text_tool": "Reading your screen...",
    "toggle_screen_recording_tool": "Screen recording...",
    "get_system_performance_tool": "Checking system...", "get_cpu_temperature_tool": "Checking system...",
    "get_battery_tool": "Checking system...", "get_storage_tool": "Checking system...",
    "get_temperature_summary": "Checking system...", "get_performance_summary": "Checking system...",
    "get_current_wifi_tool": "Checking Wi-Fi...", "connect_to_wifi_tool": "Connecting to Wi-Fi...",
    "wifi_radio_on_tool": "Changing Wi-Fi...", "wifi_radio_off_tool": "Changing Wi-Fi...",
    "bluetooth_on_tool": "Changing Bluetooth...", "bluetooth_off_tool": "Changing Bluetooth...",
    "night_light_on_tool": "Changing display...", "night_light_off_tool": "Changing display...",
    "focus_assist_on_tool": "Changing settings...", "focus_assist_off_tool": "Changing settings...",
    "set_volume_tool": "Adjusting volume...", "mute_tool": "Adjusting volume...",
    "unmute_tool": "Adjusting volume...", "set_volume_percent": "Adjusting volume...",
    "adjust_volume": "Adjusting volume...", "set_mute": "Adjusting volume...",
    "set_brightness_tool": "Changing brightness...",
    "lock_pc_tool": "Locking PC...", "lock_pc": "Locking PC...",
    "shutdown_pc_tool": "Shutting down...", "shutdown_pc": "Shutting down...",
    "restart_pc_tool": "Restarting...", "restart_pc": "Restarting...",
    "sleep_pc_tool": "Going to sleep...", "sleep_pc": "Going to sleep...",
    "cancel_shutdown_tool": "Cancelling shutdown...", "cancel_shutdown": "Cancelling shutdown...",
    "empty_recycle_bin_tool": "Emptying recycle bin...", "empty_recycle_bin": "Emptying recycle bin...",
    "show_desktop_tool": "Showing desktop...", "show_desktop": "Showing desktop...",
    "play_song_tool": "Playing music...", "play_song": "Playing music...",
    "get_weather_tool": "Checking weather...",
    "call_contact_tool": "Calling {name}...", "send_whatsapp_message_tool": "Sending message...",
    "type_text_tool": "Typing...", "paste_code_tool": "Typing...", "press_keys_tool": "Pressing keys...",
    "read_clipboard_tool": "Using clipboard...", "save_clipboard_tool": "Using clipboard...",
    "set_clipboard_tool": "Using clipboard...", "copy_file_to_clipboard_tool": "Using clipboard...",
    "start_timer_tool": "Setting timer...", "list_timers_tool": "Checking timers...",
    "cancel_timer_tool": "Cancelling timer...", "add_reminder_tool": "Setting reminder...",
    "list_reminders_tool": "Checking reminders...",
    "add_note_tool": "Saving note...", "list_notes_tool": "Checking notes...",
    "add_todo_tool": "Updating to-do list...", "list_todos_tool": "Checking to-do list...",
    "complete_todo_tool": "Updating to-do list...",
    "remember_name_tool": "Remembering...", "remember_fact_tool": "Remembering...",
    "get_name_tool": "Remembering...", "recall_fact_tool": "Remembering...",
}


def _friendly_message(fn, args, kwargs):
    template = _MESSAGES.get(fn.__name__, "Working...")
    if "{name}" not in template:
        return template
    name = ""
    try:
        bound = inspect.signature(fn).bind_partial(*args, **kwargs)
        for v in bound.arguments.values():       # first string argument
            if isinstance(v, str) and v.strip():
                name = v.strip()[:24].title()
                break
    except Exception:
        pass
    return template.format(name=name) if name else template.replace(" {name}", "")


def wrap_tool(fn):
    """Wrap an action so the HUD shows EXECUTING while it runs. Keeps the
    original name, docstring and signature (the Gemini tool schema is built
    from them). If anything goes wrong the original function is returned."""
    try:
        if getattr(fn, "_hud_wrapped", False) or not callable(fn):
            return fn

        @functools.wraps(fn)
        def _wrapped(*args, **kwargs):
            try:
                executing_begin(_friendly_message(fn, args, kwargs))
            except Exception:
                pass
            try:
                return fn(*args, **kwargs)
            finally:
                executing_end()

        _wrapped._hud_wrapped = True
        return _wrapped
    except Exception:
        return fn


def wrap_tools(fns):
    return [wrap_tool(f) for f in fns]
