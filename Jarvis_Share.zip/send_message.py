"""
send_message.py -- WhatsApp text messaging automation for Jarvis.

Reuses the contact-search-and-open-chat logic from call_contact.py (the
same window connection, raw SendInput typing, etc.) instead of
duplicating that hard-won debugging work -- see call_contact.py's own
docstring for the history of why it's built this way.

This module only adds what calling doesn't need: finding the message
input box (bottom of the open chat, NOT the sidebar search box) and
sending the message.

r3 FIX -- the real reason the header check kept failing:
call_contact.SIDEBAR_WIDTH_FRACTION (0.4) is fine for finding the
sidebar search box, but it was ALSO used as the left edge of the chat
pane. On a ~1900px-wide window that's x~760, while the sidebar really
ends near x~545. The contact's name in the chat header (and every
incoming message bubble) sits between x~545 and x~760, so it was being
filtered out before it was ever looked at -- only right-aligned,
outgoing items survived. r3 computes the chat pane's left edge from
the sidebar search box itself (its right edge + CHAT_PANE_MARGIN), so
it works at any window size.

r4 -- auto-launch. If WhatsApp is closed (or minimized to the tray),
the script now starts it itself and waits for the chat list to appear
before searching. It launches via the "whatsapp:" URI, NOT a file
path: the Store version lives in C:\\Program Files\\WindowsApps, which
is permission-locked and whose folder name changes with every update,
so a hard-coded path would break. The URI works no matter where
Windows installed it. (Fallback: shell:AppsFolder with the app's
package family name.) Allow up to ~30s when it has to cold-start.

r10 -- all header-checking code has been DELETED (not just switched off):
no VERIFY_HEADER flag, no header scan, no "chat header doesn't show..."
message. The first console line prints the version AND the file path, so
you can tell instantly if Jarvis is running an older send_message.py.

r9 -- all name COMPARISON removed from the send step. After the top
search result is pressed, the script only waits for keyboard focus to
land in a message box (any chat's), then clears it, types and sends. It
no longer checks the message box's name against the contact, so there is
no waiting, no mismatch warning and no scan when a name was misspelled.
(resolve_contact from r8 only rewrites the text typed into the SEARCH
box; to switch it off, empty KNOWN_CONTACTS and CONTACT_ALIASES.)

r8 -- misheard names. Speech recognition often spells a contact wrong
("balaji the rice"), the WhatsApp search then finds nothing (or the
wrong person), and the name never matches the chat's message box.
resolve_contact() maps what Jarvis heard to the real WhatsApp name using
KNOWN_CONTACTS (fuzzy match) and CONTACT_ALIASES (exact nicknames /
repeat mishearings). ADD YOUR CONTACTS TO KNOWN_CONTACTS below. Also: if
the chat that opened has a message box whose name doesn't match (e.g.
you clicked the right chat yourself), it now sends to the open chat
after ~3s with a warning, instead of scanning for 20+ seconds.

r7 -- speed. Every UI-tree scan of WhatsApp's Electron/WebView window can
take several seconds, and r6 did ~5 of them per message. r7 does ONE:
  * already-open WhatsApp is used as-is (no "is the UI ready" scan; that
    scan only runs right after launching/restoring it);
  * the sidebar search box is found with a single scan, not two;
  * the message box is found WITHOUT scanning: after a chat is opened
    from search, WhatsApp leaves keyboard focus in that chat's message
    box ("Type a message to <contact>"), which is read with one direct
    UIA call. Only if that fails does it fall back to the old scan.
Each step now prints elapsed seconds, e.g. "[  7.3s] top result pressed",
so any remaining slow step is visible.

r6 -- before typing, the message box is cleared (Ctrl+A, Backspace) so a
leftover draft can't be sent together with the new message.

r5 -- header verification is now OFF by default (VERIFY_HEADER = False).
The script searches the name, presses the top result, finds the message
box and sends. Set VERIFY_HEADER = True to turn the safety check back on.

Header verification (when VERIFY_HEADER is True): the contact's name must
appear in a control inside the header band (any control type) before
anything is typed. If it doesn't, the script prints everything it can
see in that band and refuses to send.

ASSUMPTION -- the message box's accessible name. WhatsApp Desktop's
message input is labeled "Type a message" (ControlType=Edit) in the
screenshot, but this has NOT been confirmed with Accessibility
Insights. If sending fails with "Could not find the message box", the
console output prints what it found at the bottom of the chat -- update
MESSAGE_BOX_TITLE below with the real name.

TIP: use the full contact name ("Balaji The Rise", not "Balaji") so the
DOWN+ENTER fallback can never land on a different similarly-named chat.

Usage (standalone test):
    python send_message.py "Balaji The Rise" "running 10 minutes late"

Safe test -- types the message into the box but does NOT press Enter:
    python send_message.py "Balaji The Rise" "test" --dry-run

Integration into jarvis_up.py:
    from send_message import send_message
    ...
    if t.startswith("send a message to ") or t.startswith("message "):
        ...
"""

import difflib
import os
import re
import subprocess
import sys
import time

from call_contact import (
    Application,
    _visible_matches, _read_search_box_text, _clear_search_box,
    _send_text, _send_vk, _VK_DOWN, _VK_RETURN,
    SIDEBAR_WIDTH_FRACTION,
)

try:
    import win32gui
    HAVE_WIN32GUI = True
except ImportError:
    HAVE_WIN32GUI = False

SCRIPT_VERSION = "r14-contacts-file"

# After clicking "Voice call", should we hand focus back to the window you were
# using? False = leave WhatsApp's call window in front (you want to talk, not
# have it pushed behind). Messages always restore your previous window.
RESTORE_WINDOW_AFTER_CALL = False

# Jarvis runs hidden (pythonw), so print() output is invisible in voice mode.
# Everything this module prints is ALSO appended to send_message.log next to
# this file, so a failed voice send can be diagnosed afterwards.
_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "send_message.log")
_builtin_print = print


def print(*args, **kwargs):  # noqa: A001  (intentional shadow, module-local)
    _builtin_print(*args, **kwargs)
    try:
        with open(_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + " ".join(str(a) for a in args) + "\n")
    except Exception:
        pass


MESSAGE_BOX_TITLE = "Type a message"

# --- Contact name resolution -------------------------------------------
# Your contacts and nicknames live in contacts.py (NOT in this file), so
# updating send_message.py never wipes your list again.
try:
    from contacts import KNOWN_CONTACTS, CONTACT_ALIASES
except ImportError:
    KNOWN_CONTACTS, CONTACT_ALIASES = [], {}
    print("[send_message] contacts.py not found next to send_message.py -- "
          "no contacts/aliases loaded.")

# Real WhatsApp names only: these are what the fuzzy matcher compares against.
_REAL_NAMES = list(KNOWN_CONTACTS)

# Speech hints: Jarvis hands KNOWN_CONTACTS to the speech recognizer so it
# spells names right. Add every alias word to that list too, so Whisper is
# nudged to write "Thozha" instead of guessing "tola". (resolve_contact()
# uses _REAL_NAMES above, so these extra words never become search targets.)
_have = {n.lower() for n in KNOWN_CONTACTS}
for _alias in CONTACT_ALIASES:
    if _alias.lower() not in _have:
        KNOWN_CONTACTS.append(_alias.title())
        _have.add(_alias.lower())

FUZZY_CUTOFF = 0.75  # 0..1; higher = stricter name matching


def _norm_name(s):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", "", (s or "").lower())).strip()


def resolve_contact(spoken):
    """Maps a spoken/misheard name to a real WhatsApp contact name.
    Order: exact alias -> exact known name -> fuzzy match on known names.
    Returns the original text if nothing matches well enough."""
    key = _norm_name(spoken)
    if not key:
        return spoken
    for alias, real in CONTACT_ALIASES.items():
        if _norm_name(alias) == key:
            return real
    names = {_norm_name(n): n for n in _REAL_NAMES}
    if key in names:
        return names[key]
    close = difflib.get_close_matches(key, list(names), n=1, cutoff=FUZZY_CUTOFF)
    if close:
        return names[close[0]]
    return spoken


# Height (pixels up from the bottom of the window) of the compose area.
COMPOSE_BAND_HEIGHT = 150

# Gap between the sidebar search box's right edge and the start of the
# chat pane. Search box right edge ~520 and sidebar edge ~545 on a
# 1900px-wide window, so ~25px.
CHAT_PANE_MARGIN = 25


# --- Launching WhatsApp when it's closed -------------------------------
# The "whatsapp:" URI is registered by the Store app, so Windows finds
# and starts it wherever it's installed (and brings it to the front if
# it's already running in the tray).
WHATSAPP_URI = "whatsapp:"
WHATSAPP_APPSFOLDER = r"shell:AppsFolder\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"
LAUNCH_TIMEOUT = 30  # seconds to wait for WhatsApp to open and render


def _connect_whatsapp():
    app = Application(backend="uia").connect(title_re=".*WhatsApp.*")
    return app, app.top_window()


def _launch_whatsapp():
    """Ask Windows to start/show WhatsApp. Returns True if a launch
    request was made (not a guarantee the window is up yet)."""
    try:
        os.startfile(WHATSAPP_URI)
        return True
    except Exception as e:
        print(f"[send_message] whatsapp: URI launch failed ({e}); trying AppsFolder fallback")
    try:
        subprocess.Popen(["explorer.exe", WHATSAPP_APPSFOLDER])
        return True
    except Exception as e:
        print(f"[send_message] AppsFolder launch failed too ({e})")
    return False


def _ensure_whatsapp_open(timeout=LAUNCH_TIMEOUT):
    """Returns (app, win) once WhatsApp is open AND its chat UI has
    rendered (a visible Edit control exists), launching it if needed.
    Returns None if that doesn't happen within `timeout` seconds."""
    launched = False
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            app, win = _connect_whatsapp()
            was_minimized = False
            try:
                if win.is_minimized():
                    win.restore()
                    was_minimized = True
            except Exception:
                pass
            if not launched and not was_minimized:
                return app, win  # already open and showing: skip the slow UI scan
            if _visible_matches(win, control_type="Edit"):
                time.sleep(0.5)  # let the UI settle
                return app, win
        except Exception:
            pass
        if not launched:
            print("[send_message] WhatsApp isn't open (or isn't showing) — launching it...")
            _launch_whatsapp()
            launched = True
        time.sleep(1.0)
    return None


def _focused_element_name():
    """Accessible name of whichever control currently has keyboard focus,
    via ONE direct UIA call (milliseconds -- no tree scan). Returns ""
    if it can't be read."""
    try:
        from pywinauto.uia_defines import IUIA
        return IUIA().iuia.GetFocusedElement().CurrentName or ""
    except Exception:
        return ""


def _focused_wrapper():
    """pywinauto wrapper around whichever control has keyboard focus (one
    direct UIA call, no tree scan), or None."""
    try:
        from pywinauto.uia_defines import IUIA
        from pywinauto.uia_element_info import UIAElementInfo
        from pywinauto.controls.uiawrapper import UIAWrapper
        return UIAWrapper(UIAElementInfo(IUIA().iuia.GetFocusedElement()))
    except Exception:
        return None


def _composer_text(box=None):
    """Current text of the message box ('' if empty / unreadable).
    Uses `box` if given, else the focused control."""
    box = box or _focused_wrapper()
    if box is None:
        return ""
    try:
        v, tp = _read_search_box_text(box)
        return (v or tp or "").strip()
    except Exception:
        return ""


def _send_enter_scancode():
    """Enter as a hardware-style key event (scan code), in case WhatsApp's
    composer ignores the plain virtual-key Enter."""
    import ctypes
    from call_contact import _INPUT, _KEYBDINPUT, _INPUT_KEYBOARD, _KEYEVENTF_KEYUP
    KEYEVENTF_SCANCODE = 0x0008
    sc = ctypes.windll.user32.MapVirtualKeyW(_VK_RETURN, 0)
    extra = ctypes.c_ulong(0)
    down = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(0, sc, KEYEVENTF_SCANCODE, 0, ctypes.pointer(extra)))
    up = _INPUT(type=_INPUT_KEYBOARD, ki=_KEYBDINPUT(0, sc, KEYEVENTF_SCANCODE | _KEYEVENTF_KEYUP, 0, ctypes.pointer(extra)))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(down), ctypes.sizeof(_INPUT))
    ctypes.windll.user32.SendInput(1, ctypes.pointer(up), ctypes.sizeof(_INPUT))


def _wait_cleared(box, probe, timeout=1.5):
    """True once the composer no longer contains the typed text (= sent)."""
    end = time.time() + timeout
    while time.time() < end:
        if probe not in _composer_text(box).lower():
            return True
        time.sleep(0.15)
    return False


def _filter_cached(elements, max_left=None, min_left=None, control_type=None, title=None):
    """Filters an ALREADY-FETCHED element list (one win.descendants()
    call) instead of asking UIA to walk the tree again. WhatsApp's
    Electron/WebView UI tree is large enough that repeating a fresh
    scan for every lookup was the actual source of most of the runtime.
    Scan once per UI-state-change, then filter the same cached list."""
    matches = []
    for cand in elements:
        try:
            if control_type is not None and cand.element_info.control_type != control_type:
                continue
            if title is not None and cand.element_info.name != title:
                continue
            rect = cand.rectangle()
            if not cand.is_visible():
                continue
            if rect.width() <= 0 or rect.height() <= 0:
                continue
            if max_left is not None and rect.left > max_left:
                continue
            if min_left is not None and rect.left < min_left:
                continue
            matches.append(cand)
        except Exception:
            continue
    return matches


def _dump_band(elements, label, chat_left, top_min, top_max, limit=40):
    """Diagnostic: print every visible control (including UNNAMED ones)
    whose top edge is inside [top_min, top_max] and that sits in the
    chat pane. Used when a lookup fails so the console shows exactly
    what WhatsApp is exposing."""
    print(f"[send_message] --- {label} (x >= {chat_left}, y {top_min}..{top_max}) ---")
    shown = 0
    for cand in elements:
        if shown >= limit:
            print("[send_message]   ... (more not shown)")
            break
        try:
            if not cand.is_visible():
                continue
            r = cand.rectangle()
            if r.width() <= 0 or r.height() <= 0:
                continue
            if r.left < chat_left or r.top < top_min or r.top > top_max:
                continue
            ei = cand.element_info
            print(f"[send_message]   {str(ei.control_type):10} name={ei.name!r} "
                  f"class={ei.class_name!r} auto_id={ei.automation_id!r} "
                  f"rect=({r.left},{r.top},{r.right},{r.bottom})")
            shown += 1
        except Exception:
            continue


def send_message(contact: str, message: str = None, dry_run: bool = False,
                 call: bool = False) -> bool:
    """Blind flow: (launch WhatsApp if closed) -> search the name -> open
    whatever result is on top -> then, depending on the mode:
        message given -> type it + Enter
        call=True     -> click the chat header's "Voice call" button
        neither       -> just leave the chat open
    No name/header comparison anywhere."""
    print(f"[send_message] Script version: {SCRIPT_VERSION}  file: {os.path.abspath(__file__)}"
          f"{' (DRY RUN: will type but not send)' if dry_run else ''}")
    resolved = resolve_contact(contact)
    if resolved != contact:
        print(f"[send_message] Resolved heard name '{contact}' -> '{resolved}'")
        contact = resolved
    t_start = time.time()

    def lap(label):
        print(f"[send_message] [{time.time() - t_start:5.1f}s] {label}")

    original_hwnd = None
    if HAVE_WIN32GUI:
        try:
            original_hwnd = win32gui.GetForegroundWindow()
        except Exception:
            original_hwnd = None

    opened = _ensure_whatsapp_open()
    if opened is None:
        print(f"[send_message] Couldn't get WhatsApp open and showing its chat list within "
              f"{LAUNCH_TIMEOUT}s. Open it manually (and make sure you're logged in, not on the "
              f"QR screen) and try again.")
        return False
    app, win = opened
    print(f"[send_message] Connected to window: '{win.window_text()}'")
    lap("window ready")

    try:
        win.set_focus()
        time.sleep(0.15)

        win_rect = win.rectangle()
        # Only used to LOCATE the sidebar search box (it's well left of
        # this). NOT used as the chat pane's left edge -- see r3 note.
        sidebar_cutoff = win_rect.left + int(win_rect.width() * SIDEBAR_WIDTH_FRACTION)

        # --- Step 1: find and use the sidebar contact search (same
        # approach as call_contact.py) ---
        all_edits = list(win.descendants(control_type="Edit"))  # the ONLY tree scan
        search_candidates = _filter_cached(
            all_edits, max_left=sidebar_cutoff, title="Search or start a new chat",
        )
        if not search_candidates:
            search_candidates = _filter_cached(all_edits, max_left=sidebar_cutoff)
        if not search_candidates:
            print("[send_message] Sidebar search box not found -- is WhatsApp on the Chats screen?")
            return False

        search_box = search_candidates[0]
        lap("search box located")
        box_rect = search_box.rectangle()
        center_x = (box_rect.left + box_rect.right) // 2
        center_y = (box_rect.top + box_rect.bottom) // 2

        # The chat pane starts just right of the sidebar search box.
        chat_left = box_rect.right + CHAT_PANE_MARGIN
        print(f"[send_message] Chat pane starts at x={chat_left} "
              f"(window left={win_rect.left}, width={win_rect.width()})")

        contact_lower = contact.strip().lower()
        landed = False
        after_value = after_textpattern = ""

        for attempt in range(2):
            settle = 0.15 if attempt == 0 else 0.4
            key_pause = 0.02 if attempt == 0 else 0.05

            search_box.click_input(coords=(center_x - box_rect.left, center_y - box_rect.top))
            time.sleep(settle)

            try:
                _clear_search_box(pause=key_pause)
            except Exception as e:
                print(f"[send_message] Clearing search box raised an exception: {e}")
            time.sleep(0.05)

            try:
                _send_text(contact, pause=key_pause)
            except Exception as e:
                print(f"[send_message] Raw SendInput typing raised an exception: {e}")

            time.sleep(0.25 if attempt == 0 else 0.5)

            after_value, after_textpattern = _read_search_box_text(search_box)
            landed = (contact_lower in after_value.lower()) or (contact_lower in after_textpattern.lower())
            if landed:
                break
            if attempt == 0:
                print(f"[send_message] Typing didn't land on attempt {attempt + 1}, retrying")

        if not landed:
            print(f"[send_message] Typed text did not land in the search box after retrying. Aborting.")
            return False

        # --- Step 2: press the top search result (DOWN + ENTER). ---
        time.sleep(0.3)  # let filtered results finish rendering
        _send_vk(_VK_DOWN)
        time.sleep(0.15)
        _send_vk(_VK_RETURN)
        print(f"[send_message] Pressed the top search result for '{contact}'.")
        lap("top result pressed")

        # --- Step 4: get into the message box. NO name comparison of any
        # kind: after pressing the top result, wait until keyboard focus
        # lands in a chat's message box ("Type a message ..."), whatever
        # chat that is, then type and send. Focus is read with one direct
        # UIA call (no tree scan). ---
        message_box = None
        composer_focused = False
        for _ in range(15):  # up to ~3s for the chat to open
            time.sleep(0.2)
            if "type a message" in _focused_element_name().lower():
                composer_focused = True
                break

        if composer_focused:
            print("[send_message] Message box has focus.")
        else:
            # Focus isn't in a message box (the fast path doesn't apply on
            # this machine): fall back to clicking the lowest Edit control
            # in the chat pane, which is the message box.
            print("[send_message] Focus isn't in a message box -- scanning for it.")
            for _ in range(6):
                time.sleep(0.5)
                edits = list(win.descendants(control_type="Edit"))
                candidates = _filter_cached(edits, min_left=chat_left)
                if candidates:
                    message_box = max(candidates, key=lambda c: c.rectangle().top)
                    break

            if message_box is None:
                print("[send_message] Could not find the message box after opening the chat.")
                chat_elements = list(win.descendants())
                _dump_band(chat_elements, "compose area, ALL controls",
                           chat_left, win_rect.bottom - COMPOSE_BAND_HEIGHT, win_rect.bottom)
                return False

            print(f"[send_message] Using message box: '{message_box.element_info.name}'")

            msg_rect = message_box.rectangle()
            message_box.click_input(coords=(
                (msg_rect.left + msg_rect.right) // 2 - msg_rect.left,
                (msg_rect.top + msg_rect.bottom) // 2 - msg_rect.top,
            ))
        lap("message box ready")
        time.sleep(0.15)

        if call:
            # Same pipeline as messaging up to here; the last step is the
            # header's "Voice call" button instead of typing. (Groups/other
            # builds may label it plain "Call".)
            wanted = ("voice call", "call", "start voice call")
            btns, elements = [], []
            for _ in range(8):               # header can still be rendering
                elements = list(win.descendants(control_type="Button"))
                in_chat = _filter_cached(elements, min_left=chat_left)
                btns = [b for b in in_chat if (b.element_info.name or "").strip().lower() in wanted]
                if btns:
                    break
                time.sleep(0.4)
            if not btns:
                seen = [(b.element_info.name or "") for b in _filter_cached(elements, min_left=chat_left)][:20]
                print(f"[send_message] No 'Voice call' button in the chat header. Buttons seen: {seen}")
                return False
            btn = min(btns, key=lambda b: b.rectangle().top)   # the header one, not a lower one
            btn.click_input()
            print(f"[send_message] Voice call started to '{contact}'.")
            lap("call button clicked")
            return True

        if not message:                      # "open X's chat": done, nothing to type
            print(f"[send_message] Opened the top result for '{contact}'.")
            return True

        # Make sure WhatsApp really is the foreground window; SendInput goes
        # to the foreground window only. (When Jarvis runs hidden, Windows'
        # foreground lock can stop set_focus() from working.)
        try:
            if HAVE_WIN32GUI and win32gui.GetForegroundWindow() != win.handle:
                print("[send_message] WhatsApp isn't foreground -- forcing it forward.")
                try:
                    win.set_focus()
                except Exception:
                    pass
                time.sleep(0.2)
        except Exception:
            pass

        # Re-grab the composer as a wrapper so we can READ it back.
        box = message_box or _focused_wrapper()
        if "type a message" not in (box.element_info.name.lower() if box else ""):
            print(f"[send_message] Focused control is '{box.element_info.name if box else None}', "
                  f"not the message box -- clicking the composer.")
            edits = list(win.descendants(control_type="Edit"))
            cands = _filter_cached(edits, min_left=chat_left)
            if cands:
                box = max(cands, key=lambda c: c.rectangle().top)
                r = box.rectangle()
                box.click_input(coords=((r.left + r.right) // 2 - r.left, (r.top + r.bottom) // 2 - r.top))
                time.sleep(0.25)

        try:
            _clear_search_box(pause=0.03)
        except Exception as e:
            print(f"[send_message] Clearing the message box raised an exception: {e}")
        time.sleep(0.15)

        probe = message.strip().lower()[:12]
        typed_ok = False
        for attempt in range(2):
            try:
                _send_text(message, pause=0.02)
            except Exception as e:
                print(f"[send_message] Typing the message raised an exception: {e}")
                return False
            time.sleep(0.3)
            if probe in _composer_text(box).lower():
                typed_ok = True
                break
            print(f"[send_message] Typed text NOT visible in the message box (attempt {attempt + 1}); "
                  f"box reads {_composer_text(box)!r}. Re-clicking and retrying.")
            try:
                r = box.rectangle()
                box.click_input(coords=((r.left + r.right) // 2 - r.left, (r.top + r.bottom) // 2 - r.top))
            except Exception:
                pass
            time.sleep(0.3)
            _clear_search_box(pause=0.03)
            time.sleep(0.15)
        if not typed_ok:
            print("[send_message] The message never appeared in the message box -- not sending.")
            return False
        lap("message typed")

        if dry_run:
            print(f"[send_message] DRY RUN: typed the message into '{contact}'s box but did NOT "
                  f"press Enter. Clear the box yourself (Ctrl+A, Backspace).")
            return True

        # --- Send, and VERIFY (composer empties when WhatsApp accepts it) ---
        time.sleep(0.2)
        _send_vk(_VK_RETURN)
        if not _wait_cleared(box, probe):
            print("[send_message] Enter (virtual key) didn't send; trying scan-code Enter.")
            _send_enter_scancode()
            if not _wait_cleared(box, probe):
                print("[send_message] Enter didn't send; clicking the Send button.")
                btns = _filter_cached(list(win.descendants(control_type="Button")),
                                      min_left=chat_left, title="Send")
                if btns:
                    btns[0].click_input()
                    if not _wait_cleared(box, probe, timeout=2.0):
                        print("[send_message] Send button clicked but the text is still in the box.")
                        return False
                else:
                    print("[send_message] No 'Send' button found; message NOT sent.")
                    return False
        print(f"[send_message] Message sent to '{contact}'.")
        lap("done")
        return True

    finally:
        if HAVE_WIN32GUI and original_hwnd and (RESTORE_WINDOW_AFTER_CALL or not call):
            try:
                time.sleep(0.2)
                win32gui.SetForegroundWindow(original_hwnd)
            except Exception as e:
                print(f"[send_message] (Couldn't restore previous window — {e})")


def call_whatsapp_contact(contact: str) -> bool:
    """Voice-call a contact through the same pipeline as send_message()."""
    return send_message(contact, call=True)


if __name__ == "__main__":
    if "--call" in sys.argv[1:]:
        who = " ".join(a for a in sys.argv[1:] if a != "--call")
        if not who:
            print("Usage: python send_message.py --call <contact name>")
            sys.exit(1)
        print("Done." if call_whatsapp_contact(who) else "Failed — see messages above.")
        sys.exit(0)
    dry = "--dry-run" in sys.argv[1:]
    args = [a for a in sys.argv[1:] if a != "--dry-run"]
    if len(args) < 2:
        print('Usage: python send_message.py <contact name> "<message>" [--dry-run]')
        sys.exit(1)
    name = args[0]
    msg = " ".join(args[1:])
    result = send_message(name, msg, dry_run=dry)
    print("Done." if result else "Failed — see messages above.")
