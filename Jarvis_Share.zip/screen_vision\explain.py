"""
explain.py -- L2: sends OCR'd TEXT (not the screenshot image) to
Gemini for understanding/explanation. Cheaper and faster than the
vision tier (L3) since text tokens are far lighter than image tokens --
this is the tier for "what does this mean" / "explain this error"
style questions where OCR already got usable text.

Same API key already loaded for llm_brain.py's Gemini model (.env /
GEMINI_API_KEY). Uses gemini-3.1-flash-lite for consistency with the
rest of this project.

SDK NOTE (migrated 2026-09): uses the `google-genai` package
(`from google import genai`), not the older, deprecated
`google-generativeai` package -- see llm_brain.py's SDK NOTE for the
full old-vs-new API shape if you're used to the old one.
"""

import os
from pathlib import Path

from google import genai
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

MODEL_NAME = "gemini-3.1-flash-lite"

_client = None


def _get_client():
    """Returns the google-genai Client, creating it once. Replaces the
    old SDK's genai.configure() + genai.GenerativeModel(model_name=...)
    pair -- the new SDK has no separate per-model object; the model
    name is only specified per-call, at generate_content() time."""
    global _client
    if _client is not None:
        return _client

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        return None

    _client = genai.Client(api_key=api_key)
    return _client


def ask_about_text(screen_text: str, question: str) -> str:
    """Answers a question about text already extracted from the
    screen via OCR. Text-only Gemini call -- no image involved."""
    client = _get_client()
    if client is None:
        return "I don't have a Gemini API key set up."

    prompt = (
        f"Here is text extracted from the user's screen:\n\n{screen_text}\n\n"
        f"Question: {question.strip() or 'Briefly explain what this shows.'}\n\n"
        "Answer in 1-3 short spoken sentences -- this will be read aloud, "
        "so no markdown, no lists, no asterisks."
    )

    try:
        response = client.models.generate_content(model=MODEL_NAME, contents=prompt)
        return response.text.strip()
    except Exception as e:
        return f"I couldn't process that: {e}"
