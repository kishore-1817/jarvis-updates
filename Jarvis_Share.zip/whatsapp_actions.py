"""
whatsapp_actions.py -- WhatsApp Desktop action layer for Jarvis.

    HEAR -> UNDERSTAND -> LOCATE -> ACT -> VERIFY -> RESPOND

This does NOT replace call_contact.py / send_message.py. It imports their
proven helpers (raw SendInput typing, sidebar-vs-header position logic,
_visible_matches, _filter_cached) and adds what they lack:

  * the send is SPLIT from the typing: open chat -> verify recipient ->
    type -> verify the typed text -> ASK -> (yes) re-verify -> send ->
    verify it really appeared in the chat
  * ambiguity: several similar contacts -> ask, never guess
  * every step returns / logs a clear status; "sent" is only claimed when
    a NEW message bubble with that text is actually seen afterwards

Locate method priority (WhatsApp Desktop has no API / no send shortcut):
    1. Windows UI Automation (pywinauto)  -- search box, result rows,
       header, message box   [primary]
    2. OCR of the screen (screen_vision.cache, local winocr) -- only as
       second evidence that a sent message appeared
    3. Gemini Vision -- NOT used here at all.

Confirmation reuses file_manager.start_confirmation / start_choice (the
existing pending yes/no slot that jarvis_up.py already checks first on
every command, and that the HUD already shows as CONFIRMATION).

ACTION_TEST_MODE = True  -> only checks that WhatsApp and its search box can
be found; nothing is clicked, typed or sent.

Diagnostic:  python whatsapp_actions.py --dump   (prints what UIA sees)
"""

import difflib
import os
import re
import time
from contextlib import contextmanager

import file_manager
from action_types import ActionResult, ActionStatus, Stopwatch, log_event
from call_contact import (
    Application,
    _visible_matches, _read_search_box_text, _clear_search_box,
    _send_text, _send_vk, _VK_DOWN, _VK_RETURN,
    SIDEBAR_WIDTH_FRACTION,
)
from send_message import _filter_cached, MESSAGE_BOX_TITLE, CHAT_PANE_MARGIN

try:
    import win32gui
    HAVE_WIN32GUI = True
except ImportError:
    HAVE_WIN32GUI = False

# ---------------------------------------------------------------------
# Settings (easy to change / disable)
# ---------------------------------------------------------------------
ACTION_TEST_MODE = False        # True: locate only, never click/type/send
LAUNCH_TIMEOUT = 15             # seconds to wait for WhatsApp after launching it
DRAFT_TTL_SECONDS = 120         # a staged message expires if not confirmed in time
SEND_VERIFY_TIMEOUT = 5.0       # seconds to wait for the sent bubble to show up
MAX_CHOICES = 5

# ---------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------
_INVISIBLE = dict.fromkeys(map(ord, "\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u200b"), None)


def _norm(s) -> str:
    """lowercase, drop invisible direction marks, collapse whitespace."""
    return re.sub(r"\s+", " ", (s or "").translate(_INVISIBLE)).strip().lower()


FUZZY_NAME_CUTOFF = 0.80   # 0..1; spelling tolerance for contact names


def _name_matches(query: str, text: str) -> bool:
    """True if `query` is in `text`, OR closely matches a run of words in it.
    WhatsApp's own search is spelling-tolerant ("tarun" finds "Tharun RMK
    COLLEGE"), so a plain substring check wrongly rejected the chat it had
    just correctly opened."""
    q, t = _norm(query), _norm(text)
    if not q or not t:
        return False
    if q in t:
        return True
    words, n = t.split(), len(q.split())
    for size in {n, n + 1}:
        for i in range(0, max(0, len(words) - size) + 1):
            cand = " ".join(words[i:i + size])
            if cand and difflib.SequenceMatcher(None, q, cand).ratio() >= FUZZY_NAME_CUTOFF:
                return True
    return False


def _row_label(text: str) -> str:
    """Best-effort contact name from a sidebar row's accessible text
    (rows usually read 'Name, last message, time...'). UNCONFIRMED on a
    real machine -- run `python whatsapp_actions.py --dump` to check."""
    first = re.split(r"[\r\n]|,\s", (text or "").translate(_INVISIBLE).strip())[0].strip()
    return first or (text or "").strip()


def _hud(state: str, message: str = None):
    """Map action phases onto EXISTING HUD states (the HUD has no
    LOCATING/VERIFYING of its own; the message text carries the phase)."""
    try:
        import hud
        hud.set_state(state, message)
    except Exception:
        pass


# ---------------------------------------------------------------------
# UI layer -- every direct touch of the WhatsApp window lives here, so the
# logic below can be tested against a fake.
# ---------------------------------------------------------------------
def _try_connect():
    try:
        app = Application(backend="uia").connect(title_re=".*WhatsApp.*")
        return app.top_window()
    except Exception:
        return None


class WhatsAppUI:
    def __init__(self):
        self.win = None
        self.cutoff = 0
        self.chat_left = 0          # left edge of the CHAT pane (see locate_search_box)
        self._elements = []

    # -- connect / focus ------------------------------------------------
    def connect(self, launch: bool = False):
        """Returns SUCCESS, NOT_FOUND (not running), or TIMEOUT (launched
        but window never appeared)."""
        win = _try_connect()
        status = ActionStatus.SUCCESS
        if win is None:
            if not launch:
                return ActionStatus.NOT_FOUND
            try:
                os.startfile("whatsapp:")      # same launcher APP_INDEX uses
            except Exception:
                return ActionStatus.NOT_FOUND
            deadline = time.monotonic() + LAUNCH_TIMEOUT
            while time.monotonic() < deadline and win is None:
                time.sleep(0.5)
                win = _try_connect()
            if win is None:
                return ActionStatus.TIMEOUT
            time.sleep(1.5)                    # let the chat list render
        self.win = win
        r = win.rectangle()
        self.cutoff = r.left + int(r.width() * SIDEBAR_WIDTH_FRACTION)
        return status

    @contextmanager
    def foreground(self):
        """Bring WhatsApp forward (real keystrokes need the foreground),
        restore the user's previous window afterwards."""
        orig = None
        if HAVE_WIN32GUI:
            try:
                orig = win32gui.GetForegroundWindow()
            except Exception:
                pass
        try:
            self.win.set_focus()
            time.sleep(0.15)
            r = self.win.rectangle()
            self.cutoff = r.left + int(r.width() * SIDEBAR_WIDTH_FRACTION)
            yield
        finally:
            if HAVE_WIN32GUI and orig:
                try:
                    time.sleep(0.2)
                    win32gui.SetForegroundWindow(orig)
                except Exception:
                    pass

    # -- sidebar search ---------------------------------------------------
    def locate_search_box(self):
        c = (_visible_matches(self.win, max_left=self.cutoff,
                              title="Search or start a new chat", control_type="Edit")
             or _visible_matches(self.win, max_left=self.cutoff, control_type="Edit"))
        if c:
            # The chat pane starts just right of the sidebar. The 40%-of-width
            # `cutoff` is only good for FINDING the search box: on a wide
            # window it lies INSIDE the chat pane (x~766 vs. real edge ~560),
            # which hid the chat header and the message box from every lookup.
            self.chat_left = c[0].rectangle().right + CHAT_PANE_MARGIN
        return c[0] if c else None

    def _ensure_chat_left(self):
        if not self.chat_left:
            self.locate_search_box()
        if not self.chat_left:                    # last resort
            self.chat_left = self.cutoff

    def type_in_search(self, query: str) -> bool:
        box = self.locate_search_box()
        if box is None:
            return False
        rect = box.rectangle()
        cx, cy = (rect.left + rect.right) // 2, (rect.top + rect.bottom) // 2
        q = _norm(query)
        for attempt in range(2):
            settle = 0.15 if attempt == 0 else 0.4
            pause = 0.02 if attempt == 0 else 0.05
            box.click_input(coords=(cx - rect.left, cy - rect.top))
            time.sleep(settle)
            try:
                _clear_search_box(pause=pause)
                time.sleep(0.05)
                _send_text(query, pause=pause)
            except Exception:
                return False
            time.sleep(0.25 if attempt == 0 else 0.5)
            v, tp = _read_search_box_text(box)
            if q in _norm(v) or q in _norm(tp):
                return True
        return False

    def result_rows(self):
        """[(label, full_text, handle)] for visible sidebar list rows."""
        rows = []
        for r in _visible_matches(self.win, max_left=self.cutoff, control_type="ListItem"):
            try:
                text = r.window_text() or ""
            except Exception:
                text = ""
            rows.append((_row_label(text), text, r))
        return rows

    def click_row(self, handle):
        handle.click_input()

    def keyboard_pick_first(self):
        _send_vk(_VK_DOWN)
        time.sleep(0.15)
        _send_vk(_VK_RETURN)

    # -- chat pane ----------------------------------------------------------
    def header_texts(self):
        """Texts of header Text/Button controls on the chat side. One live
        scan; the element list is cached for message_box()."""
        self._ensure_chat_left()
        self._elements = list(self.win.descendants())
        out = []
        for c in (_filter_cached(self._elements, min_left=self.chat_left, control_type="Text")
                  + _filter_cached(self._elements, min_left=self.chat_left, control_type="Button")):
            try:
                t = c.window_text()
            except Exception:
                t = ""
            if t and t not in out:
                out.append(t)
        return out

    def message_box(self):
        """The compose box: the LOWEST Edit control in the chat pane (named
        'Type a message', or 'Type a message to <name>')."""
        self._ensure_chat_left()
        els = self._elements or list(self.win.descendants())
        edits = _filter_cached(els, min_left=self.chat_left, control_type="Edit")
        named = [c for c in edits
                 if (c.element_info.name or "").lower().startswith(MESSAGE_BOX_TITLE.lower())]
        pool = named or edits
        if not pool:
            log_event("ACTION_FAILURE", "no message box found",
                      chat_left=self.chat_left, edits_seen=len(edits))
            return None
        return max(pool, key=lambda c: c.rectangle().top)

    def read_box(self):
        """(value_pattern_text, text_pattern_text) of the message box."""
        box = self.message_box()
        if box is None:
            return None
        return _read_search_box_text(box)

    def clear_box(self):
        box = self.message_box()
        if box is None:
            return False
        self._click_center(box)
        _clear_search_box()
        return True

    def type_into_box(self, text: str) -> bool:
        box = self.message_box()
        if box is None:
            return False
        self._click_center(box)
        time.sleep(0.15)
        _clear_search_box()                    # WhatsApp keeps old drafts
        time.sleep(0.05)
        _send_text(text, pause=0.02)
        time.sleep(0.25)
        return True

    def press_enter(self):
        _send_vk(_VK_RETURN)

    @staticmethod
    def _click_center(el):
        r = el.rectangle()
        el.click_input(coords=((r.left + r.right) // 2 - r.left,
                               (r.top + r.bottom) // 2 - r.top))

    # -- evidence that a message really is in the chat -------------------------
    def count_in_chat_uia(self, snippet: str) -> int:
        self._ensure_chat_left()
        n = 0
        for c in self.win.descendants():
            try:
                if c.element_info.control_type == "Edit":
                    continue
                if snippet in _norm(c.element_info.name) and c.rectangle().left >= self.chat_left:
                    n += 1
            except Exception:
                continue
        return n

    def count_in_chat_ocr(self, snippet: str) -> int:
        try:
            from screen_vision import cache            # existing L1 capture + OCR
            _img, text, _w = cache.get_capture_and_text(force_refresh=True)
            return _norm(text).count(snippet)
        except Exception:
            return 0


_new_ui = WhatsAppUI        # tests replace this with a fake


# ---------------------------------------------------------------------
# Logic layer
# ---------------------------------------------------------------------
class _Choice:
    """Quacks like the Path objects file_manager._parse_choice_index expects
    (it matches the reply against `.parent.name`, and falls back to
    'first/second/1/2')."""
    def __init__(self, label):
        self.label = label
        self.name = _norm(label)
        self.parent = self


def _open_chat(ui, contact: str, exact_label: str = None) -> ActionResult:
    """Search -> pick row -> VERIFY the chat header. Assumes WhatsApp is in
    the foreground (caller holds ui.foreground())."""
    sw = Stopwatch()
    query = exact_label or contact
    q = _norm(query)

    log_event("ACTION_LOCATING", f"contact '{query}'", method="UIA sidebar search")
    _hud("EXECUTING", f"Finding {query}...")

    if not ui.type_in_search(query):
        return ActionResult(ActionStatus.FAILED,
                            "I couldn't use WhatsApp's search box. Is it on the Chats screen?",
                            detail="search typing did not land", elapsed=sw.lap())
    time.sleep(0.3)

    distinct = {}
    for label, text, handle in ui.result_rows():
        if q in _norm(label) or q in _norm(text) or _name_matches(q, label):
            distinct.setdefault(_norm(label), (label, handle))

    chosen = None
    if len(distinct) > 1:
        exact = [v for k, v in distinct.items() if k == q]
        if len(exact) == 1:
            chosen = exact[0]
        else:
            labels = [v[0] for v in distinct.values()][:MAX_CHOICES]
            log_event("ACTION_FAILURE", f"ambiguous contact '{query}'", detail=labels)
            return ActionResult(ActionStatus.AMBIGUOUS, "", data={"labels": labels},
                                elapsed=sw.lap())
    elif len(distinct) == 1:
        chosen = next(iter(distinct.values()))

    log_event("ACTION_EXECUTING", f"open chat '{chosen[0] if chosen else query}'",
              method="click row" if chosen else "keyboard fallback")
    if chosen:
        ui.click_row(chosen[1])
    else:
        ui.keyboard_pick_first()
    time.sleep(0.6)

    # VERIFY -- never trust that the click opened the right chat.
    log_event("ACTION_VERIFYING", "chat header")
    _hud("EXECUTING", "Checking the chat...")
    needle = _norm(chosen[0]) if chosen else q
    header = ui.header_texts()
    match = next((h for h in header if _name_matches(needle, h)), None)
    if match is None:
        if chosen is None:
            return ActionResult(ActionStatus.NOT_FOUND,
                                f"I couldn't find a chat named {contact}.",
                                detail=f"no row, header={header[:10]}", elapsed=sw.lap())
        return ActionResult(ActionStatus.FAILED,
                            "The chat that opened doesn't look like the right one, so I stopped.",
                            detail=f"header={header[:10]}", elapsed=sw.lap())
    return ActionResult(ActionStatus.SUCCESS, f"Opened {match}'s chat.",
                        method="UIA", data={"name": match}, elapsed=sw.lap())


def _box_has(ui, message: str):
    """True/False whether the message box currently holds exactly `message`;
    None if the box can't be read."""
    r = ui.read_box()
    if r is None:
        return None
    m = _norm(message)
    return m in (_norm(r[0]), _norm(r[1]))


# --- staged draft (module state; one at a time) ------------------------------
_draft = None


def _draft_valid() -> bool:
    return _draft is not None and (time.monotonic() - _draft["t"]) <= DRAFT_TTL_SECONDS


def _connect_ui(launch: bool):
    ui = _new_ui()
    st = ui.connect(launch=launch)
    return ui, st


def _not_running_msg(st) -> str:
    if st == ActionStatus.TIMEOUT:
        return "I opened WhatsApp but it took too long to appear."
    return "WhatsApp doesn't seem to be open."


# --- public: open a chat --------------------------------------------------------
def open_chat(contact: str, exact_label: str = None) -> str:
    sw = Stopwatch()
    contact = contact.strip()
    log_event("ACTION_REQUEST", f"Open WhatsApp chat: {contact}")
    if not contact:
        return "Whose chat should I open?"

    ui, st = _connect_ui(launch=not ACTION_TEST_MODE)
    if st != ActionStatus.SUCCESS:
        log_event("ACTION_FAILURE", "WhatsApp unavailable", result=st.value)
        _hud("ERROR")
        return _not_running_msg(st)

    if ACTION_TEST_MODE:
        return _test_mode_report(ui, f"open {contact}'s chat")

    with ui.foreground():
        res = _open_chat(ui, contact, exact_label)

    if res.status == ActionStatus.AMBIGUOUS:
        return _ask_which(contact, res.data["labels"], lambda label: open_chat(contact, label))
    if res.ok:
        log_event("ACTION_SUCCESS", res.message, method=res.method, execution_time=f"{sw.lap()}s")
        _hud("SUCCESS")
        return res.message
    log_event("ACTION_FAILURE", res.message, result=res.status.value, detail=res.detail)
    _hud("ERROR")
    return res.message


def _ask_which(contact, labels, on_label) -> str:
    spoken = ", ".join(f"{i}. {l}" for i, l in enumerate(labels, 1))
    prompt = f"I found more than one match for {contact}: {spoken}. Which one?"
    return file_manager.start_choice(prompt, [_Choice(l) for l in labels],
                                     lambda chosen: on_label(chosen.label))


# --- public: stage a message (does NOT send) ---------------------------------------
def stage_message(contact: str, message: str, exact_label: str = None) -> str:
    """Open the chat, verify the recipient, type the message, verify the
    typed text, then ASK. Nothing is sent here. Returns the spoken prompt
    (or an error sentence)."""
    global _draft
    sw = Stopwatch()
    contact, message = contact.strip(), message.strip()
    log_event("ACTION_REQUEST", f"WhatsApp message to '{contact}'", chars=len(message))
    if not contact:
        return "Who should I message?"
    if not message:
        return f"What should I say to {contact}?"
    _draft = None
    _hud("THINKING", "Planning...")
    log_event("ACTION_PLANNING", "connect > open chat > verify > type > verify > confirm > send > verify")

    ui, st = _connect_ui(launch=not ACTION_TEST_MODE)
    if st != ActionStatus.SUCCESS:
        log_event("ACTION_FAILURE", "WhatsApp unavailable", result=st.value)
        _hud("ERROR")
        return _not_running_msg(st)

    if ACTION_TEST_MODE:
        return _test_mode_report(ui, f"message {contact}")

    box_found, verified = None, None
    with ui.foreground():
        res = _open_chat(ui, contact, exact_label)
        if res.ok:
            name = res.data["name"]
            log_event("ACTION_EXECUTING", "typing message", method="SendInput")
            _hud("EXECUTING", "Typing...")
            box_found = ui.type_into_box(message)
            if box_found:
                log_event("ACTION_VERIFYING", "typed text")
                _hud("EXECUTING", "Checking the text...")
                verified = _box_has(ui, message)

    if res.status == ActionStatus.AMBIGUOUS:
        return _ask_which(contact, res.data["labels"],
                          lambda label: stage_message(contact, message, label))
    if not res.ok:
        log_event("ACTION_FAILURE", res.message, result=res.status.value, detail=res.detail)
        _hud("ERROR")
        return res.message
    if verified is not True:
        why = ("I couldn't find the message box." if not box_found
               else "I couldn't confirm that the message was typed correctly.")
        log_event("ACTION_FAILURE", why, result="FAILED")
        _hud("ERROR")
        return why + " Nothing was sent."

    _draft = {"name": name, "message": message, "t": time.monotonic()}
    log_event("ACTION_VERIFYING", "draft ready, waiting for confirmation",
              result=ActionStatus.NEEDS_CONFIRMATION.value, execution_time=f"{sw.lap()}s")
    return file_manager.start_confirmation(
        f"The message to {name} is ready: {message}. Send it?",
        on_yes=_send_draft, on_no=_cancel_draft)


# --- confirmed: send + verify ------------------------------------------------------
def _send_draft() -> str:
    global _draft
    d, _draft = _draft, None                   # consume first: can never double-send
    sw = Stopwatch()
    if d is None or (time.monotonic() - d["t"]) > DRAFT_TTL_SECONDS:
        log_event("ACTION_FAILURE", "draft expired or missing", result="CANCELLED")
        return "That message draft has expired, so I didn't send anything."
    name, message = d["name"], d["message"]
    log_event("ACTION_REQUEST", f"confirmed: send to '{name}'")

    ui, st = _connect_ui(launch=False)
    if st != ActionStatus.SUCCESS:
        return _not_running_msg(st) + " Nothing was sent."

    snippet = _norm(message)[:40]
    with ui.foreground():
        # Re-verify EVERYTHING -- the UI may have changed since we asked.
        log_event("ACTION_VERIFYING", "recipient + draft before sending")
        _hud("EXECUTING", "Checking before sending...")
        if not any(_norm(name) in _norm(h) for h in ui.header_texts()):
            log_event("ACTION_FAILURE", "chat changed before send", result="FAILED")
            _hud("ERROR")
            return f"The open chat is no longer {name}'s, so I didn't send anything."
        if _box_has(ui, message) is not True:
            log_event("ACTION_FAILURE", "message box changed before send", result="FAILED")
            _hud("ERROR")
            return "The text in the message box changed, so I didn't send anything."

        uia_before = ui.count_in_chat_uia(snippet)
        ocr_before = ui.count_in_chat_ocr(snippet) if uia_before == 0 else None

        log_event("ACTION_EXECUTING", "pressing Enter in message box", method="SendInput")
        _hud("EXECUTING", "Sending...")
        ui.press_enter()

        log_event("ACTION_VERIFYING", "new message bubble")
        _hud("EXECUTING", "Verifying...")
        evidence = None
        box_cleared = False
        deadline = time.monotonic() + SEND_VERIFY_TIMEOUT
        while time.monotonic() < deadline:
            time.sleep(0.5)
            if ui.count_in_chat_uia(snippet) > uia_before:
                evidence = "UIA"
                break
            if _box_has(ui, message) is False:
                box_cleared = True
                if ocr_before is not None and ui.count_in_chat_ocr(snippet) > ocr_before:
                    evidence = "OCR"
                    break

    if evidence:
        log_event("ACTION_SUCCESS", f"sent to '{name}'", method="Enter", verification=evidence,
                  execution_time=f"{sw.lap()}s")
        _hud("SUCCESS")
        return f"Sent to {name}."
    if box_cleared:
        log_event("ACTION_FAILURE", "box cleared but bubble not seen", result=ActionStatus.UNVERIFIED.value)
        _hud("ERROR")
        return (f"I pressed send and the box cleared, but I couldn't see the message in "
                f"{name}'s chat, so I can't confirm it was delivered. Please check.")
    log_event("ACTION_FAILURE", "message still in box after Enter", result=ActionStatus.TIMEOUT.value)
    _hud("ERROR")
    return f"I pressed send but the message is still in the box, so it may not have gone out. Please check {name}'s chat."


def _cancel_draft(reason: str = "no") -> str:
    """'no' -> clear the typed text out of WhatsApp too. 'dropped' (user moved
    on to another command) -> just forget the draft, don't grab focus."""
    global _draft
    d, _draft = _draft, None
    log_event("ACTION_FAILURE", "draft cancelled", result=ActionStatus.CANCELLED.value, reason=reason)
    if d and reason == "no":
        try:
            ui, st = _connect_ui(launch=False)
            if st == ActionStatus.SUCCESS:
                with ui.foreground():
                    if (any(_norm(d["name"]) in _norm(h) for h in ui.header_texts())
                            and _box_has(ui, d["message"]) is True):
                        ui.clear_box()
        except Exception:
            pass
    return "Okay, I won't send it."


# ---------------------------------------------------------------------
# Test mode + diagnostics
# ---------------------------------------------------------------------
def _test_mode_report(ui, what: str) -> str:
    box = ui.locate_search_box()
    log_event("ACTION_LOCATING", "TEST MODE", found_search_box=box is not None)
    if box is None:
        return "Test mode: I found WhatsApp but not its search box. Nothing was clicked."
    return (f"Test mode: I found WhatsApp and its search box. I would {what}, "
            f"but test mode is on, so I didn't click, type or send anything.")


def dump_ui():
    """Prints what UI Automation can see. Run with WhatsApp open on the Chats
    screen; then search a name in WhatsApp and run again."""
    ui = _new_ui()
    st = ui.connect(launch=False)
    if st != ActionStatus.SUCCESS:
        print("WhatsApp not found."); return
    print("cutoff x =", ui.cutoff)
    print("search box:", ui.locate_search_box())
    print("--- sidebar rows (label | full text) ---")
    for label, text, _h in ui.result_rows()[:15]:
        print(repr(label), "|", repr(text[:100]))
    print("--- header texts ---")
    print(ui.header_texts()[:25])
    print("message box:", ui.message_box())


if __name__ == "__main__":
    import sys
    if "--dump" in sys.argv:
        dump_ui()
    else:
        print('usage: python whatsapp_actions.py --dump')
