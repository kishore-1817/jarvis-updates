"""
window_commands.py -- voice control for Windows windows (Command Router domain).

Handles (all spoken text arrives lowercased):
    "snap left" / "push right" / "snap this right" / "push top left" / "snap bottom right"
        (tolerates mishearings: "sanp lift", "nop right", "snap write", "push left" ...)
    "maximize" / "minimize" / "restore"            (the window you're using)
    "minimize all" / "show desktop"                 / "restore all windows"
    "switch to chrome" / "focus vs code" / "bring up whatsapp"
    "switch window" / "next window"                 (Alt+Tab)
    "move this to the next monitor"
    "close this window"                             (Alt+F4: the app still asks
                                                     about unsaved work itself)
    "task view" / "new desktop" / "next desktop" / "previous desktop" /
    "close this desktop" / "full screen"
    "what windows are open"

It does NOT touch "open <app>" or "close <app>" -- those stay with your
existing handlers (open launches an app, close kills its process).

Hook it up exactly like whatsapp_commands.py: call
    window_commands.try_handle(text, speak)
from the command router; it returns True when it handled the command.

Standalone test (no voice needed; prints instead of speaking):
    python window_commands.py "snap left"
    python window_commands.py "switch to chrome"
"""

import ctypes
import difflib
import os
import re
import sys
import time
from ctypes import wintypes

try:
    import win32con
    import win32gui
    import win32process
    HAVE_WIN32 = True
except ImportError:          # not on Windows / pywin32 missing
    HAVE_WIN32 = False

try:
    import psutil
except ImportError:
    psutil = None

FUZZY_CUTOFF = 0.80          # spelling tolerance for "switch to <app>"

# ---------------------------------------------------------------- keys ----
VK_LWIN, VK_MENU, VK_CONTROL, VK_SHIFT = 0x5B, 0x12, 0x11, 0x10
VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN = 0x25, 0x26, 0x27, 0x28
VK_TAB, VK_F4, VK_F11, VK_D = 0x09, 0x73, 0x7A, 0x44
_EXTENDED = {VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN}

_INPUT_KEYBOARD = 1
_KEYEVENTF_EXTENDEDKEY = 0x0001
_KEYEVENTF_KEYUP = 0x0002


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", wintypes.WPARAM)]


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", wintypes.WPARAM)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", _MOUSEINPUT), ("ki", _KEYBDINPUT), ("hi", _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


def _key(vk, up=False):
    flags = (_KEYEVENTF_EXTENDEDKEY if vk in _EXTENDED else 0) | (_KEYEVENTF_KEYUP if up else 0)
    inp = _INPUT(type=_INPUT_KEYBOARD)
    inp.ki = _KEYBDINPUT(vk, 0, flags, 0, 0)
    ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))


def _hotkey(*vks):
    """Press the keys together (in order), then release in reverse."""
    for vk in vks:
        _key(vk)
        time.sleep(0.02)
    for vk in reversed(vks):
        _key(vk, up=True)
        time.sleep(0.02)


# ------------------------------------------------------------- windows ----
_SHELL_CLASSES = {"Shell_TrayWnd", "Shell_SecondaryTrayWnd", "Progman", "WorkerW",
                  "Windows.UI.Core.CoreWindow", "NotifyIconOverflowWindow"}

# What people SAY -> part of the program's exe name (compact, lowercase).
_APP_HINTS = {
    "vscode": "code", "visualstudiocode": "code", "code": "code",
    "fileexplorer": "explorer", "explorer": "explorer", "files": "explorer",
    "terminal": "windowsterminal", "commandprompt": "cmd", "cmd": "cmd",
    "edge": "msedge", "microsoftedge": "msedge",
    "word": "winword", "powerpoint": "powerpnt", "ppt": "powerpnt",
    "notepad": "notepad", "vlc": "vlc", "teams": "teams",
}


def _norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", "", (s or "").lower())).strip()


def _compact(s):
    return _norm(s).replace(" ", "")


def _pid_of(hwnd):
    try:
        return win32process.GetWindowThreadProcessId(hwnd)[1]
    except Exception:
        return 0


def _exe_stem(pid):
    if psutil is None or not pid:
        return ""
    try:
        return os.path.splitext(psutil.Process(pid).name())[0].lower()
    except Exception:
        return ""


def _cloaked(hwnd):
    """True for hidden UWP/virtual-desktop windows that are 'visible' but not shown."""
    try:
        v = ctypes.c_int(0)
        ctypes.windll.dwmapi.DwmGetWindowAttribute(
            wintypes.HWND(hwnd), 14, ctypes.byref(v), ctypes.sizeof(v))
        return v.value != 0
    except Exception:
        return False


def _usable(hwnd):
    """A normal app window the user could mean (not the taskbar, desktop, or Jarvis)."""
    try:
        if not hwnd or not win32gui.IsWindowVisible(hwnd) or _cloaked(hwnd):
            return False
        if not win32gui.GetWindowText(hwnd) or win32gui.GetClassName(hwnd) in _SHELL_CLASSES:
            return False
        if _pid_of(hwnd) == os.getpid():
            return False
        ex = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        if ex & win32con.WS_EX_TOOLWINDOW and not ex & win32con.WS_EX_APPWINDOW:
            return False
        return True
    except Exception:
        return False


def _list_windows():
    """[(hwnd, title, exe_stem)] for open app windows, most recently used first."""
    out = []

    def cb(hwnd, _):
        if _usable(hwnd):
            out.append((hwnd, win32gui.GetWindowText(hwnd), _exe_stem(_pid_of(hwnd))))
        return True

    try:
        win32gui.EnumWindows(cb, None)
    except Exception:
        pass
    return out


def _focus(hwnd):
    """Bring a window to the front (restoring it if minimized). True if it worked."""
    try:
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        try:
            win32gui.SetForegroundWindow(hwnd)
        except Exception:
            pass
        time.sleep(0.12)
        if win32gui.GetForegroundWindow() != hwnd:
            # Windows only lets the foreground app change the foreground; a
            # synthetic Alt tap lifts that restriction. (Only on retry, because
            # a bare Alt can flash an app's menu bar.)
            _key(VK_MENU)
            _key(VK_MENU, up=True)
            try:
                win32gui.SetForegroundWindow(hwnd)
            except Exception:
                pass
            time.sleep(0.12)
        return win32gui.GetForegroundWindow() == hwnd
    except Exception as e:
        print(f"[window_commands] focus failed: {e}")
        return False


def _ensure_target():
    """The window to act on: the foreground one, or -- if the foreground is the
    taskbar / desktop / Jarvis itself -- the most recent real window (focused first)."""
    fg = win32gui.GetForegroundWindow()
    if _usable(fg):
        return fg
    wins = _list_windows()
    if not wins:
        return None
    _focus(wins[0][0])
    return wins[0][0]


def _fuzzy(q, text):
    """Spelling-tolerant: does `q` closely match a word / word-pair in `text`?"""
    q, t = _norm(q), _norm(text)
    if not q or not t:
        return False
    words, n = t.split(), len(q.split())
    for size in {n, n + 1}:
        for i in range(0, max(0, len(words) - size) + 1):
            cand = " ".join(words[i:i + size])
            if cand and difflib.SequenceMatcher(None, q, cand).ratio() >= FUZZY_CUTOFF:
                return True
    return False


def find_window(query):
    """Best open window for a spoken app name, or None.
    Order: program name (chrome.exe) -> window title -> spelling-tolerant."""
    wins = _list_windows()
    qc = _compact(query)
    if not qc:
        return None
    hint = _APP_HINTS.get(qc, qc)
    for w in wins:                                   # 1. the program itself
        stem = _compact(w[2])
        if stem and (hint == stem or (len(hint) >= 4 and hint in stem)):
            return w
    for w in wins:                                   # 2. words in the title
        if qc in _compact(w[1]):
            return w
    for w in wins:                                   # 3. misheard spelling
        if _fuzzy(query, w[2]) or _fuzzy(query, w[1]):
            return w
    return None


# ------------------------------------------------------------- actions ----
# --- snap / push: tolerant of how the speech recognizer mangles these words ---
_SNAP_VERBS = {"snap", "push", "move", "put", "dock", "slide", "pushed", "snapped"}
_SNAP_HEARD = {"sanp", "snapp", "snaps", "snip", "snub", "snob", "slap", "nap", "nop",
               "snop", "knap", "snab", "sneap", "bush", "posh", "pushes", "pushing"}
_LEFT = {"left", "lift", "lit", "let", "loft", "lef", "leff", "lefts", "laughed", "lest", "lefty"}
_RIGHT = {"right", "write", "rite", "rit", "ride", "wright", "night", "not", "rate", "writes", "rights"}
_TOP = {"top", "tap", "stop", "tops", "upper"}
_BOTTOM = {"bottom", "bottoms", "button", "buttom", "bottum", "lower"}
_FILLER = {"this", "the", "window", "it", "to", "side", "half", "corner", "a", "my",
           "on", "of", "screen", "please", "that"}
_SNAP_FUZZY = 0.75          # for words not in the lists above


def _ratio(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio()


def _is_snap_verb(w):
    return (w in _SNAP_VERBS or w in _SNAP_HEARD
            or max(_ratio(w, "snap"), _ratio(w, "push")) >= _SNAP_FUZZY)


def _as_side(w):
    if w in _LEFT:
        return "left"
    if w in _RIGHT:
        return "right"
    l, r = _ratio(w, "left"), _ratio(w, "right")
    if max(l, r) >= 0.7:
        return "left" if l > r else "right"
    return None


def _as_vert(w):
    if w in _TOP:
        return "top"
    if w in _BOTTOM:
        return "bottom"
    return None


def parse_snap(t):
    """'push right', 'snap this left', 'sanp lift', 'nop top left' ... ->
    (vertical or None, 'left'|'right'). None if it isn't a snap command.
    Every word must be understood, so ordinary sentences can't trigger it."""
    toks = [w for w in re.split(r"[\s\-_,]+", t) if w]
    if len(toks) < 2 or not _is_snap_verb(toks[0]):
        return None
    side = vert = None
    for w in toks[1:]:
        if w in _FILLER or w in _SNAP_VERBS or w in _SNAP_HEARD:
            continue                                  # "sanp nop right": the verb heard twice
        sd = _as_side(w)
        if sd:
            if side not in (None, sd):
                return None                           # "left right" -> contradictory
            side = sd                                 # "left lit": same word heard twice is fine
            continue
        vt = _as_vert(w)
        if vt:
            if vert not in (None, vt):
                return None
            vert = vt
            continue
        return None                                   # an unknown word -> not ours
    return (vert, side) if side else None


def _snap(vert, side):
    if _ensure_target() is None:
        return "I don't see a window to move."
    _hotkey(VK_LWIN, VK_LEFT if side == "left" else VK_RIGHT)
    if vert:                                          # quarter: then up/down
        time.sleep(0.3)
        _hotkey(VK_LWIN, VK_UP if vert == "top" else VK_DOWN)
        return f"Snapped {vert} {side}."
    return f"Snapped {side}."


def _maximize(m):
    h = _ensure_target()
    if h is None:
        return "I don't see a window."
    win32gui.ShowWindow(h, win32con.SW_MAXIMIZE)
    return "Maximized."


def _minimize(m):
    h = _ensure_target()
    if h is None:
        return "I don't see a window."
    win32gui.ShowWindow(h, win32con.SW_MINIMIZE)
    return "Minimized."


def _restore(m):
    h = _ensure_target()
    if h is None:
        return "I don't see a window."
    win32gui.ShowWindow(h, win32con.SW_RESTORE)
    return "Restored."


def _minimize_all(m):
    _hotkey(VK_LWIN, VK_D)
    return "Showing the desktop."


def _restore_all(m):
    _hotkey(VK_LWIN, VK_D)                            # Win+D toggles back
    return "Bringing your windows back."


def _next_monitor(m):
    if _ensure_target() is None:
        return "I don't see a window to move."
    _hotkey(VK_LWIN, VK_SHIFT, VK_LEFT if m.group(1) == "previous" else VK_RIGHT)
    return "Moved to the other screen."


def _switch_window(m):
    _hotkey(VK_MENU, VK_TAB)
    return "Switched."


def _close_window(m):
    if _ensure_target() is None:
        return "I don't see a window to close."
    _hotkey(VK_MENU, VK_F4)
    return "Closing the window."


def _task_view(m):
    _hotkey(VK_LWIN, VK_TAB)
    return "Task view."


def _new_desktop(m):
    _hotkey(VK_LWIN, VK_CONTROL, VK_D)
    return "New desktop."


def _next_desktop(m):
    _hotkey(VK_LWIN, VK_CONTROL, VK_RIGHT)
    return "Next desktop."


def _prev_desktop(m):
    _hotkey(VK_LWIN, VK_CONTROL, VK_LEFT)
    return "Previous desktop."


def _close_desktop(m):
    _hotkey(VK_LWIN, VK_CONTROL, VK_F4)
    return "Closed the desktop."


def _fullscreen(m):
    if _ensure_target() is None:
        return "I don't see a window."
    _hotkey(VK_F11)
    return "Toggled full screen."


def _list_open(m):
    seen, names = set(), []
    for _, title, stem in _list_windows():
        if not stem or stem == "applicationframehost":      # Settings, Calculator...
            label = title
        else:
            label = stem.replace(".root", "").replace(".", " ").title()
        if label not in seen:
            seen.add(label)
            names.append(label)
    if not names:
        return "I don't see any open windows."
    return "Open: " + ", ".join(names[:6]) + "."


_NOT_APPS = {"standby", "sleep", "desktop", "sleep mode", "previous", "next",
             "the next one", "the previous one", "main", "home", "assist",
             "focus assist", "dark mode", "light mode", "night light"}


def _switch_to(m):
    q = m.group(1).strip()
    if _norm(q) in _NOT_APPS:
        return None                                   # not ours -> other handlers
    w = find_window(q)
    if w is None:
        return None                                   # no such window -> let the other handlers try
    return f"Switched to {q}." if _focus(w[0]) else f"I couldn't bring {q} to the front."


_SW = r"(?:this |the |it )?(?:window )?"
_RULES = [
    (re.compile(r"^(?:maximi[sz]e|full size)(?: this| it| the window| this window| window)?$"), _maximize),
    (re.compile(r"^(?:minimi[sz]e (?:all|everything|all windows)|show (?:the )?desktop|go to (?:the )?desktop|hide all windows)$"), _minimize_all),
    (re.compile(r"^minimi[sz]e(?: this| it| the window| this window| window)?$"), _minimize),
    (re.compile(r"^(?:restore|bring back|show) (?:all |my )?windows$"), _restore_all),
    (re.compile(r"^restore(?: this| the window| this window| window)?$"), _restore),
    (re.compile(rf"^(?:move|send) {_SW}to (?:the )?(next|other|second|another|previous) (?:monitor|screen|display)$"), _next_monitor),
    (re.compile(r"^(?:switch|next|change)(?: the)? windows?$|^alt tab$"), _switch_window),
    (re.compile(r"^close (?:this |the current |current |the )?window$"), _close_window),
    (re.compile(r"^(?:task view|show task view)$"), _task_view),
    (re.compile(r"^(?:new|create|add) (?:virtual )?desktop$"), _new_desktop),
    (re.compile(r"^(?:next|right) (?:virtual )?desktop$"), _next_desktop),
    (re.compile(r"^(?:previous|last|left) (?:virtual )?desktop$"), _prev_desktop),
    (re.compile(r"^close (?:this |the current )?(?:virtual )?desktop$"), _close_desktop),
    (re.compile(r"^(?:toggle |exit )?full ?screen$"), _fullscreen),
    (re.compile(r"^(?:what|which) windows are open$|^list (?:open )?windows$"), _list_open),
    (re.compile(r"^(?:switch to|focus on|focus|bring up|jump to) (?:the )?(.+?)(?: window)?$"), _switch_to),
]


def try_handle(t: str, speak) -> bool:
    if not HAVE_WIN32:
        return False
    t = re.sub(r"^(?:please|jarvis)\s+", "", t.strip().rstrip(".,!?").strip())
    snap = parse_snap(t)
    if snap:
        try:
            speak(_snap(*snap))
        except Exception as e:
            print(f"[window_commands] snap failed: {e}")
            speak("I couldn't move the window.")
        return True
    for rx, fn in _RULES:
        m = rx.match(t)
        if not m:
            continue
        try:
            reply = fn(m)
        except Exception as e:                        # never crash the voice loop
            print(f"[window_commands] {fn.__name__} failed: {e}")
            reply = "I couldn't do that to the window."
        if reply is None:                             # rule declined (e.g. "switch to standby")
            return False
        speak(reply)
        return True
    return False


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python window_commands.py "snap left"')
        sys.exit(1)
    cmd = " ".join(sys.argv[1:]).lower()
    print("Handled." if try_handle(cmd, print) else "Not a window command.")
