"""
Free, keyless weather lookups via wttr.in.

No API key, no billing, no account needed -- wttr.in is a public
weather service that returns compact one-line summaries specifically
designed for command-line/voice-style use, which is exactly what a
spoken reply needs.
"""

import requests

WEATHER_URL = "https://wttr.in/{location}"


def get_weather(location: str = "") -> str:
    """Returns a spoken-friendly weather summary for `location`.
    Empty location = auto-detected from your connection's approximate
    location. Never raises -- returns a plain error message string
    instead so callers can just speak() the result either way."""
    try:
        resp = requests.get(
            WEATHER_URL.format(location=requests.utils.quote(location)),
            params={"format": "%l:+%C,+%t+(feels+like+%f),+%h+humidity,+%w+wind"},
            timeout=6,
            headers={"User-Agent": "curl"},  # wttr.in serves plain text to curl-like clients
        )
        resp.raise_for_status()
        text = resp.text.strip()
        if not text or "Unknown location" in text:
            return f"I couldn't find weather for {location or 'your location'}."
        return text
    except Exception as e:
        return f"I couldn't reach the weather service right now: {e}"
