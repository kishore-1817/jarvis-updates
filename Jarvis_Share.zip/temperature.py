"""CPU temperature reporting.

Primary source: LibreHardwareMonitor's built-in Remote Web Server (a
local JSON endpoint) -- NOT WMI. WMI support isn't reliably present in
every LibreHardwareMonitor build (confirmed failing here with an
"invalid namespace" COM error), but the web server ships with every
version and is simpler to talk to besides.

SETUP:
    1. Open LibreHardwareMonitor (already running as Administrator)
    2. Menu: Options -> Remote Web Server -> Run
       (leave the port on its default, 8085)
    3. Leave LibreHardwareMonitor running in the background
    4. pip install requests

Fallback: the built-in Windows ACPI thermal zone, used only if the web
server isn't reachable. Often inaccurate/unsupported on modern
laptops -- kept as a last resort, not the primary path.
"""

import requests

LHM_WEB_URL = "http://localhost:8085/data.json"


def _find_temp_value(node, require_cpu_package: bool):
    """Recursively searches the LibreHardwareMonitor JSON tree for a
    temperature reading. When require_cpu_package is True, only matches
    a node named 'CPU Package'; otherwise matches any node with 'cpu'
    in its name that has a C value."""
    text = node.get("Text", "")
    value = node.get("Value", "")

    if "C" in value and ("\u00b0C" in value):
        name = text.lower()
        if require_cpu_package and "cpu package" in name:
            return value
        if not require_cpu_package and "cpu" in name:
            return value

    for child in node.get("Children", []):
        result = _find_temp_value(child, require_cpu_package)
        if result:
            return result
    return None


def _read_lhm_web_temperature():
    try:
        resp = requests.get(LHM_WEB_URL, timeout=2)
        resp.raise_for_status()
        tree = resp.json()
    except Exception:
        return None  # server not running or not reachable

    value_str = _find_temp_value(tree, require_cpu_package=True)
    if not value_str:
        value_str = _find_temp_value(tree, require_cpu_package=False)
    if not value_str:
        return None

    try:
        return float(value_str.replace("\u00b0C", "").strip())
    except ValueError:
        return None


def _read_acpi_temperature():
    """Windows' built-in ACPI thermal zone. Last-resort fallback only --
    often unsupported or inaccurate on modern laptops."""
    try:
        import wmi
        conn = wmi.WMI(namespace="root/WMI")
        zones = conn.MSAcpi_ThermalZoneTemperature()
    except Exception:
        return None
    if not zones:
        return None
    kelvin = zones[0].CurrentTemperature / 10.0  # tenths of a Kelvin
    return kelvin - 273.15


def get_cpu_temperature():
    """Returns CPU temperature in Celsius, or None if no source is available."""
    temp = _read_lhm_web_temperature()
    if temp is not None:
        return temp
    return _read_acpi_temperature()


def get_temperature_summary() -> str:
    temp = get_cpu_temperature()

    if temp is None:
        return ("I couldn't read the CPU temperature. Make sure "
                "LibreHardwareMonitor is running, with its Remote Web "
                "Server turned on under Options.")

    summary = f"CPU temperature is {temp:.0f} degrees Celsius."

    if temp >= 85:
        summary += (" That's quite hot. Close background apps, check "
                     "that the vents aren't blocked, and consider "
                     "giving it a rest.")
    elif temp >= 70:
        summary += " That's warm, but normal under load."
    else:
        summary += " That's a healthy temperature."

    return summary
