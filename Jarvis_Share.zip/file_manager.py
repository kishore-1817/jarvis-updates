"""
file_manager.py -- everything to do with finding, opening, copying,
moving, renaming, deleting, listing, and organizing files and folders
on the user's computer.

Deliberately has NO dependency on jarvis_up.py -- every public function
returns a plain, spoken-friendly string. jarvis_up.py imports what it
needs and decides which spoken phrases route to which function; Gemini
(via the *_tool wrappers registered in jarvis_up.py) can call the same
functions when a phrase doesn't match a keyword exactly. Either way,
the LLM never touches a file directly -- it only ever calls these
deterministic functions, same as a keyword match would.

DESIGN: disambiguation and confirmation
----------------------------------------
Two problems every destructive or ambiguous action runs into:

  1. Multiple matches. "Delete report.pdf" when there's a
     Downloads/report.pdf AND a Documents/report.pdf shouldn't silently
     pick one -- it should ask which one.
  2. Destructive actions. Deleting (even to the Recycle Bin) shouldn't
     happen on the first sentence -- it should confirm first.

Both need a REPLY to the previous thing said, which means state has to
survive from one spoken command to the next. Rather than waiting for
the full conversation-memory system (a separate, bigger roadmap item),
this module keeps its own small, scoped "pending action" -- a single
module-level slot holding either a yes/no confirmation or a
multiple-choice question, whichever is currently outstanding.

jarvis_up.py's dispatcher checks has_pending() FIRST, before anything
else, on every single command -- so "yes", "the downloads one", or
"second" gets routed to resolve_pending() no matter how the original
ambiguous/destructive request came in (keyword match or Gemini tool
call). If resolve_pending() doesn't recognize the reply as an answer,
it drops the pending action and returns None, so the caller just
treats that text as a brand new command instead of getting stuck
demanding "yes or no" forever.

DELETION uses send2trash, so "delete" always means Recycle Bin, never
os.unlink(). Requires: pip install Send2Trash
"""

import os
import re
import shutil
import subprocess
from pathlib import Path

try:
    import send2trash
    _SEND2TRASH_AVAILABLE = True
except Exception:
    _SEND2TRASH_AVAILABLE = False


# ---------------------------------------------------------------------
# Known folders (moved here from jarvis_up.py -- this module is now the
# one place that knows where "desktop", "downloads", etc. actually are)
# ---------------------------------------------------------------------
HOME = Path.home()
onedrive = os.environ.get("OneDrive")  # Windows sets this automatically when OneDrive is active
onedrive_path = Path(onedrive) if onedrive else None


def resolve_folder(name: str) -> Path:
    """Prefer the OneDrive-redirected folder if it exists, else fall back to the local one."""
    if onedrive_path:
        candidate = onedrive_path / name
        if candidate.exists():
            return candidate
    return HOME / name


FOLDERS = {
    "desktop": resolve_folder("Desktop"),
    "documents": resolve_folder("Documents"),
    "downloads": HOME / "Downloads",   # Downloads usually stays local even with OneDrive
    "pictures": resolve_folder("Pictures"),
    "music": HOME / "Music",           # Music/Videos aren't OneDrive-backed by default
    "videos": HOME / "Videos",
}

# Folders NOT searched when looking for a file -- system/dev clutter that
# would make the scan slow and return junk matches
EXCLUDED_DIR_NAMES = {
    "appdata", "node_modules", ".git", "__pycache__", "$recycle.bin",
    "programdata", ".cache", ".vscode", "venv", ".venv", "windows",
}
MAX_SEARCH_DEPTH = 6  # folder levels below the home folder

# Alternate names people say for the same folder
FOLDER_ALIASES = {
    "gallery": "pictures",
    "photos": "pictures",
    "photo": "pictures",
    "picture": "pictures",
    "download": "downloads",
    "document": "documents",
    "video": "videos",
    "desktops": "desktop",
}


def resolve_folder_key(spoken: str) -> str:
    return FOLDER_ALIASES.get(spoken, spoken)


def open_folder(folder_key: str) -> bool:
    """Opens File Explorer directly at a known folder (Desktop, Downloads, etc.)."""
    path = FOLDERS.get(folder_key)
    if not path or not path.exists():
        return False
    subprocess.Popen(f'explorer "{path}"', shell=True)
    return True


# ---------------------------------------------------------------------
# Pending action -- the small stateful piece described in the module
# docstring above. One slot: either a confirmation or a multi-choice
# question is outstanding, or nothing is.
# ---------------------------------------------------------------------
_pending = None

_YES_WORDS = ("yes", "yeah", "yep", "yup", "confirm", "do it", "go ahead", "sure", "correct")
_NO_WORDS = ("no", "nope", "cancel", "never mind", "nevermind", "stop", "don't", "abort")
# "send it" counts as yes ONLY when nothing negates it ("don't send it" must NOT).
_SEND_IT_WORDS = ("send it", "send the message")
_NEGATION_RE = re.compile(r"\b(no|not|don'?t|dont|never|cancel|abort|stop|wait|hold)\b")
_ORDINAL_WORDS = ("first", "second", "third", "fourth", "fifth")
_NUMBER_WORDS = ("one", "two", "three", "four", "five")


def has_pending() -> bool:
    return _pending is not None


def start_confirmation(prompt: str, on_yes, on_no=None) -> str:
    """Sets a pending yes/no confirmation. `on_yes` is a zero-argument
    callable run (and its return value spoken) if the next thing heard
    looks like a "yes". Returns `prompt` so callers can just `return
    start_confirmation(...)` directly as their spoken result."""
    global _pending
    _pending = {"kind": "confirm", "on_yes": on_yes, "on_no": on_no}
    return prompt


def start_choice(prompt: str, matches, on_choice) -> str:
    """Sets a pending multiple-choice question over `matches` (a list
    of Paths). `on_choice` is called with the chosen Path once the next
    reply resolves to one of them (by folder name, ordinal, or number).
    Returns `prompt` so callers can `return start_choice(...)` directly."""
    global _pending
    _pending = {"kind": "choose", "matches": list(matches), "on_choice": on_choice}
    return prompt


def _parse_choice_index(t: str, matches) -> int:
    """Returns the index of the match `t` seems to refer to, or None.
    Tries the containing folder's name first ("the downloads one"),
    since that's the most natural way to disambiguate by ear, then
    falls back to ordinals/numbers ("second", "2")."""
    for i, m in enumerate(matches):
        folder_name = m.parent.name.lower()
        if folder_name and folder_name in t:
            return i
    # Ordinals FIRST, then digits, then number words. Checking them per-index (as
    # before) made "the second one" resolve to the FIRST match, because the bare
    # word "one" matched index 0 before "second" was ever looked at.
    n = min(len(matches), 5)
    for i in range(n):
        if _ORDINAL_WORDS[i] in t:
            return i
    for i in range(n):
        if re.search(rf"\b{i + 1}\b", t):
            return i
    for i in range(n):
        if _NUMBER_WORDS[i] in t:
            return i
    return None


def resolve_pending(text: str):
    """Attempts to interpret `text` as a reply to the current pending
    action. Returns the spoken result string if consumed, or None if
    `text` doesn't look like a reply at all -- in that case the pending
    action is silently dropped (assume the user moved on to something
    else) and the caller should treat `text` as a brand new command,
    not retry asking for an answer."""
    global _pending
    if _pending is None:
        return None

    pending = _pending
    t = text.lower().strip()

    if pending["kind"] == "confirm":
        on_no = pending.get("on_no")
        is_yes = (any(w in t for w in _YES_WORDS)
                  or (any(w in t for w in _SEND_IT_WORDS) and not _NEGATION_RE.search(t)))
        if is_yes:
            _pending = None
            return pending["on_yes"]()
        if any(w in t for w in _NO_WORDS):
            _pending = None
            if on_no:
                try:
                    return on_no("no") or "Okay, cancelled."
                except Exception:
                    pass
            return "Okay, cancelled."
        _pending = None
        if on_no:
            try:
                on_no("dropped")  # user moved on -- let the owner forget its draft
            except Exception:
                pass
        return None  # didn't look like an answer -- treat as a new command

    if pending["kind"] == "choose":
        idx = _parse_choice_index(t, pending["matches"])
        if idx is not None:
            chosen = pending["matches"][idx]
            _pending = None
            return pending["on_choice"](chosen)
        if any(w in t for w in _NO_WORDS) or "none" in t:
            _pending = None
            return "Okay, cancelled."
        _pending = None
        return None

    _pending = None
    return None


# ---------------------------------------------------------------------
# Search -- returns ALL matches, never silently picks "the first one".
# Callers (below) decide what 0/1/many results mean for their action.
# ---------------------------------------------------------------------
def find_matches(name: str):
    """Searches the whole home folder for FILES matching `name`, with
    or without extension. Skips system/dev clutter and caps search
    depth so it doesn't crawl forever."""
    name = name.strip().lower()
    home_depth = len(HOME.parts)
    matches = []

    for root, dirs, files in os.walk(HOME, topdown=True):
        root_path = Path(root)
        depth = len(root_path.parts) - home_depth
        if depth >= MAX_SEARCH_DEPTH:
            dirs[:] = []
            continue

        dirs[:] = [d for d in dirs
                   if d.lower() not in EXCLUDED_DIR_NAMES and not d.startswith(".")]

        for f in files:
            stem = Path(f).stem.lower()
            if stem == name or f.lower() == name:
                matches.append(root_path / f)
    return matches


def find_folder_matches(name: str):
    """Same idea as find_matches(), but for FOLDERS (directories)
    rather than files -- used by delete-folder and the folder-rename
    fallback."""
    name = name.strip().lower()
    home_depth = len(HOME.parts)
    matches = []

    for root, dirs, files in os.walk(HOME, topdown=True):
        root_path = Path(root)
        depth = len(root_path.parts) - home_depth
        if depth >= MAX_SEARCH_DEPTH:
            dirs[:] = []
            continue

        dirs[:] = [d for d in dirs
                   if d.lower() not in EXCLUDED_DIR_NAMES and not d.startswith(".")]

        for d in dirs:
            if d.lower() == name:
                matches.append(root_path / d)
    return matches


def find_file(name: str):
    """Backward-compatible single-result helper for any internal caller
    that just wants "a" match without disambiguation handling. Prefer
    find_matches() for anything user-facing."""
    matches = find_matches(name)
    return matches[0] if matches else None


def _describe(p: Path) -> str:
    return f"{p.name} in {p.parent.name}"


def _list_spoken(matches) -> str:
    return ", ".join(_describe(m) for m in matches[:5])


# ---------------------------------------------------------------------
# Find / Open
# ---------------------------------------------------------------------
def find_command(name: str) -> str:
    """"Find my resume" -- reports location(s), never acts on the file."""
    matches = find_matches(name)
    if not matches:
        return f"I couldn't find a file named {name}."
    if len(matches) == 1:
        return f"Found it: {matches[0]}"
    return f"I found {len(matches)}: {_list_spoken(matches)}."


def open_command(name: str) -> str:
    """"Open my resume" -- opens the file with its default application."""
    matches = find_matches(name)
    if not matches:
        return f"I couldn't find a file named {name}."
    if len(matches) == 1:
        return _open_path(matches[0])
    return start_choice(
        f"I found {len(matches)} files named {name}: {_list_spoken(matches)}. Which one?",
        matches,
        _open_path,
    )


def _open_path(p: Path) -> str:
    try:
        os.startfile(str(p))
        return f"Opening {p.name}."
    except Exception as e:
        return f"Couldn't open {p.name}: {e}"


# ---------------------------------------------------------------------
# Copy / Move -- to a known folder, upgraded from the old version to
# handle multiple matches instead of silently grabbing the first one.
# ---------------------------------------------------------------------
def copy_or_move_file(filename: str, dest_key: str, move: bool = False) -> str:
    """Copies or moves a file to a known folder (desktop, downloads,
    etc.). Multiple matches trigger a spoken disambiguation question."""
    dest_folder = FOLDERS.get(dest_key)
    if not dest_folder:
        return f"I don't know the folder {dest_key}."
    matches = find_matches(filename)
    if not matches:
        return f"I couldn't find a file named {filename}."
    if len(matches) == 1:
        return _do_copy_or_move(matches[0], dest_folder, dest_key, move)
    return start_choice(
        f"I found {len(matches)} files named {filename}: {_list_spoken(matches)}. Which one?",
        matches,
        lambda p: _do_copy_or_move(p, dest_folder, dest_key, move),
    )


def _do_copy_or_move(src: Path, dest_folder: Path, dest_key: str, move: bool) -> str:
    try:
        if move:
            shutil.move(str(src), str(dest_folder / src.name))
            return f"Moved {src.name} to {dest_key}."
        shutil.copy2(str(src), str(dest_folder / src.name))
        return f"Copied {src.name} to {dest_key}."
    except Exception as e:
        return f"Something went wrong: {e}"


# ---------------------------------------------------------------------
# Copy / Move -- to an arbitrary destination (e.g. a specific drive),
# not one of the predefined FOLDERS. Parsing a spoken path is
# inherently fuzzy, which is exactly why this ALWAYS confirms before
# acting, unlike the known-folder version above.
# ---------------------------------------------------------------------
_DRIVE_WORD_RE = re.compile(r"^([a-z]) drive\s*(.*)$")


def _parse_drive_destination(spoken: str):
    """Parses phrases like 'd drive projects' into a Path. Best-effort
    only -- treats the remainder as ONE folder name (title-cased), not
    a nested path, since there's no reliable way to hear the difference
    between "projects folder two" as one name versus two nested ones."""
    m = _DRIVE_WORD_RE.match(spoken.strip().lower())
    if not m:
        return None
    drive_letter, rest = m.groups()
    rest = rest.strip()
    if not rest:
        return Path(f"{drive_letter.upper()}:/")
    folder_name = " ".join(w.capitalize() for w in rest.split())
    return Path(f"{drive_letter.upper()}:/") / folder_name


def copy_or_move_to_path_command(filename: str, spoken_destination: str, move: bool = False) -> str:
    dest_path = _parse_drive_destination(spoken_destination)
    if dest_path is None:
        return (f"I didn't understand the destination {spoken_destination!r}. "
                f"Try saying it like 'D drive Projects'.")
    matches = find_matches(filename)
    if not matches:
        return f"I couldn't find a file named {filename}."
    if len(matches) > 1:
        return start_choice(
            f"I found {len(matches)} files named {filename}: {_list_spoken(matches)}. Which one?",
            matches,
            lambda p: _confirm_copy_move_to_path(p, dest_path, move),
        )
    return _confirm_copy_move_to_path(matches[0], dest_path, move)


def _confirm_copy_move_to_path(src: Path, dest_path: Path, move: bool) -> str:
    action_word = "move" if move else "copy"
    will_create = "" if dest_path.exists() else " -- I'll create that folder"
    return start_confirmation(
        f"I'll {action_word} {src.name} to {dest_path}{will_create}. Confirm?",
        lambda: _do_copy_or_move_to_path(src, dest_path, move),
    )


def _do_copy_or_move_to_path(src: Path, dest_path: Path, move: bool) -> str:
    try:
        dest_path.mkdir(parents=True, exist_ok=True)
        if move:
            shutil.move(str(src), str(dest_path / src.name))
            return f"Moved {src.name} to {dest_path}."
        shutil.copy2(str(src), str(dest_path / src.name))
        return f"Copied {src.name} to {dest_path}."
    except Exception as e:
        return f"Something went wrong: {e}"


# ---------------------------------------------------------------------
# Rename -- files first, falls back to folders if no file matches
# ---------------------------------------------------------------------
def rename_command(old_name: str, new_name: str) -> str:
    matches = find_matches(old_name)
    if matches:
        if len(matches) == 1:
            return _do_rename(matches[0], new_name)
        return start_choice(
            f"I found {len(matches)} files named {old_name}: {_list_spoken(matches)}. Which one?",
            matches,
            lambda p: _do_rename(p, new_name),
        )

    folder_matches = find_folder_matches(old_name)
    if not folder_matches:
        return f"I couldn't find a file or folder named {old_name}."
    if len(folder_matches) == 1:
        return _do_rename(folder_matches[0], new_name, is_folder=True)
    return start_choice(
        f"I found {len(folder_matches)} folders named {old_name}. Which one?",
        folder_matches,
        lambda p: _do_rename(p, new_name, is_folder=True),
    )


def _do_rename(path: Path, new_name: str, is_folder: bool = False) -> str:
    new_name = new_name.strip()
    if not is_folder and "." not in new_name and path.suffix:
        new_name = new_name + path.suffix  # keep the original extension if none was given
    new_path = path.parent / new_name
    if new_path.exists():
        return f"Something named {new_name} already exists there."
    try:
        path.rename(new_path)
        return f"Renamed it to {new_name}."
    except Exception as e:
        return f"Couldn't rename that: {e}"


# ---------------------------------------------------------------------
# Delete -- ALWAYS to the Recycle Bin via send2trash, ALWAYS confirmed
# first. This is the one place os.unlink()/shutil.rmtree() must never
# appear -- that's the whole point of this design.
# ---------------------------------------------------------------------
def delete_command(name: str) -> str:
    matches = find_matches(name)
    if not matches:
        return f"I couldn't find a file named {name}."
    if len(matches) == 1:
        return _confirm_delete_file(matches[0])
    return start_choice(
        f"I found {len(matches)} files named {name}: {_list_spoken(matches)}. Which one?",
        matches,
        _confirm_delete_file,
    )


def _confirm_delete_file(path: Path) -> str:
    return start_confirmation(
        f"I found {path}. Move it to the Recycle Bin?",
        lambda: _do_delete(path, is_folder=False),
    )


def delete_folder_command(name: str) -> str:
    matches = find_folder_matches(name)
    if not matches:
        return f"I couldn't find a folder named {name}."
    if len(matches) == 1:
        return _confirm_delete_folder(matches[0])
    return start_choice(
        f"I found {len(matches)} folders named {name}: "
        f"{', '.join(m.parent.name + '/' + m.name for m in matches[:5])}. Which one?",
        matches,
        _confirm_delete_folder,
    )


def _confirm_delete_folder(path: Path) -> str:
    try:
        file_count = sum(len(files) for _, _, files in os.walk(path))
    except Exception:
        file_count = "an unknown number of"
    return start_confirmation(
        f"This will move the entire {path.name} folder, including "
        f"{file_count} files inside it, to the Recycle Bin. Are you sure?",
        lambda: _do_delete(path, is_folder=True),
    )


def _do_delete(path: Path, is_folder: bool = False) -> str:
    if not _SEND2TRASH_AVAILABLE:
        return "Deleting needs an extra library -- run: pip install Send2Trash"
    try:
        send2trash.send2trash(str(path))
        kind = "folder" if is_folder else "file"
        return f"Moved the {path.name} {kind} to the Recycle Bin."
    except Exception as e:
        return f"Something went wrong deleting that: {e}"


# ---------------------------------------------------------------------
# Create folder
# ---------------------------------------------------------------------
def create_folder_command(name: str, parent_key: str = "desktop") -> str:
    parent_key = resolve_folder_key((parent_key or "desktop").strip().lower())
    parent = FOLDERS.get(parent_key)
    if not parent:
        return f"I don't recognize the folder {parent_key}."
    target = parent / name.strip()
    if target.exists():
        return f"A folder called {name} already exists in {parent_key}."
    try:
        target.mkdir(parents=True)
        return f"Created {name} in {parent_key}."
    except Exception as e:
        return f"Couldn't create that folder: {e}"


# ---------------------------------------------------------------------
# List files / search by extension -- both scoped to ONE known folder
# (non-recursive), since "what files are in Downloads" means the top
# level of Downloads, not a full-drive search.
# ---------------------------------------------------------------------
def list_files_command(folder_key: str) -> str:
    folder_key = resolve_folder_key(folder_key.strip().lower())
    folder = FOLDERS.get(folder_key)
    if not folder or not folder.exists():
        return f"I don't recognize the folder {folder_key}."
    try:
        entries = [f.name for f in folder.iterdir() if f.is_file()]
    except Exception as e:
        return f"Couldn't read that folder: {e}"
    if not entries:
        return f"{folder_key.capitalize()} is empty."
    preview = ", ".join(entries[:8])
    remaining = len(entries) - 8
    if remaining > 0:
        return f"You have {len(entries)} files in {folder_key}, including {preview}, and {remaining} more."
    return f"You have {len(entries)} files in {folder_key}: {preview}."


def search_folder_command(extension: str, folder_key: str) -> str:
    folder_key = resolve_folder_key(folder_key.strip().lower())
    folder = FOLDERS.get(folder_key)
    if not folder or not folder.exists():
        return f"I don't recognize the folder {folder_key}."
    ext = extension.strip().lower().lstrip(".")
    if len(ext) > 1 and ext.endswith("s"):
        ext = ext[:-1]  # crude plural strip: "pdfs" -> "pdf"
    try:
        matches = list(folder.glob(f"*.{ext}"))
    except Exception as e:
        return f"Couldn't search that folder: {e}"
    if not matches:
        return f"I didn't find any .{ext} files in {folder_key}."
    names = ", ".join(m.name for m in matches[:8])
    remaining = len(matches) - 8
    if remaining > 0:
        return f"Found {len(matches)} .{ext} files in {folder_key}, including {names}, and {remaining} more."
    return f"Found {len(matches)} .{ext} files in {folder_key}: {names}."


# ---------------------------------------------------------------------
# Show location / duplicate
# ---------------------------------------------------------------------
def show_location_command(name: str) -> str:
    matches = find_matches(name)
    if not matches:
        return f"I couldn't find a file named {name}."
    if len(matches) == 1:
        return _do_show_location(matches[0])
    return start_choice(
        f"I found {len(matches)} files named {name}: {_list_spoken(matches)}. Which one?",
        matches,
        _do_show_location,
    )


def _do_show_location(path: Path) -> str:
    try:
        subprocess.Popen(f'explorer /select,"{path}"')
        return f"Here's where {path.name} is."
    except Exception as e:
        return f"Couldn't open that location: {e}"


def duplicate_command(name: str) -> str:
    matches = find_matches(name)
    if not matches:
        return f"I couldn't find a file named {name}."
    if len(matches) == 1:
        return _do_duplicate(matches[0])
    return start_choice(
        f"I found {len(matches)} files named {name}: {_list_spoken(matches)}. Which one?",
        matches,
        _do_duplicate,
    )


def _do_duplicate(path: Path) -> str:
    stem, suffix = path.stem, path.suffix
    candidate = path.parent / f"{stem} - Copy{suffix}"
    n = 2
    while candidate.exists():
        candidate = path.parent / f"{stem} - Copy ({n}){suffix}"
        n += 1
    try:
        shutil.copy2(str(path), str(candidate))
        return f"Made a copy: {candidate.name}."
    except Exception as e:
        return f"Couldn't duplicate that: {e}"
