"""
browser_commands.py -- tab control + "open the Nth search result".

Router domain (same contract as clipboard_commands etc.):
    try_handle(t: str, speak) -> bool

Voice phrases:
    "new tab" / "open a new tab"            -> Ctrl+T
    "close tab" / "close this tab"          -> Ctrl+W
    "close tab 3" / "close the third tab"   -> jump to tab 3, then Ctrl+W
    "next tab" / "previous tab"             -> Ctrl+Tab / Ctrl+Shift+Tab
    "go to tab 2" / "switch to tab 2"       -> Ctrl+2 ("last tab" -> Ctrl+9)
    "reopen tab"                            -> Ctrl+Shift+T
    "search for <query>"                    -> opens Google AND remembers the
                                               top results
    "open the second result" / "click link 2" / "open result 3"
                                            -> opens that result in a new tab

Safety: tab shortcuts only fire when the FOREGROUND window is a browser,
so "close tab" can never close a Notepad / VS Code window by accident.

Note on "open result N": results come from ddgs (same package llm_brain.py
already uses), so their order can differ slightly from Google's page.
"""

import re
import ctypes
import threading
import webbrowser
import urllib.parse

import memory                      # memory.context = short-term list holder
from keyboard_control import press_keys

_BROWSER_TITLES = ("chrome", "edge", "firefox", "brave", "opera")

_NUM_WORDS = {
    "first": 1, "1st": 1, "one": 1, "1": 1,
    "second": 2, "2nd": 2, "two": 2, "2": 2,
    "third": 3, "3rd": 3, "three": 3, "3": 3,
    "fourth": 4, "4th": 4, "four": 4, "4": 4,
    "fifth": 5, "5th": 5, "five": 5, "5": 5,
    "sixth": 6, "6th": 6, "six": 6, "6": 6,
    "seventh": 7, "7th": 7, "seven": 7, "7": 7,
    "eighth": 8, "8th": 8, "eight": 8, "8": 8,
}
_ORD_ONLY = "first|1st|second|2nd|third|3rd|fourth|4th|fifth|5th|sixth|6th|seventh|7th|eighth|8th"
_NUM_PATTERN = "|".join(sorted(map(re.escape, _NUM_WORDS), key=len, reverse=True))


def _foreground_is_browser() -> bool:
    try:
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        buf = ctypes.create_unicode_buffer(512)
        ctypes.windll.user32.GetWindowTextW(hwnd, buf, 512)
        title = buf.value.lower()
        return any(b in title for b in _BROWSER_TITLES)
    except Exception:
        return True   # can't tell -> don't block the command


def _goto_tab(n: int):
    # Ctrl+1..8 = tab 1..8, Ctrl+9 = LAST tab (Chrome/Edge/Firefox behavior)
    press_keys(f"ctrl {min(n, 9)}")


# ---------------- "search for ..." + remembered results ----------------

def _fetch_results(query: str):
    try:
        from ddgs import DDGS
        with DDGS() as d:
            hits = d.text(query, max_results=5)
        urls = [h.get("href") for h in hits if h.get("href")]
        memory.context.set_last_list(urls, "search_results")
    except Exception:
        memory.context.set_last_list([], "search_results")


def _do_search(query: str, speak):
    try:
        from corrections import correct_text
        query = correct_text(query)
    except Exception:
        pass
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote_plus(query))
    memory.context.set_last_list([], "search_results")
    threading.Thread(target=_fetch_results, args=(query,), daemon=True).start()
    speak(f"Searching for {query}")


def _open_result(n: int, speak):
    ctx = memory.context
    if ctx.last_list_kind != "search_results" or not ctx.last_list:
        speak("I don't have search results to open yet. Try searching first.")
        return
    if n > len(ctx.last_list):
        speak(f"I only have {len(ctx.last_list)} results.")
        return
    webbrowser.open_new_tab(ctx.last_list[n - 1])
    speak(f"Opening result {n}")


# ---------------- router entry point ----------------

_RE_NEW_TAB   = re.compile(r"^(?:open |make |create )?(?:a |another )?new tab$")
_RE_CLOSE_N   = re.compile(rf"^close (?:the )?(?:tab )?({_NUM_PATTERN}|last)(?: tab)?$|^close tab ({_NUM_PATTERN}|last)$")
_RE_CLOSE     = re.compile(r"^close (?:this |the current |current )?tab$")
_RE_GOTO      = re.compile(rf"^(?:go to|switch to|open) (?:the )?tab ({_NUM_PATTERN}|last)$|^(?:go to|switch to) (?:the )?({_NUM_PATTERN}|last) tab$")
_RE_RESULT    = re.compile(rf"^(?:open|click|go to|select) (?:the )?(?:result|link) ({_NUM_PATTERN})$|^(?:open|click|go to|select) (?:the )?({_ORD_ONLY})(?: result| link| one)?$")
_RE_SEARCH    = re.compile(r"^search (?:for )?(.+)$")


def _num(token: str) -> int:
    return 9 if token == "last" else _NUM_WORDS[token]


def try_handle(t: str, speak) -> bool:
    t = t.strip().rstrip(".?!").lower()

    # --- search (also records results for "open the Nth result") ---
    m = _RE_SEARCH.match(t)
    if m:
        _do_search(m.group(1).strip(), speak)
        return True

    # --- open the Nth result (works from the remembered list, no browser focus needed) ---
    m = _RE_RESULT.match(t)
    if m and memory.context.last_list_kind == "search_results":
        _open_result(_NUM_WORDS[m.group(1) or m.group(2)], speak)
        return True

    # Everything below sends keystrokes -> only when a browser is in front.
    tab_phrase = (_RE_NEW_TAB.match(t) or _RE_CLOSE.match(t) or _RE_CLOSE_N.match(t)
                  or _RE_GOTO.match(t)
                  or t in ("next tab", "previous tab", "last tab", "reopen tab",
                           "reopen closed tab", "reopen the tab"))
    if not tab_phrase:
        return False

    if not _foreground_is_browser():
        speak("Your browser isn't in front. Say 'switch to chrome' first.")
        return True

    if _RE_NEW_TAB.match(t):
        press_keys("ctrl t"); speak("New tab"); return True

    if t in ("next tab",):
        press_keys("ctrl tab"); return True
    if t in ("previous tab",):
        press_keys("ctrl shift tab"); return True
    if t in ("reopen tab", "reopen closed tab", "reopen the tab"):
        press_keys("ctrl shift t"); speak("Reopened"); return True

    m = _RE_CLOSE.match(t)
    if m:
        press_keys("ctrl w"); speak("Closed"); return True

    m = _RE_CLOSE_N.match(t)
    if m:
        n = _num(m.group(1) or m.group(2))
        _goto_tab(n)
        press_keys("ctrl w")
        speak(f"Closed tab {n if n != 9 else 'last'}")
        return True

    m = _RE_GOTO.match(t)
    if m:
        _goto_tab(_num(m.group(1) or m.group(2)))
        return True

    if t == "last tab":
        _goto_tab(9); return True

    return False
