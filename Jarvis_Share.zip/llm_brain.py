"""
LLM fallback -- when a spoken command doesn't match anything built-in,
this sends it to Google's Gemini API for a real conversational answer
instead of just saying "I didn't catch a command."

Gemini has a genuinely free tier (no credit card required for personal
use, generous rate limits) and runs in the cloud, so it doesn't compete
with your laptop's RAM the way a local model would.

FRESHNESS -- why this file also does its own web search (but only sometimes):
Gemini's own "Grounding with Google Search" tool needs a Cloud Billing
account linked to work reliably (even though usage itself would stay
$0 under the free monthly quota) -- without one, it 429s almost
immediately. Since the whole point of choosing Gemini was avoiding any
card-on-file requirement, we don't use that tool. Instead, we do a
quick, completely free, keyless web search ourselves (via the `ddgs`
package -- no API key, no billing, ever) and hand Gemini the results
as extra context. This gets the same practical benefit -- Jarvis can
answer "who is the current X" correctly instead of reciting outdated
training data -- without needing billing set up anywhere.

This search is a full extra network round-trip on top of the Gemini
call itself -- often slower than the LLM response. Running it on EVERY
question (including "tell me a joke", "how are you", etc. that never
needed it) was adding real, pointless latency to most replies. Now
gated behind a quick keyword check (_needs_live_search) so it only
fires for questions that plausibly need current/timely info.

FUNCTION CALLING -- how Jarvis can actually DO things, not just talk:
jarvis_up.py owns the real actions (opening/closing apps, moving
files, taking a screenshot, etc.) since those depend on state defined
there (FOLDERS, APP_INDEX, and so on). At startup, jarvis_up.py calls
register_tools() here with a list of plain Python functions. Once
registered, Gemini is told about them (via their docstrings and type
hints) and can choose to call one directly instead of just describing
what to do -- e.g. saying "kill chrome" (which doesn't match the
"close <app>" keyword rule exactly) can still trigger close_app_tool()
under the hood. This only ever runs the specific functions we've
explicitly exposed -- Gemini has no broader access to the machine than
that fixed toolset.

CONVERSATION MEMORY -- why there's a persistent chat session:
Every call to ask_llm() reuses the same chat object instead of
starting fresh, so even two commands said back-to-back in the same
active session share context ("my name is Kishore" -> "what is my
name" works). The chat resets only when register_tools() rebuilds
things (startup), refresh_persona() is called (a remembered fact
changed), or reset_chat() is called explicitly -- it intentionally
persists across standby/active cycles within one run of the program,
since from the user's point of view that's still the same
conversation. It does NOT persist across a full restart of Jarvis --
that's long-term memory's job (see memory.py's preferences table for
that, e.g. remembering the user's name permanently belongs there, not
here).

SDK NOTE (migrated 2026-09): this file uses the `google-genai` package
(`from google import genai`), NOT the older, now-deprecated
`google-generativeai` package. The two have meaningfully different
APIs -- if you're reading old Gemini sample code online and it uses
`genai.GenerativeModel(...)` or `model.start_chat(...)`, that's the
OLD package's shape and won't work here. This file instead uses
`genai.Client(...)` and `client.chats.create(...)`. Automatic function
calling is that new SDK's default behavior whenever plain Python
functions are passed as tools -- no extra flag needed for it (the old
SDK required `enable_automatic_function_calling=True`).

SETUP:
    1. Go to https://aistudio.google.com/apikey
    2. Sign in with a Google account, click "Create API key"
    3. Copy the key
    4. Create a file named .env in this same folder containing exactly:
           GEMINI_API_KEY=paste_your_key_here
       (no quotes, no spaces around the =, nothing else in the file)
    5. pip install google-genai ddgs python-dotenv

    If you were previously using gemini_api_key.txt: that file stored
    the key in plain, unencrypted text sitting right next to the code.
    .env isn't magically unbreakable either, but it's the standard
    place secrets go and it's what you'd add to .gitignore if this
    project ever ends up in version control. Once .env is working
    (Jarvis starts normally and Gemini answers still work), delete
    gemini_api_key.txt -- it's kept as a fallback for now so this
    change doesn't break your setup mid-session, not as a permanent
    second option.
"""

import os
import re
import time
import json
import logging
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from google.genai import types
from ddgs import DDGS

import lessons  # notebook of past corrections, see lessons.py
import brain_switch  # which brain is active (voice command), see brain_switch.py
import brain_openai  # Groq / OpenRouter / Ollama, see brain_openai.py
import solver  # fast problem solver, see solver.py
import memory  # for the user's remembered name, see _build_chat_config() below

# Shares the same 'jarvis' logger jarvis_up.py sets up (with a file
# handler pointing at jarvis.log) -- getLogger() returns the same
# singleton object for a given name regardless of import order, so
# this picks up that handler once jarvis_up.py attaches it, even
# though this module is imported before that happens.
logger = logging.getLogger("jarvis")

# Loads GEMINI_API_KEY from a .env file sitting next to this script (if
# one exists). Explicit path rather than relying on cwd, since Jarvis
# might get launched from a different working directory (e.g. a
# shortcut, Start_Jarvis_Silent.vbs, or Windows startup) where a bare
# load_dotenv() would silently find nothing.
load_dotenv(Path(__file__).parent / ".env")

# Old location -- kept only as a fallback so switching to .env doesn't
# break anyone mid-session who hasn't migrated yet. Stores the key in
# plain, unencrypted text; delete this file once .env is confirmed
# working (see module SETUP notes above).
_LEGACY_KEY_PATH = Path(__file__).parent / "gemini_api_key.txt"

SYSTEM_PROMPT = (
    "You are Jarvis, a voice assistant running on the user's Windows PC. "
    "Your replies are converted to speech and read aloud, so brevity is "
    "critical: answer in ONE short sentence whenever possible, two at "
    "most. Only go longer if the user explicitly asks for more detail "
    "or a list. Never use markdown, bullet points, or asterisks -- "
    "speak naturally like a person talking, not like you're writing a "
    "document. Skip preamble, caveats, and offers to help further "
    "unless truly needed. "
    "You also have tools that actually open apps, close apps, open "
    "folders, copy or move files, take a screenshot, lock the PC, and "
    "check system performance or CPU temperature on the user's real "
    "computer. If the user's request describes one of these actions, "
    "call the matching tool instead of just explaining how they'd do it "
    "themselves -- then confirm in FIVE WORDS OR FEWER, with no "
    "\"I've\" or \"I have\" (e.g. \"Done.\", \"Opened Notepad.\", "
    "\"Copied.\"). Spoken length is latency. "
    "IMPORTANT -- never invent information. Speech recognition on this "
    "PC sometimes cuts off the end of what the user said, so a request "
    "may arrive incomplete or ambiguous. If that happens, or if you "
    "don't have a tool that actually covers what's being asked, say so "
    "plainly and ask them to repeat or clarify -- do NOT guess at a "
    "plausible-sounding answer, and do NOT state specific facts, data, "
    "or list items (to-do items, reminders, file names, numbers, etc.) "
    "unless a tool call actually returned that exact information this "
    "turn. A wrong guess spoken aloud as fact is worse than admitting "
    "you didn't catch the request. "
    "CODE COMPLETION -- when the user asks you to write/complete/finish "
    "code that's visible on their screen (e.g. \"write it\", \"finish "
    "this\"), the screen usually already has real content: includes, "
    "function signatures, existing logic, and a placeholder marking "
    "where new code goes (a comment like \"// your logic here\", an "
    "empty block, etc.). In that case, type ONLY the missing piece that "
    "belongs at that placeholder -- never retype the includes, main(), "
    "existing variable declarations, or anything already on screen. "
    "Match the indentation and style already visible so it drops in "
    "cleanly. Only type a complete file from scratch if the screen is "
    "genuinely empty or the user explicitly asks for the whole thing. "
    "CRITICAL -- the code must actually compile against what's really "
    "there, not a plausible-looking guess: (1) reuse the EXACT variable "
    "names already declared on screen -- if it declared 'x', your logic "
    "must use 'x', never a different name like 'n' or 'num' even if "
    "that's more conventional; (2) never use a type, keyword, or "
    "function that needs a header not already included on screen -- "
    "e.g. don't use true/false/bool unless <stdbool.h> is already "
    "included, use 1/0 or an int flag instead if it isn't; (3) match "
    "the existing function's actual return type -- if it returns void, "
    "don't add a return statement with a value. When genuinely unsure "
    "whether something on screen supports what you're about to write, "
    "re-check it with the screen tool rather than assuming. "
    "FRESH SCREEN RULE -- every time the user asks you to write, "
    "complete, answer or type code for something on screen (including "
    "\"again\" / \"once more\"), FIRST call the screen tool in this same "
    "turn; never reuse an earlier screen description, because the "
    "window may have changed. Identify the problem by the exact title "
    "text shown on screen (e.g. a LeetCode title) and solve THAT "
    "problem, not a similar one. Never type the user's spoken words, "
    "like \"the java code again\", into the window. "
    "CODE INSERTION RULE -- insert code ONLY with paste_code_tool, never "
    "type_text_tool: code editors (LeetCode, VS Code) auto-indent and "
    "auto-close brackets while typing, which garbles the result. If the "
    "editor already has code that should be replaced (wrong solution, "
    "errors, starter template), call paste_code_tool with "
    "replace_existing=true and the COMPLETE code (for LeetCode Java: the "
    "whole 'class Solution { ... }'); only use replace_existing=false "
    "when filling a placeholder. Never say the code was replaced or fixed "
    "unless the tool returned success, and don't ask for permission "
    "first -- just do it. If the editor is empty or has no placeholder, "
    "write the full solution for the problem on screen without asking. "
    "Speech recognition sometimes hears the word code as quotes -- when "
    "the user is clearly working on a coding problem, treat quotes as "
    "code. "
    "SCREEN COPY RULE -- when the user asks to copy text or code from "
    "their screen, call copy_screen_text_tool. Never pass the user's "
    "spoken request (e.g. 'the entire code from my screen') to "
    "set_clipboard_tool; that tool is only for text the user dictates "
    "to be copied word for word. "
    "PASTE RULE -- when the user says paste (\"paste it\", \"paste the "
    "code\"), they mean the text already on the clipboard: press ctrl v "
    "with press_keys_tool. Never write your own version of the code and "
    "paste that with paste_code_tool unless they asked you to write code. "
    "SOLVE RULE -- for ANY math, aptitude, logical reasoning or "
    "multiple-choice question, NEVER answer from your own head. If the "
    "question is on the user's screen (e.g. 'answer the question on my "
    "screen'), call solve_problem_tool with from_screen=true and leave "
    "problem empty -- the tool looks at the screen itself, so do NOT "
    "retype or paraphrase the question. If the user spoke the question, "
    "call solve_problem_tool with problem set to exactly what they said. "
    "Speak its result as-is. Do not second-guess or change the answer. "
    "CODE RULE -- when the user wants CODE for a programming question "
    "(on screen or spoken), call solve_code_tool with the language they "
    "named (empty if none). Never type the code yourself. Speak its "
    "result as-is."
)

_client = None
_tools = None
_chat = None  # persistent chat session -- see CONVERSATION MEMORY above

# Primary model first; if Google returns 503/429 (overloaded / rate
# limited) ask_llm() rotates to the next one. Edit freely.
#
# MEASURED 2026-10-03 on this key (tiny prompt, no tools):
#   gemini-3.5-flash       ~1.1-1.3s  fast, BUT free tier = only 20
#                          requests/DAY (429 seen at 19:11) -> not a good primary
#   gemini-3.5-flash-lite  ~0.7-1.4s  fast; works with thinking_level="minimal"
#                          or no thinking setting; daily limit NOT yet checked
#                          (see https://ai.dev/rate-limit)
#   gemini-3.1-flash-lite  ~3.9-7.8s  slow and variable (6-11s seen in the log)
#   gemini-flash-lite-latest ~1.1s    works, but it's an alias that can change
#                          underneath you, so it is not in the chain
#   gemini-2.5-flash / 2.5-flash-lite: 404 "no longer available to new
#       users" -- they still SHOW UP in models.list() but cannot be
#       called with this key, so never put them back in this chain.
# thinking_budget=0 is rejected (400) by the 3.5-flash-lite family, which is
# why each model gets its own thinking setting (_thinking_config_for below).
MODEL_CHAIN = ["gemini-3.5-flash-lite", "gemini-3.5-flash", "gemini-3.1-flash-lite"]
_model_index = 0
_dead_models = set()        # models that returned 404 this run -- skipped from then on
_exhausted_until = {}       # model -> time.monotonic() until which its free daily quota is used up
_last_quota_error = None
_fallback_since = None      # when we first left the primary model (monotonic seconds)
PRIMARY_RETRY_SECONDS = 300  # after this long on a fallback, try the primary again


def register_tools(tools):
    """Registers the list of Python functions Gemini is allowed to call
    directly (function calling / tool use). Called once at startup from
    jarvis_up.py, which owns the actual action functions. Forces the
    chat to be rebuilt with these tools on the next request. (No
    separate "model" object to reset anymore -- see the SDK NOTE at the
    top of this file. The client itself doesn't need rebuilding for a
    tools change, only the chat's config does.)"""
    global _tools, _chat
    _tools = tools
    _chat = None


def refresh_persona():
    """Forces the chat to be rebuilt on the next request, so a
    system-prompt-affecting preference change (currently: the user's
    name, set via remember_name_tool) takes effect immediately instead
    of only after Jarvis restarts."""
    global _chat
    _chat = None


def reset_chat():
    """Clears conversation history and starts a fresh chat on the next
    request, without needing to re-register tools. Not currently wired
    to any voice command, but here so a future 'forget our
    conversation' / 'start over' command has something to call."""
    global _chat
    _chat = None
    brain_openai.reset()


def _load_api_key() -> str:
    """Prefers GEMINI_API_KEY from .env / the environment. Falls back to
    the older gemini_api_key.txt if that's not set, so this change
    doesn't silently break anyone still on the old setup -- but prints
    a one-time reminder each run, since that file keeps the key in
    plain text rather than the more standard .env location."""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key

    if _LEGACY_KEY_PATH.exists():
        legacy_key = _LEGACY_KEY_PATH.read_text().strip()
        if legacy_key:
            print("Using gemini_api_key.txt (legacy, plain text). "
                  "Consider moving this to a .env file instead -- "
                  "see the SETUP notes at the top of llm_brain.py.")
            return legacy_key

    return ""


def _get_client():
    """Returns the google-genai Client, creating it once and reusing it.
    Unlike the old SDK's genai.configure() (a global, implicit setting),
    the new SDK uses an explicit Client object -- this is the only place
    that needs the API key. The client itself is independent of which
    tools/persona are active, so it never needs rebuilding the way the
    per-chat config does (see _build_chat_config())."""
    global _client
    if _client is not None:
        return _client

    api_key = _load_api_key()
    if not api_key:
        return None

    _client = genai.Client(api_key=api_key)
    return _client


# Models that reject thinking_budget=0 (400 INVALID_ARGUMENT, measured) and
# want thinking_level instead. Everything else uses thinking_budget=0.
_THINKING_LEVEL_MODELS = {"gemini-3.5-flash-lite", "gemini-flash-lite-latest"}


def _thinking_config_for(model: str):
    """Fastest thinking setting that THIS model accepts, or None to use the
    model's own default (still works, just maybe slower)."""
    try:
        if model in _THINKING_LEVEL_MODELS:
            return types.ThinkingConfig(thinking_level="minimal")
        return types.ThinkingConfig(thinking_budget=0)
    except (AttributeError, TypeError, ValueError) as e:
        logger.warning(
            f"thinking setting for {model} not supported by this google-genai "
            f"version -- using the model's default thinking behavior "
            f"instead. ({e!r})"
        )
        return None


def _build_system_instruction() -> str:
    """SYSTEM_PROMPT plus remembered user facts. Shared by Gemini and the
    other brains (Groq / OpenRouter / Ollama)."""
    system_instruction = SYSTEM_PROMPT
    prefs = memory.get_all_preferences()
    if prefs:
        facts_lines = []
        name = prefs.pop("name", None)
        if name:
            facts_lines.append(f"The user's name is {name}.")
        if prefs:
            fact_list = "; ".join(f"{k}: {v}" for k, v in prefs.items())
            facts_lines.append(f"Other things you know about the user: {fact_list}.")
        system_instruction += (
            " " + " ".join(facts_lines) +
            " Use these naturally when relevant, but don't force them "
            "into every reply or list them out unprompted -- that gets "
            "annoying fast."
        )
    return system_instruction


def _all_tools() -> list:
    return list(_tools or []) + [solve_problem_tool, solve_code_tool]


def _build_chat_config(model: str = None):
    """Builds the GenerateContentConfig passed to client.chats.create():
    system instruction (including any remembered user facts), the
    registered tool functions, and thinking_budget=0 (see below) --
    all as direct fields on ONE config object. This replaces the old
    SDK's split between GenerativeModel(...) (model name, system
    instruction, tools) and a separate GenerationConfig (thinking
    settings) -- the new SDK collapses all of that into this single
    object, passed fresh to chats.create() each time the chat is
    (re)built."""
    system_instruction = _build_system_instruction()

    # Explicitly forcing the lowest thinking setting removes (or minimizes)
    # the model's internal reasoning for one-line spoken answers -- logs
    # showed trivial questions occasionally taking 9-11s inside the Gemini
    # call when left on the model's default. Which setting is accepted
    # differs per model, see _thinking_config_for(); if the installed SDK
    # doesn't know it we log once and fall back to the model default
    # rather than crashing Jarvis over a latency optimization.
    thinking_config = _thinking_config_for(model or MODEL_CHAIN[_model_index])

    return types.GenerateContentConfig(
        system_instruction=system_instruction,
        tools=_all_tools(),
        thinking_config=thinking_config,
    )


def _get_chat(history=None):
    """Returns the ongoing chat session, creating it the first time (or
    after register_tools()/refresh_persona()/reset_chat() cleared it).
    Reusing the same chat object across calls is what lets Gemini see
    prior turns -- see the CONVERSATION MEMORY note at the top of this
    file. Automatic function calling is the google-genai SDK's default
    whenever plain Python functions are passed as tools -- no extra
    flag needed here, unlike the old SDK's
    enable_automatic_function_calling=True."""
    global _chat
    if _chat is not None:
        return _chat

    client = _get_client()
    if client is None:
        return None

    _chat = client.chats.create(
        # gemini-2.0-flash was discontinued by Google (404 error).
        # gemini-3.6-flash worked but defaults to "medium" thinking
        # effort, adding ~22s of internal reasoning even for trivial
        # questions. gemini-3.1-flash-lite defaults to MINIMAL thinking
        # effort -- built for fast, simple Q&A like this. Still free tier.
        model=MODEL_CHAIN[_model_index],
        config=_build_chat_config(MODEL_CHAIN[_model_index]),
        history=history,
    )
    return _chat


def _web_search_snippets(query: str, max_results: int = 3) -> str:
    """Free, keyless web search via ddgs. Returns a short block of
    result snippets, or an empty string if the search fails or finds
    nothing -- callers should treat that as "no extra context available"
    rather than an error."""
    try:
        with DDGS(timeout=5) as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
    except Exception:
        return ""

    if not results:
        return ""

    lines = []
    for r in results:
        title = r.get("title", "")
        body = r.get("body", "")
        if title or body:
            lines.append(f"- {title}: {body}")
    return "\n".join(lines)


_LIVE_SEARCH_KEYWORDS = (
    "current", "currently", "latest", "today", "right now", "this week",
    "this year", "recent", "news", "score", "weather", "price", "stock",
    "who is", "who's", "what year is it", "what's the date",
    "president", "prime minister", "chief minister", "governor",
    "ceo of", "mayor of", "cm of",
    "who won", "winner", "match result", "released", "release date",
    "trending", "exchange rate", "gold rate", "petrol", "diesel",
    "bitcoin", "forecast", "headlines", "what happened", "will it rain",
    "is it raining",
)
# Leading \b only, so "train" never matches "rain" but "scores" still
# matches "score".
_LIVE_SEARCH_RE = re.compile(
    r"\b(?:" + "|".join(re.escape(k) for k in _LIVE_SEARCH_KEYWORDS) + ")"
)


def _needs_live_search(text: str) -> bool:
    """Cheap heuristic: only questions that plausibly need up-to-date
    info pay the cost of an extra web-search round-trip. Errs toward
    skipping search -- Gemini's own knowledge answers most everyday
    questions ("tell me a joke", "how do I...", casual chat) perfectly
    well without it, and skipping is what actually saves the latency.

    NOTE (2026-09-12 bugfix): this used to only match "who is the" /
    "who's the" verbatim, so "who is CM of Tamil Nadu" (no "the")
    fell through untouched and Gemini answered from stale training
    data -- then doubled down and "corrected" the user's accurate
    real-time answer back to the wrong one. Broadened "who is the" ->
    "who is" (and "who's the" -> "who's"), and added explicit
    officeholder-title keywords (chief minister, president, prime
    minister, governor, ceo of, mayor of) as a safety net for
    phrasings that skip "who is" entirely, e.g. "chief minister of
    Tamil Nadu"."""
    return bool(_LIVE_SEARCH_RE.search(text.lower()))


# ---------------------------------------------------------------------
# LIVE CONTEXT -- date/time, weather, news
# ---------------------------------------------------------------------
# Edit these to your own location (used when you just say "weather").
DEFAULT_PLACE = ("Salem", 11.6643, 78.1460)

_WMO = {
    0: "clear", 1: "mostly clear", 2: "partly cloudy", 3: "overcast",
    45: "foggy", 48: "foggy", 51: "light drizzle", 53: "drizzle",
    55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
    71: "light snow", 73: "snow", 75: "heavy snow", 80: "rain showers",
    81: "rain showers", 82: "heavy showers", 95: "thunderstorms",
    96: "thunderstorms with hail", 99: "thunderstorms with hail",
}


def _now_line() -> str:
    """Local date/time from the PC clock -- free, instant, no network.
    Prepended to every prompt so "what day is it", "what time is it"
    and relative phrases ("this Friday") never need a search."""
    return datetime.now().astimezone().strftime(
        "Current local date and time: %A, %d %B %Y, %I:%M %p %Z."
    )


def _http_json(url: str, timeout: float = 4.0):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.load(r)


def _weather_context(text: str) -> str:
    """Real forecast data from Open-Meteo (free, keyless). Understands
    "weather in <city>"; otherwise uses DEFAULT_PLACE. Returns "" on any
    failure so the caller falls back to a normal web search."""
    try:
        t = text.lower().strip(" ?.!")
        m = re.search(
            r"\b(?:in|at|for|of)\s+([a-z][a-z .'-]*?)"
            r"\s*(?:today|now|right now|tonight|tomorrow|please)?$", t)
        city = m.group(1).strip() if m else ""
        if city in ("", "today", "now", "tomorrow", "tonight", "me", "here"):
            name, lat, lon = DEFAULT_PLACE
        else:
            g = _http_json(
                "https://geocoding-api.open-meteo.com/v1/search?count=1&name="
                + urllib.parse.quote(city))
            hit = (g.get("results") or [None])[0]
            if not hit:
                return ""
            name, lat, lon = hit["name"], hit["latitude"], hit["longitude"]

        w = _http_json(
            "https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}&timezone=auto&forecast_days=2"
            "&current=temperature_2m,apparent_temperature,weather_code,"
            "wind_speed_10m"
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,"
            "precipitation_probability_max")
        c, d = w["current"], w["daily"]

        def day(i, label):
            return (f"{label}: {_WMO.get(d['weather_code'][i], 'mixed')}, "
                    f"high {d['temperature_2m_max'][i]:.0f}, "
                    f"low {d['temperature_2m_min'][i]:.0f} degrees C, "
                    f"{d['precipitation_probability_max'][i]}% chance of rain")

        return (
            f"- Weather in {name} right now: "
            f"{c['temperature_2m']:.0f} degrees C "
            f"(feels like {c['apparent_temperature']:.0f}), "
            f"{_WMO.get(c['weather_code'], 'mixed')}, "
            f"wind {c['wind_speed_10m']:.0f} km/h.\n"
            f"- {day(0, 'Today')}\n- {day(1, 'Tomorrow')}"
        )
    except Exception as e:
        logger.warning(f"Open-Meteo lookup failed, falling back to web search: {e!r}")
        return ""


def _news_snippets(query: str, max_results: int = 4) -> str:
    try:
        with DDGS(timeout=5) as ddgs:
            results = list(ddgs.news(query, max_results=max_results))
    except Exception:
        return ""
    return "\n".join(
        f"- {r.get('title', '')}: {r.get('body', '')}"
        for r in results if r.get("title") or r.get("body")
    )


def _live_context(text: str) -> str:
    """Routes a time-sensitive question to the best free source:
    weather -> Open-Meteo, news -> ddgs news, anything else -> ddgs text.
    Each falls back to the generic web search if it comes back empty."""
    t = text.lower()
    ctx = ""
    if re.search(r"\b(weather|forecast|will it rain|is it raining)\b", t):
        ctx = _weather_context(text)
    elif re.search(r"\b(news|headlines)\b", t):
        ctx = _news_snippets(text)
    return ctx or _web_search_snippets(text)


def _is_transient(e: Exception) -> bool:
    msg = str(e).upper()
    return any(k in msg for k in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED",
                                  "500", "INTERNAL", "DEADLINE", "TIMEOUT", "OVERLOADED"))


def _is_model_missing(e: Exception) -> bool:
    """A 404 means THIS model can't be used with this key (e.g. 'no longer
    available to new users') -- retrying it is pointless, so the caller
    skips it for the rest of the run and moves to the next model."""
    msg = str(e).upper()
    return "NOT_FOUND" in msg or "NO LONGER AVAILABLE" in msg


def _is_daily_quota(e: Exception) -> bool:
    """429 caused by the free tier's PER-DAY request cap (seen in the log:
    gemini-3.5-flash allows only 20 requests/day, then 'retry in 10h').
    Retrying the same model is pointless; a per-MINUTE 429 is different
    and still goes through the normal short-retry path."""
    msg = str(e).upper()
    return "RESOURCE_EXHAUSTED" in msg and "PERDAY" in msg


def _quota_retry_seconds(e: Exception, default: float = 3600.0) -> float:
    """Reads the 'retryDelay' Google puts in the 429 (e.g. '37106s')."""
    m = re.search(r"retryDelay'\s*:\s*'(\d+(?:\.\d+)?)s'", str(e))
    try:
        return float(m.group(1)) if m else default
    except Exception:
        return default


def _is_available(model: str) -> bool:
    return (model not in _dead_models
            and _exhausted_until.get(model, 0) <= time.monotonic())


def _next_alive_index():
    """Index of the next model after the current one that is usable (not
    404-dead, not out of daily quota), or None if there isn't one."""
    for i in range(_model_index + 1, len(MODEL_CHAIN)):
        if _is_available(MODEL_CHAIN[i]):
            return i
    return None


def _switch_model(new_index: int):
    """Moves to MODEL_CHAIN[new_index], carrying the conversation history
    over so Gemini keeps the context of this run."""
    global _chat, _model_index, _fallback_since
    try:
        history = _chat.get_history() if _chat is not None else None
    except Exception:
        history = None
    _model_index = new_index
    if new_index == 0:
        _fallback_since = None
    elif _fallback_since is None:
        _fallback_since = time.monotonic()
    _chat = None
    _chat = _get_chat(history=history)
    logger.warning(f"Switched Gemini model to {MODEL_CHAIN[_model_index]}")


def _maybe_return_to_primary():
    """Without this, one temporary error on the primary left Jarvis on a
    fallback model for the rest of the run. After PRIMARY_RETRY_SECONDS
    on a fallback, go back to the primary (unless it's marked dead)."""
    if (_model_index != 0 and _fallback_since is not None
            and _is_available(MODEL_CHAIN[0])
            and time.monotonic() - _fallback_since > PRIMARY_RETRY_SECONDS):
        logger.info(f"Retrying primary Gemini model {MODEL_CHAIN[0]}")
        _switch_model(0)


def _send_with_retry(prompt: str):
    """Sends to Gemini. On a temporary error (503 'high demand', per-minute
    429) it retries once on the same model after a short wait, then moves
    down MODEL_CHAIN, keeping the conversation history. On a 404 or a
    used-up DAILY quota it skips straight to the next model (no waiting)
    and doesn't touch that model again until it's usable. Any other error
    is raised."""
    global _last_quota_error
    last_error = None
    same_model_retried = False
    _maybe_return_to_primary()
    for _ in range(len(MODEL_CHAIN) + 2):
        model = MODEL_CHAIN[_model_index]
        if not _is_available(model):
            nxt = _next_alive_index()
            if nxt is None:
                raise _last_quota_error or last_error or RuntimeError("no usable Gemini model")
            _switch_model(nxt)
            model = MODEL_CHAIN[_model_index]
        chat = _get_chat()
        if chat is None:
            raise RuntimeError("no chat available")
        try:
            return chat.send_message(message=prompt)
        except Exception as e:
            last_error = e
            if _is_model_missing(e):
                logger.warning(f"Gemini model {model} is unavailable for this key "
                               f"-- skipping it for this run: {e!r}")
                _dead_models.add(model)
            elif _is_daily_quota(e):
                delay = _quota_retry_seconds(e)
                _exhausted_until[model] = time.monotonic() + delay
                _last_quota_error = e
                logger.warning(f"Gemini free daily quota used up on {model}; "
                               f"skipping it for about {delay / 3600:.1f}h")
            elif _is_transient(e):
                logger.warning(f"Gemini transient error on {model}: {e!r}")
                if not same_model_retried:
                    same_model_retried = True
                    time.sleep(1.5)          # first try: same model again
                    continue
            else:
                raise
            nxt = _next_alive_index()
            if nxt is None:
                break
            _switch_model(nxt)
    raise last_error


# ---------------------------------------------------------------------
# SOLVER -- careful reasoning for math / aptitude / MCQ questions
# ---------------------------------------------------------------------
# The normal chat runs with thinking minimal + "answer in one sentence",
# which is great for speed but means multi-step problems (profit and
# discount, ratios, time and work...) get a guessed answer. This tool does
# a separate call with high thinking and a "work it out, then verify
# against every option" prompt. Gemini calls it automatically (see the
# SOLVE RULE in SYSTEM_PROMPT).
SOLVER_MODELS = ["gemini-3.5-flash", "gemini-3.5-flash-lite"]
# ADAPTIVE SPEED: try a fast pass first (low thinking, a few seconds); only
# if it is unsure, matched no option, or could not be parsed, run a careful
# pass (high thinking). Easy questions get answered fast, hard ones still
# get the full treatment.
SOLVER_LEVELS = ("low", "high")
_last_solve = None  # (finished_at, key, spoken_result) -- dedupes retried tool calls

_SOLVER_PROMPT = (
    "You are an exact problem solver for aptitude, maths and logical "
    "reasoning questions. Work step by step and compute carefully. If "
    "options are given, substitute your result back into the question "
    "and confirm it matches exactly one option before answering. Re-read "
    "the question for traps (discount on marked price vs cost price, "
    "successive percentages, units). "
    "STRICT RULES: (0) Use ONLY the options that appear in the text. If "
    "no options are given, just give the computed value and say no "
    "options were provided. Never create options yourself. (1) Compute EXACTLY what is written. Never change an "
    "operator, number or word (for example % to //) to make an option "
    "fit. (2) If your exact result is only a rounding difference from an "
    "option, choose that option. If it clearly matches NO option, do not "
    "pick the nearest one: answer 'none of the options, my result is "
    "<value>'. (3) If the question data is impossible or inconsistent, "
    "give the standard textbook answer but add 'note: the question data "
    "is inconsistent'. (4) The text came from screen OCR, so if a symbol "
    "looks misread, say so instead of silently fixing it. "
    "Finish with exactly these two lines: "
    "ANSWER: <option letter or number and its value>\n"
    "CONFIDENCE: high or low. Use low if the problem had many steps, "
    "any calculation felt shaky, the result matched no option, or the "
    "text looked misread."
)


def _grab_screen_part():
    """Screenshot of the primary monitor as a Gemini image part, or None."""
    try:
        import io
        from PIL import ImageGrab
        img = ImageGrab.grab().convert("RGB")
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=85)
        return types.Part.from_bytes(data=buf.getvalue(), mime_type="image/jpeg")
    except Exception as e:
        logger.warning(f"Screen capture for solver failed: {e!r}")
        return None


def _solver_config(level: str, prompt: str = None):
    kwargs = dict(
        system_instruction=prompt or _SOLVER_PROMPT,
        thinking_config=types.ThinkingConfig(thinking_level=level),
    )
    try:  # cap a hung call (a 429'd model once hung ~80s) at 40s
        kwargs["http_options"] = types.HttpOptions(timeout=40000)
    except Exception:
        pass
    return types.GenerateContentConfig(**kwargs)


def _run_solver(client, contents, level: str, prompt: str = None):
    """One pass at the given thinking level, trying each solver model in
    turn. Returns (model, text, last_error)."""
    last_error = None
    for model in SOLVER_MODELS:
        if not _is_available(model):
            continue
        try:
            resp = client.models.generate_content(
                model=model, contents=contents, config=_solver_config(level, prompt))
            out = (resp.text or "").strip()
            if out:
                return model, out, last_error
        except Exception as e:
            last_error = e
            logger.warning(f"Solver failed on {model} (level={level}): {e!r}")
            if _is_model_missing(e):
                _dead_models.add(model)
            elif _is_daily_quota(e):
                _exhausted_until[model] = time.monotonic() + _quota_retry_seconds(e)
    return None, "", last_error


def _needs_careful_pass(out: str, ans: str) -> bool:
    """True when the fast answer should not be trusted as-is."""
    conf = re.findall(r"CONFIDENCE:\s*(high|low)", out, flags=re.I)
    if not conf or conf[-1].lower() != "high":
        return True
    return "none of the options" in ans.lower()


def solve_problem_tool(problem: str = "", from_screen: bool = False) -> str:
    """Solves a math, aptitude, logical reasoning or multiple-choice
    question with careful step-by-step thinking and returns the verified
    final answer. Use this for ANY such question instead of answering
    directly.

    Args:
        problem: The question exactly as the user SPOKE it, with options
            if given. Leave empty when from_screen is true.
        from_screen: True when the question is on the user's screen. The
            tool then looks at the screen itself, so do not retype it.
    """
    client = _get_client()
    if client is None:
        return "I don't have a brain connected yet."
    result = solver.solve(client, problem, from_screen,
                          is_available=_is_available,
                          on_model_error=_note_solver_error)
    if result == solver.CODING:
        logger.info("SOLVER saw a coding question -> code tool")
        return solve_code_tool("")
    return result


def _note_solver_error(model: str, e: Exception):
    """Keeps the 404 / daily-quota bookkeeping the old solver did."""
    if _is_model_missing(e):
        _dead_models.add(model)
    elif _is_daily_quota(e):
        _exhausted_until[model] = time.monotonic() + _quota_retry_seconds(e)


# ---------------------------------------------------------------------
# CODE SOLVER -- "write the java code for the question on my screen"
# ---------------------------------------------------------------------
# One Gemini call looks at the screen, writes the solution and puts it on
# the clipboard ("say paste it" then inserts it). Skips the extra
# "relay the tool result" round trip that used to add 6-11 s.
_CODE_PROMPT = (
    "You are an expert programmer. Look at the screenshot, find the "
    "programming question and write a complete, correct, efficient "
    "solution. If the screen shows a starter template (for example "
    "LeetCode's 'class Solution' with a method signature), keep exactly "
    "that class and signature. Reply in EXACTLY this format and nothing "
    "else:\n"
    "TITLE: <short problem name>\n"
    "LANG: <language name>\n"
    "```<language>\n<only the code, no explanation>\n```"
)

CODE_AUTO_PASTE = True       # paste the code straight into the focused editor (Ctrl+V)
CODE_REPLACE_EDITOR = True   # True: Ctrl+A first, so the solution replaces the starter code
                             # (Ctrl+Z undoes it). False: insert at the cursor instead.

_CODE_LANGS = [
    ("c plus plus", "C++"), ("c++", "C++"), ("cpp", "C++"),
    ("c sharp", "C#"), ("c#", "C#"), ("javascript", "JavaScript"),
    ("java script", "JavaScript"), ("java", "Java"), ("python", "Python"),
    ("golang", "Go"), ("kotlin", "Kotlin"), ("rust", "Rust"),
    ("typescript", "TypeScript"), ("swift", "Swift"),
]

_CODING_HINTS = re.compile(
    r"(```|leetcode|hackerrank|codeforces|\bwrite (?:a |the )?(?:program|function|code)\b"
    r"|\breturn (?:a|the) (?:list|array|string|integer|boolean)\b"
    r"|\bgiven (?:an?|the) (?:array|string|linked list|tree|integer|matrix|graph)\b"
    r"|\bimplement\b|\balgorithm\b|\bsample (?:input|output)\b|\btest cases?\b"
    r"|\btime complexity\b|\bclass solution\b)", re.I)


def _looks_like_coding(text: str) -> bool:
    return bool(_CODING_HINTS.search(text or ""))


def _copy_to_clipboard(text: str) -> bool:
    try:
        from clipboard_control import set_clipboard_text
        return bool(set_clipboard_text(text))
    except ImportError:
        pass
    except Exception as e:
        logger.warning(f"clipboard_control failed: {e!r}")
        return False
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except Exception as e:
        logger.warning(f"Clipboard copy failed: {e!r}")
        return False


def solve_code_tool(language: str = "", problem: str = "") -> str:
    """Writes working code for a programming question shown on the user's
    screen (or spoken in `problem`) and puts it on the clipboard. Use this
    when the user asks for code for a question, e.g. 'write the java code
    for the question on my screen'.

    Args:
        language: Programming language the user asked for (Java, Python,
            C++...). Leave empty if they did not name one.
        problem: Only if the question was spoken instead of on screen.
    """
    client = _get_client()
    if client is None:
        return "I don't have a brain connected yet."
    lang = (language or "").strip()
    lang_line = (f"Write the solution in {lang}." if lang else
                 "Write it in the language shown in the code editor on the "
                 "screen; if none is visible, use Python.")
    shot = _grab_screen_part()
    if shot is not None:
        contents = [shot, "Find the programming question on this screen and "
                          "solve it. " + lang_line]
    elif problem.strip():
        contents = f"{problem}\n{lang_line}"
    else:
        return "I couldn't capture the screen."

    last_error = None
    code = title = found_lang = None
    for level in SOLVER_LEVELS:
        model, out, err = _run_solver(client, contents, level, _CODE_PROMPT)
        if err is not None:
            last_error = err
        if not out:
            continue
        logger.info(f"CODE_SOLVER model={model} level={level} lang={lang!r}")
        m = re.search(r"```[^\n]*\n(.*?)```", out, re.S)
        if not m:
            continue
        code = m.group(1).rstrip() + "\n"
        t = re.search(r"TITLE:\s*(.+)", out)
        l = re.search(r"LANG:\s*(.+)", out)
        title = t.group(1).strip() if t else ""
        found_lang = (l.group(1).strip() if l else "") or lang
        break

    if not code:
        logger.error(f"Code solver gave up: {last_error!r}")
        return "I couldn't write that code. Please try again."
    if not _copy_to_clipboard(code):
        return "I wrote the code but couldn't copy it to the clipboard."
    what = f"{found_lang} code" if found_lang else "The code"
    if title:
        what += f" for {title}"
    if CODE_AUTO_PASTE:
        try:
            from keyboard_control import press_keys
            time.sleep(0.2)
            if CODE_REPLACE_EDITOR:
                press_keys("ctrl a")
                time.sleep(0.2)
            press_keys("ctrl v")
            return f"{what} is typed into your editor."
        except Exception as e:
            logger.warning(f"Auto-paste failed, code stays on clipboard: {e!r}")
    return f"{what} is on your clipboard. Say paste it to insert it."


def _fast_screen_reply(text: str):
    """Direct route for 'answer/solve/write code for the question on my
    screen': runs the tool right away instead of asking the chat model to
    call it and then re-word the result (that detour cost 6-11 s and
    sometimes produced a wrong 'I can't see the problem'). Returns the
    reply text, or None when the request is something else."""
    t = text.lower().strip()
    if not re.search(r"\b(question|problem|task)\b", t):
        return None
    wants_code = bool(re.search(
        r"\b(code|program|solution|java|python|cpp|javascript|c\+\+|c#)", t))
    on_screen = "screen" in t
    # also catch a misheard "...code for the question" with no 'screen'
    if not on_screen and not (wants_code and len(t.split()) <= 8):
        return None
    try:
        if wants_code:
            lang = ""
            for key, name in _CODE_LANGS:
                if re.search(r"(?<![\w+#])" + re.escape(key) + r"(?![\w+#])", t):
                    lang = name
                    break
            return solve_code_tool(lang)
        if on_screen and re.search(r"\b(answer|solve)\b", t):
            return solve_problem_tool("", True)
    except Exception as e:
        logger.error(f"Fast screen route failed: {e!r}", exc_info=True)
    return None


_ANSWER_MISHEARS = re.compile(
    r"^(?:(?:oh|um|uh|hey|okay|ok),?\s+)?"
    r"(?:enter|inter|ansa|answered|answers|and sir|ans a)\s+"
    r"(?=(?:the|this)\s+(?:question|problem)\b.*\bscreen)",
    re.I)


def _fix_answer_command(text: str) -> str:
    """Whisper base.en often hears 'answer' as 'enter' (seen in the log),
    which made Jarvis treat the command as something else. Also handles
    a dropped first word ('the question on my screen')."""
    t = text.strip()
    t = _ANSWER_MISHEARS.sub("answer ", t)
    if re.match(r"^(?:the|this)\s+(?:question|problem)\b.*\bscreen", t, re.I):
        t = "answer " + t
    return t


def _prepare_prompt(text: str):
    """Builds the full prompt (live-search context, clock line, lessons).
    Shared by ask_llm() and ask_llm_stream(). Returns
    (prompt, did_search, t_start, t_after_search)."""
    t_start = time.monotonic()
    did_search = _needs_live_search(text)
    search_context = _live_context(text) if did_search else ""
    t_after_search = time.monotonic()

    if search_context:
        prompt = (
            "Here are current web search results:\n"
            f"{search_context}\n\n"
            "This question was flagged as likely needing up-to-date info, "
            "so treat these search results as more current and reliable "
            "than your own training knowledge for anything time-sensitive "
            "(current officeholders, prices, scores, dates, news) -- your "
            "training data has a cutoff and these results don't. Only "
            "disregard a result if it's clearly off-topic or contradicts "
            "itself, not because it conflicts with what you already "
            f"believed. Now answer this question: {text}"
        )
    else:
        prompt = text

    # Clock context on every turn (free, no network) -- see _now_line().
    prompt = f"[{_now_line()}]\n{lessons.prompt_block(text)}{prompt}"
    return prompt, did_search, t_start, t_after_search


MAX_HISTORY_MESSAGES = 12  # ~6 exchanges kept; older turns are dropped


def _trim_history():
    """Keeps only the most recent turns of the persistent chat so the
    prompt sent to Gemini never grows unbounded. Without this, every
    question, web-search result, and tool call from the whole run was
    re-sent on every request, making replies slower and slower (and
    hitting free-tier token limits -> 429 retries -> minutes of delay).
    Long-term facts (e.g. the user's name) live in memory.py, not here."""
    global _chat
    if _chat is None:
        return
    try:
        hist = list(_chat.get_history())
    except Exception:
        return
    if len(hist) <= MAX_HISTORY_MESSAGES:
        return
    hist = hist[-MAX_HISTORY_MESSAGES:]
    # history must start with a plain user turn, not a tool result
    while hist and not (
        hist[0].role == "user"
        and not any(getattr(p, "function_response", None)
                    for p in (hist[0].parts or []))
    ):
        hist = hist[1:]
    try:
        _chat = None
        _chat = _get_chat(history=hist)
    except Exception as e:
        logger.warning(f"History trim failed, starting a fresh chat: {e!r}")
        _chat = None


def ask_llm(text: str) -> str:
    """Sends text to Gemini (via the persistent chat session, so prior
    turns in this run are visible) and returns a spoken-friendly reply.
    Uses automatic function calling: if registered tools are available
    and Gemini decides the request needs one, it calls the Python
    function directly and folds the result into its final reply --
    callers here just get back the finished spoken text either way.
    Returns a clear fallback message instead of crashing if no API key
    is set up yet, or if the call fails for any reason (offline, rate
    limit, etc.)."""
    text = _fix_answer_command(text)
    _fast = _fast_screen_reply(text)
    if _fast is not None:
        return _fast

    # Non-Gemini brain selected ("change brain to groq"): try it first,
    # fall through to Gemini below if it fails.
    if brain_switch.get_brain() != "gemini":
        name = brain_switch.get_brain()
        try:
            prompt, *_ = _prepare_prompt(text)
            reply = brain_openai.ask(name, prompt, _build_system_instruction(), _all_tools())
            if reply:
                logger.info(f"LLM_BRAIN {name} ok")
                return reply
        except Exception as e:
            logger.error(f"{name} brain failed, falling back to Gemini: {e!r}", exc_info=True)

    chat = _get_chat()
    if chat is None:
        return ("I don't have a brain connected yet. Add your Gemini "
                "API key to a .env file (GEMINI_API_KEY=your_key) in "
                "this folder to enable this.")

    prompt, did_search, t_start, t_after_search = _prepare_prompt(text)

    try:
        # google-genai's Chat.send_message takes `message` as a keyword
        # argument (the old SDK accepted it positionally).
        response = _send_with_retry(prompt)
        _trim_history()
        t_after_llm = time.monotonic()

        # Records which tool(s), if any, Gemini actually invoked this
        # turn -- added after a real incident (2026-09-13) where a
        # garbled/incomplete transcript ("list the apps you scanned in
        # my [cut off]") got a confident-sounding but entirely
        # fabricated answer ("you have chocolate on your to-do list"),
        # and there was no way to tell after the fact whether that came
        # from a misrouted tool call or pure hallucination. Now that's
        # answerable by reading this line instead of guessing.
        #
        # SDK NOTE: the old SDK exposed this via response.candidates
        # (each with a function_call part). The new SDK's automatic
        # function calling instead records the full call-and-respond
        # exchange in response.automatic_function_calling_history -- a
        # list of Content objects, each with .parts the same shape as
        # before.
        called_tools = []
        for content in (getattr(response, "automatic_function_calling_history", None) or []):
            for part in content.parts:
                fc = getattr(part, "function_call", None)
                if fc and fc.name:
                    called_tools.append(f"{fc.name}({dict(fc.args)})")
        logger.info(f"TOOLS_CALLED: {called_tools if called_tools else 'none'}")

        # LLM_TIMING -- separates "did the web search add latency" from
        # "was the Gemini call itself slow", since THINKING-state
        # duration alone (visible in the state-transition log lines)
        # conflates both. Every call logs this, not just slow ones, so
        # there's a normal-case baseline to compare a slow one against.
        logger.info(
            "LLM_TIMING model=%s words=%d searched=%s search=%.2fs gemini_call=%.2fs total=%.2fs",
            MODEL_CHAIN[_model_index], len(text.split()), did_search,
            t_after_search - t_start, t_after_llm - t_after_search,
            t_after_llm - t_start,
        )

        # response.text is a convenience property that raises a fairly
        # unfriendly library exception (mentioning "Part", "candidate",
        # "finish_reason" -- internal SDK terms) whenever the response
        # has no text content, which does happen occasionally (e.g. an
        # automatic function-calling turn that didn't come back with a
        # final text reply -- a known SDK-level rough edge, not unique
        # to this project). Checking the actual parts ourselves first
        # means that case gets a normal spoken response instead of that
        # raw exception being read aloud verbatim. response.candidates
        # is core Gemini API response shape, unchanged by the SDK
        # migration -- only the model/chat *creation* API changed.
        candidates = response.candidates or []
        parts = candidates[0].content.parts if candidates else []
        text_parts = [p.text for p in parts if getattr(p, "text", "")]

        if not text_parts:
            finish_reason = candidates[0].finish_reason if candidates else "unknown"
            logger.warning(
                f"Gemini returned no text content for text={text!r} "
                f"finish_reason={finish_reason!r}"
            )
            return "Sorry, I didn't quite get an answer for that -- could you try rephrasing?"

        return "".join(text_parts).strip()
    except Exception as e:
        t_after_error = time.monotonic()
        logger.info(
            "LLM_TIMING model=%s words=%d searched=%s search=%.2fs gemini_call=%.2fs (FAILED) total=%.2fs",
            MODEL_CHAIN[_model_index], len(text.split()), did_search,
            t_after_search - t_start, t_after_error - t_after_search,
            t_after_error - t_start,
        )
        logger.error(f"Gemini call failed for text={text!r}: {e!r}", exc_info=True)
        if _is_daily_quota(e):
            return ("I've used up today's free AI quota, so I can only do my "
                    "built-in commands for now.")
        if _is_transient(e):
            return "My brain is busy right now. Please try again in a moment."
        return "I couldn't reach my brain just now. Check the console for details."


# ---------------------------------------------------------------------
# STREAMING -- speak sentence by sentence while Gemini is still writing
# ---------------------------------------------------------------------
_SENT_END = re.compile(r'([.!?]+["\')\]]*)(\s+)')
_ABBREV = {"mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc",
           "e.g", "i.e", "no", "inc"}
MIN_CHUNK_CHARS = 20  # very short sentences get merged with the next one


def _pop_sentences(buf: str, flush: bool = False):
    """Splits complete sentences off the front of buf. Returns
    (sentences, leftover). flush=True also returns the leftover."""
    out = []
    start = 0
    for m in _SENT_END.finditer(buf):
        cand = buf[start:m.end(1)].strip()
        words = cand.split()
        if not words:
            continue
        if m.group(1)[0] == "." and words[-1].rstrip(".!?").lower() in _ABBREV:
            continue
        if len(cand) < MIN_CHUNK_CHARS:
            continue
        out.append(cand)
        start = m.end()
    rest = buf[start:]
    if flush and rest.strip():
        out.append(rest.strip())
        rest = ""
    return out, rest


def _chunk_text(chunk) -> str:
    try:
        cands = chunk.candidates or []
        if not cands or cands[0].content is None:
            return ""
        return "".join(
            p.text for p in (cands[0].content.parts or [])
            if getattr(p, "text", None) and not getattr(p, "thought", False)
        )
    except Exception:
        return ""


def ask_llm_stream(text: str, should_stop=None):
    """Generator version of ask_llm(): yields the reply one sentence at a
    time as Gemini writes it, so the caller can start speaking the first
    sentence while the rest is still being generated. should_stop is an
    optional callable; when it returns True the stream is abandoned
    (used when the user says "stop"). If the stream fails before any
    sentence was produced, falls back to the normal ask_llm() so all the
    retry / model-fallback / quota handling still applies."""
    text = _fix_answer_command(text)
    _fast = _fast_screen_reply(text)
    if _fast is not None:
        yield _fast
        return

    if brain_switch.get_brain() != "gemini":
        name = brain_switch.get_brain()
        n_out = 0
        try:
            prompt, *_ = _prepare_prompt(text)
            buf = ""
            for piece in brain_openai.stream(name, prompt, _build_system_instruction(),
                                             _all_tools(), should_stop):
                buf += piece
                sentences, buf = _pop_sentences(buf)
                for sent in sentences:
                    n_out += 1
                    yield sent
            sentences, buf = _pop_sentences(buf, flush=True)
            for sent in sentences:
                n_out += 1
                yield sent
        except Exception as e:
            logger.error(f"{name} brain stream failed: {e!r}", exc_info=True)
        if n_out or (should_stop is not None and should_stop()):
            return
        logger.warning(f"{name} gave nothing -- falling back to Gemini")

    _maybe_return_to_primary()
    chat = _get_chat()
    if chat is None:
        yield ("I don't have a brain connected yet. Add your Gemini "
               "API key to a .env file (GEMINI_API_KEY=your_key) in "
               "this folder to enable this.")
        return

    prompt, did_search, t_start, t_after_search = _prepare_prompt(text)
    buf = ""
    yielded = 0
    t_first = None
    last_afc = None
    try:
        for chunk in chat.send_message_stream(message=prompt):
            if should_stop is not None and should_stop():
                logger.info("LLM stream abandoned (interrupted)")
                return
            afc = getattr(chunk, "automatic_function_calling_history", None)
            if afc:
                last_afc = afc
            piece = _chunk_text(chunk)
            if not piece:
                continue
            buf += piece
            sentences, buf = _pop_sentences(buf)
            for sent in sentences:
                if t_first is None:
                    t_first = time.monotonic()
                yielded += 1
                yield sent
        sentences, buf = _pop_sentences(buf, flush=True)
        for sent in sentences:
            if t_first is None:
                t_first = time.monotonic()
            yielded += 1
            yield sent
    except Exception as e:
        logger.error(f"Gemini stream failed for text={text!r}: {e!r}", exc_info=True)
        if yielded == 0:
            yield ask_llm(text)   # full retry / fallback path
        return

    t_end = time.monotonic()
    called_tools = []
    for content in (last_afc or []):
        for part in (content.parts or []):
            fc = getattr(part, "function_call", None)
            if fc and fc.name:
                called_tools.append(f"{fc.name}({dict(fc.args)})")
    logger.info(f"TOOLS_CALLED: {called_tools if called_tools else 'none'}")
    logger.info(
        "LLM_STREAM_TIMING model=%s words=%d searched=%s search=%.2fs "
        "first_sentence=%.2fs total=%.2fs sentences=%d",
        MODEL_CHAIN[_model_index], len(text.split()), did_search,
        t_after_search - t_start,
        (t_first - t_after_search) if t_first else -1.0,
        t_end - t_start, yielded,
    )
    if yielded == 0:
        logger.warning(f"Gemini stream returned no text for text={text!r}")
        yield "Sorry, I didn't quite get an answer for that -- could you try rephrasing?"
        return
    _trim_history()
