"""
memory.py -- Jarvis's persistent memory layer (Phase 2 of the roadmap).

Two different kinds of "memory" live here, on purpose kept separate:

1. LONG-TERM (SQLite, survives restarts) -- notes, todos, reminders,
   and a running command_history log. Lives in jarvis_memory.db, next
   to this file, created automatically the first time this module is
   imported. Nothing here needs a schema migration tool yet -- these
   tables are simple enough that `CREATE TABLE IF NOT EXISTS` is fine
   for now.

2. SHORT-TERM (plain Python, in-memory only, cleared every restart) --
   tracks whatever list Jarvis most recently spoke or showed, so a
   follow-up like "open the second one" or "delete the first one" can
   resolve against it without needing to persist across sessions. This
   is intentionally NOT in the database -- it's conversational state,
   not something that should still make sense tomorrow.

Every long-term function opens its own short-lived connection rather
than keeping one connection open for the whole program. sqlite3
connections aren't safe to share across threads, and Jarvis's voice
loop is single-threaded but this keeps things simple and avoids any
"connection left open/stale" class of bug -- these are small, local
writes, so the per-call connection overhead is not worth optimizing
away.
"""

import sqlite3
import threading
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).parent / "jarvis_memory.db"

# Guards each connection/transaction. Not strictly required for a
# single-threaded caller, but cheap insurance if a future feature (e.g.
# a background reminder-checker thread) ever calls into this module
# from somewhere other than the main loop.
_lock = threading.Lock()


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def init_db():
    """Creates every table if it doesn't already exist. Safe to call
    every startup -- CREATE TABLE IF NOT EXISTS is a no-op once the
    schema is in place."""
    with _lock, _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS todos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                created_at TEXT NOT NULL,
                done INTEGER NOT NULL DEFAULT 0,
                done_at TEXT
            );

            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                remind_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                fired INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS preferences (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                command_text TEXT NOT NULL,
                response_text TEXT
            );
            """
        )


init_db()


# ---------------------------------------------------------------------
# Notes
# ---------------------------------------------------------------------

def add_note(text: str) -> int:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO notes (text, created_at) VALUES (?, ?)",
            (text, _now()),
        )
        return cur.lastrowid


def list_notes(limit: int = 20):
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT id, text, created_at FROM notes ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def delete_note(note_id: int) -> bool:
    with _lock, _connect() as conn:
        cur = conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        return cur.rowcount > 0


# ---------------------------------------------------------------------
# Todos
# ---------------------------------------------------------------------

def add_todo(text: str) -> int:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO todos (text, created_at, done) VALUES (?, ?, 0)",
            (text, _now()),
        )
        return cur.lastrowid


def list_todos(include_done: bool = False, limit: int = 20):
    with _lock, _connect() as conn:
        if include_done:
            query = ("SELECT id, text, done, created_at, done_at FROM todos "
                      "ORDER BY id DESC LIMIT ?")
        else:
            query = ("SELECT id, text, done, created_at, done_at FROM todos "
                      "WHERE done = 0 ORDER BY id DESC LIMIT ?")
        rows = conn.execute(query, (limit,)).fetchall()
        return [dict(r) for r in rows]


def complete_todo(todo_id: int) -> bool:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE todos SET done = 1, done_at = ? WHERE id = ? AND done = 0",
            (_now(), todo_id),
        )
        return cur.rowcount > 0


def delete_todo(todo_id: int) -> bool:
    with _lock, _connect() as conn:
        cur = conn.execute("DELETE FROM todos WHERE id = ?", (todo_id,))
        return cur.rowcount > 0


# ---------------------------------------------------------------------
# Reminders
# ---------------------------------------------------------------------

def add_reminder(text: str, remind_at: datetime) -> int:
    with _lock, _connect() as conn:
        cur = conn.execute(
            "INSERT INTO reminders (text, remind_at, created_at, fired) VALUES (?, ?, ?, 0)",
            (text, remind_at.isoformat(timespec="seconds"), _now()),
        )
        return cur.lastrowid


def get_due_reminders():
    """Reminders whose remind_at has passed and that haven't fired yet.
    Callers should mark each one fired (mark_reminder_fired) once it's
    actually been spoken, so it isn't repeated every loop."""
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT id, text, remind_at FROM reminders "
            "WHERE fired = 0 AND remind_at <= ? ORDER BY remind_at ASC",
            (_now(),),
        ).fetchall()
        return [dict(r) for r in rows]


def mark_reminder_fired(reminder_id: int):
    with _lock, _connect() as conn:
        conn.execute("UPDATE reminders SET fired = 1 WHERE id = ?", (reminder_id,))


def list_upcoming_reminders(limit: int = 20):
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT id, text, remind_at FROM reminders "
            "WHERE fired = 0 ORDER BY remind_at ASC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def delete_reminder(reminder_id: int) -> bool:
    with _lock, _connect() as conn:
        cur = conn.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
        return cur.rowcount > 0


# ---------------------------------------------------------------------
# Preferences -- simple key/value store. Not wired to anything yet;
# here so later phases (personality, routines) have a place to persist
# small settings without inventing a new table each time.
# ---------------------------------------------------------------------

def set_preference(key: str, value: str):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO preferences (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


def get_preference(key: str, default=None):
    with _lock, _connect() as conn:
        row = conn.execute(
            "SELECT value FROM preferences WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default


def get_all_preferences() -> dict:
    """Every stored preference as a key->value dict. Used to give Gemini
    full context about the user (name, favorite things, anything
    remembered via "remember that my X is Y") without it needing to be
    asked about each one individually."""
    with _lock, _connect() as conn:
        rows = conn.execute("SELECT key, value FROM preferences").fetchall()
        return {r["key"]: r["value"] for r in rows}


def get_all_keys() -> list[str]:
    """Returns a list of all preference keys currently saved in the database."""
    with _lock, _connect() as conn:
        rows = conn.execute("SELECT key FROM preferences").fetchall()
        return [str(row["key"]) for row in rows if row["key"]]


# ---------------------------------------------------------------------
# Command history -- a long-term log, separate from the short-term
# ConversationContext below. Useful later for "what did I ask you
# earlier" type queries, or for debugging what Jarvis actually heard
# over time (jarvis.log has this too, but that rotates and isn't
# queryable).
# ---------------------------------------------------------------------

def log_command(command_text: str, response_text: str = ""):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO command_history (timestamp, command_text, response_text) "
            "VALUES (?, ?, ?)",
            (_now(), command_text, response_text),
        )


def recent_history(limit: int = 10):
    with _lock, _connect() as conn:
        rows = conn.execute(
            "SELECT timestamp, command_text, response_text FROM command_history "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------
# SHORT-TERM conversation context -- in-memory only, cleared on
# restart. Lets a follow-up command resolve an ordinal ("the second
# one") or a bare "that" against whatever Jarvis most recently spoke
# or showed. Any command handler that reads a numbered list back to
# the user should call context.set_last_list(...) right after; any
# handler for a follow-up phrase should call context.resolve_ordinal(...).
# ---------------------------------------------------------------------

class ConversationContext:
    def __init__(self):
        self.last_list = []       # e.g. matching file paths, todo dicts
        self.last_list_kind = ""  # e.g. "files", "todos" -- lets callers sanity-check
        self.last_command = ""
        self.last_response = ""

    def set_last_list(self, items, kind: str = ""):
        self.last_list = list(items)
        self.last_list_kind = kind

    def resolve_ordinal(self, word: str):
        """word: 'first'/'1st'/'one', 'second'/'2nd'/'two', ... 'last'.
        Returns the matching item from last_list, or None if the word
        isn't a recognized ordinal or the list doesn't have that many
        items."""
        ordinals = {
            "first": 0, "1st": 0, "one": 0,
            "second": 1, "2nd": 1, "two": 1,
            "third": 2, "3rd": 2, "three": 2,
            "fourth": 3, "4th": 3, "four": 3,
            "fifth": 4, "5th": 4, "five": 4,
            "last": -1,
        }
        idx = ordinals.get(word.lower().strip())
        if idx is None:
            return None
        try:
            return self.last_list[idx]
        except IndexError:
            return None

    def remember_turn(self, command_text: str, response_text: str):
        self.last_command = command_text
        self.last_response = response_text


# One shared instance -- Jarvis runs single-threaded, single-session,
# so a module-level singleton is enough; no need for a class-per-user.
context = ConversationContext()