"""
command_router.py -- the Command Router that replaces jarvis_up.py's
giant if/elif chain, one domain at a time.

Each domain module exposes:
    try_handle(t: str, speak) -> bool

`t` is the lowercased, stripped transcript. `speak` is passed IN
(never imported back from jarvis_up.py) specifically to avoid a
circular import -- jarvis_up.py imports this router, so domain modules
importing jarvis_up.py back to get speak() would create a cycle.

DOMAINS is checked in order; the first one to return True wins and
dispatch() stops there -- same priority-matters behavior the old
single function had. Migrating a domain here should never change what
a given phrase does, only where that logic lives.

MIGRATION STATUS (2026-09-18): only clipboard has been moved here so
far, as the proof of concept. Everything else still lives in
jarvis_up.py's _dispatch_command(). jarvis_up.py tries this router
FIRST; if nothing here handles it, it falls through to the old
dispatcher unchanged. Domains get added here one at a time, each
tested before moving the next, rather than one large rewrite.
"""

import clipboard_commands
import file_commands
import weather_commands
import screen_commands
import whatsapp_commands
import window_commands

DOMAINS = [
    whatsapp_commands,      # first: 'open X's chat' must not be grabbed by file_commands
    window_commands,        # snap/maximize/minimize/'switch to <app>' -- narrow exact phrases, so before file/screen
    clipboard_commands,
    file_commands,
    weather_commands,
    screen_commands,
    # more domains land here as they're migrated out of
    # jarvis_up.py's _dispatch_command(), e.g.:
    # app_commands (needs its own business-logic module first --
    # APP_INDEX is currently a jarvis_up.py-level global),
    # system_commands, keyboard_commands, ...
]


def dispatch(t: str, speak) -> bool:
    """Tries each migrated domain in order. Returns True if one of
    them handled the command (and already called speak(...) with the
    result). Returns False if none of them recognized it, meaning the
    caller should fall back to the old dispatcher for anything not yet
    migrated."""
    for domain in DOMAINS:
        if domain.try_handle(t, speak):
            return True
    return False
