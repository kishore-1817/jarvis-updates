"""
cache.py -- short-lived cache of the last screenshot + OCR result, so
a quick follow-up ("what's on my screen" then "copy that text") reuses
the same capture instead of grabbing and OCR'ing the screen twice for
what's really one interaction.

Invalidated by either: TTL expiring, or the active window having
changed since the cached capture (comparing L0's cheap window title,
not re-running OCR just to check).
"""

import time

from . import capture, ocr, window_info

TTL_SECONDS = 8

_cache = {
    "timestamp": 0.0,
    "window_title": None,
    "screenshot": None,
    "text": None,
}


def get_capture_and_text(force_refresh: bool = False):
    """Returns (screenshot, ocr_text, window_info_dict) for the current
    screen -- reusing the cached capture if it's still fresh (within
    TTL_SECONDS) and the active window hasn't changed, otherwise
    capturing and OCR'ing fresh."""
    info = window_info.get_active_window_info()
    now = time.monotonic()

    cache_valid = (
        not force_refresh
        and _cache["screenshot"] is not None
        and (now - _cache["timestamp"]) < TTL_SECONDS
        and _cache["window_title"] == info["title"]
    )

    if cache_valid:
        return _cache["screenshot"], _cache["text"], info

    screenshot = capture.grab_screenshot()
    text = ocr.extract_text(screenshot)

    _cache["timestamp"] = now
    _cache["window_title"] = info["title"]
    _cache["screenshot"] = screenshot
    _cache["text"] = text

    return screenshot, text, info
