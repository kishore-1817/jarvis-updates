"""
On-screen answer banner for the Ctrl+Alt+S hotkey.

show(text, seconds):
  The banner now ALWAYS hides itself after DISPLAY_SECONDS (2 s), whatever
  the caller passes. Change DISPLAY_SECONDS below to adjust it; set it to
  None to go back to "stays until the next answer or a right-click".

It never takes keyboard focus, can be dragged with the left mouse button,
and keeps re-asserting "always on top" (Windows) so other windows are much
less likely to cover it. Runs in its own tkinter thread, so it can't
interfere with the HUD or the Ctrl+Alt+J type box.
"""
import os
import queue
import threading
import logging

logger = logging.getLogger("jarvis")

# How long the answer stays on screen. Overrides whatever the caller passes.
DISPLAY_SECONDS = 2.0

_q = queue.Queue()
_start_lock = threading.Lock()
_started = False

_GWL_EXSTYLE = -20
_WS_EX_TOPMOST, _WS_EX_TOOLWINDOW, _WS_EX_NOACTIVATE = 0x8, 0x80, 0x08000000
_HWND_TOPMOST = -1
_SWP_FLAGS = 0x0001 | 0x0002 | 0x0010 | 0x0040   # NOSIZE|NOMOVE|NOACTIVATE|SHOWWINDOW


def _loop():
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        win = tk.Toplevel(root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.attributes("-alpha", 0.96)
        win.configure(bg="#00d4ff")
        inner = tk.Frame(win, bg="#0b1220")
        inner.pack(padx=2, pady=2)
        wrap = max(300, min(900, win.winfo_screenwidth() - 160))
        label = tk.Label(inner, text="", fg="#e6f1ff", bg="#0b1220",
                         font=("Segoe UI", 20, "bold"), wraplength=wrap,
                         justify="center", padx=28, pady=18)
        label.pack()
        win.withdraw()

        state = {"after": None, "visible": False, "hwnd": None, "drag": None}

        def get_hwnd():
            if state["hwnd"] or os.name != "nt":
                return state["hwnd"]
            import ctypes
            u = ctypes.windll.user32
            h = u.GetParent(win.winfo_id()) or win.winfo_id()
            style = u.GetWindowLongW(h, _GWL_EXSTYLE)
            u.SetWindowLongW(h, _GWL_EXSTYLE,
                             style | _WS_EX_TOPMOST | _WS_EX_TOOLWINDOW | _WS_EX_NOACTIVATE)
            state["hwnd"] = h
            return h

        def keep_on_top():
            if state["visible"]:
                try:
                    if os.name == "nt":
                        import ctypes
                        ctypes.windll.user32.SetWindowPos(
                            get_hwnd(), _HWND_TOPMOST, 0, 0, 0, 0, _SWP_FLAGS)
                    else:
                        win.lift()
                except Exception:
                    pass
            root.after(250, keep_on_top)

        def hide(_e=None):
            state["visible"] = False
            win.withdraw()

        def drag_start(e):
            state["drag"] = (e.x_root - win.winfo_x(), e.y_root - win.winfo_y())

        def drag_move(e):
            d = state["drag"]
            if d:
                win.geometry(f"+{e.x_root - d[0]}+{e.y_root - d[1]}")

        for w in (win, inner, label):
            w.bind("<ButtonPress-1>", drag_start)
            w.bind("<B1-Motion>", drag_move)
            w.bind("<Button-3>", hide)            # right-click closes

        def poll():
            try:
                while True:
                    text, secs = _q.get_nowait()
                    label.config(text=text)
                    win.update_idletasks()
                    if not state["visible"]:      # keep position if already shown/dragged
                        w, h = win.winfo_reqwidth(), win.winfo_reqheight()
                        x = (win.winfo_screenwidth() - w) // 2
                        win.geometry(f"{w}x{h}+{x}+60")
                    else:
                        win.geometry("")          # let it resize to the new text
                    state["visible"] = True
                    win.deiconify()
                    win.lift()
                    if state["after"] is not None:
                        root.after_cancel(state["after"])
                        state["after"] = None
                    if secs is not None:
                        state["after"] = root.after(int(secs * 1000), hide)
            except queue.Empty:
                pass
            root.after(50, poll)

        poll()
        keep_on_top()
        root.mainloop()
    except Exception as e:
        logger.error(f"Answer popup thread died: {e!r}", exc_info=True)


def show(text: str, seconds=None):
    global _started
    with _start_lock:
        if not _started:
            _started = True
            threading.Thread(target=_loop, daemon=True).start()
    _q.put((text, DISPLAY_SECONDS if DISPLAY_SECONDS is not None else seconds))
