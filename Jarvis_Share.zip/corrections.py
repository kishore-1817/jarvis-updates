﻿"""
Correction list for phrases that speech recognition keeps mishearing.
Add anything that keeps getting misheard to KNOWN_TERMS below, written exactly
the way it should come out, e.g. "smash karts".
"""

import difflib

KNOWN_TERMS = [
    # add your own frequently-misheard phrases here
]

MATCH_CUTOFF = 0.6  # 0-1, higher = stricter (fewer, more confident corrections)


def correct_text(text: str) -> str:
    """Returns the closest KNOWN_TERMS match if text is close-but-not-exact
    to one of them, otherwise returns text unchanged."""
    if text in KNOWN_TERMS:
        return text  # already exact, nothing to do

    matches = difflib.get_close_matches(text, KNOWN_TERMS, n=1, cutoff=MATCH_CUTOFF)
    return matches[0] if matches else text
