"""
form_filler.py -- lets Jarvis fill Google Forms (any form, any questions).

How it works
    1. You copy the form link, then say "Jarvis, fill this form".
    2. Jarvis opens the form in its own Chrome window (Playwright).
    3. For every question it reads the question text, asks Gemini for an
       answer using your facts (saved preferences + form_profile.txt),
       and types / clicks it in. Word limits like "50-75 Words" in the
       question are respected automatically.
    4. It does NOT submit. You review, then click Submit yourself.

Setup (once):
    pip install playwright
    playwright install chromium
    Edit form_profile.txt with your own facts.

First run: if the form needs a Google login, log in in the Jarvis window.
The login is saved in the "form_chrome_profile" folder, so it's one-time.
"""

import os
import re
import socket
import subprocess
import threading
import time
from pathlib import Path

HERE = Path(__file__).parent
PROFILE_FILE = HERE / "form_profile.txt"
BROWSER_DIR = HERE / "form_chrome_profile"

_busy = threading.Event()


# ---------------------------------------------------------------------
# Facts + Gemini
# ---------------------------------------------------------------------

def _facts() -> str:
    parts = []
    try:
        import memory
        prefs = memory.get_all_preferences()
        if prefs:
            parts.append("Saved details:\n" + "\n".join(f"- {k}: {v}" for k, v in prefs.items()))
    except Exception:
        pass
    if PROFILE_FILE.exists():
        parts.append(PROFILE_FILE.read_text(encoding="utf-8").strip())
    return "\n\n".join(parts)


def _gemini(prompt: str) -> str:
    """One-shot Gemini call using the client + model list from llm_brain."""
    import llm_brain
    client = llm_brain._get_client()
    if client is None:
        raise RuntimeError("No Gemini API key found")
    last = None
    for model in llm_brain.MODEL_CHAIN:
        try:
            if not llm_brain._is_available(model):
                continue
            resp = client.models.generate_content(model=model, contents=prompt)
            text = (resp.text or "").strip()
            if text:
                return text
        except Exception as e:  # try the next model
            last = e
    raise RuntimeError(f"Gemini failed: {last!r}")


def _word_limits(question: str):
    """'(50-75 Words)' -> (50, 75); 'max 100 words' -> (None, 100)."""
    m = re.search(r"(\d+)\s*(?:-|–|to)\s*(\d+)\s*words?", question, re.I)
    if m:
        return int(m.group(1)), int(m.group(2))
    m = re.search(r"(?:max(?:imum)?|up to|under|within)\s*(\d+)\s*words?", question, re.I)
    if m:
        return None, int(m.group(1))
    return None, None


def _trim_to(text: str, hi: int) -> str:
    words = text.split()
    if len(words) <= hi:
        return text
    cut = " ".join(words[:hi])
    end = max(cut.rfind(". "), cut.rfind("."))
    return cut[: end + 1] if end > len(cut) * 0.6 else cut


def answer_text(question: str, facts: str) -> str:
    """Returns the answer, or '' if Gemini doesn't have the info (SKIP)."""
    lo, hi = _word_limits(question)
    if lo or hi:
        length = (f"Write between {lo} and {hi} words." if lo and hi
                  else f"Write at most {hi} words.")
    else:
        length = ("If the question just asks for a value (name, email, phone, "
                  "roll number...), give only that value. Otherwise answer in 1-3 sentences.")
    prompt = (
        "You are filling out a form on behalf of the person described below. "
        "Answer in first person, plain text, no markdown, no quotes, no preamble.\n"
        f"{length}\n"
        "Use ONLY the facts given. If the facts don't contain what is needed "
        "(e.g. a phone number or ID you weren't given), reply exactly: SKIP\n\n"
        f"FACTS:\n{facts}\n\nQUESTION:\n{question}"
    )
    text = ""
    for _ in range(3):
        text = _gemini(prompt)
        if text.strip().upper() == "SKIP":
            return ""
        n = len(text.split())
        if lo and hi and not (lo <= n <= hi):
            prompt += f"\n\n(Your last answer was {n} words. It must be {lo}-{hi} words.)"
            continue
        break
    if hi:
        text = _trim_to(text, hi)
    return text.strip()


def answer_choice(question: str, options: list, facts: str, multi: bool = False) -> list:
    """Picks option text(s) from `options`. Returns [] if unsure."""
    prompt = (
        "You are filling out a form on behalf of the person described below.\n"
        f"Pick {'all that apply' if multi else 'exactly one'} of the options, "
        "copying the option text exactly, one per line, nothing else. "
        "If the facts don't tell you, reply exactly: SKIP\n\n"
        f"FACTS:\n{facts}\n\nQUESTION:\n{question}\n\nOPTIONS:\n" + "\n".join(options)
    )
    out = _gemini(prompt)
    if out.strip().upper() == "SKIP":
        return []
    chosen = [ln.strip(" -*") for ln in out.splitlines() if ln.strip()]
    lowered = {o.lower().strip(): o for o in options}
    return [lowered[c.lower()] for c in chosen if c.lower() in lowered][: (None if multi else 1)]


# ---------------------------------------------------------------------
# Google Forms page handling
# ---------------------------------------------------------------------

_TEXT_SEL = ('input[type="text"], input[type="email"], input[type="number"], '
             'input[type="tel"], input[type="url"], textarea')


def _fill_page(page, facts: str, report: dict):
    for block in page.locator('div[role="listitem"]').all():
        try:
            if not block.is_visible():
                continue              # question belongs to another page
            heading = block.locator('div[role="heading"]').first
            if heading.count() == 0:
                continue
            question = heading.inner_text().replace("*", "").strip()
            if not question:
                continue

            radios = block.locator('div[role="radio"]')
            checks = block.locator('div[role="checkbox"]')
            listbox = block.locator('div[role="listbox"]')

            if radios.count():
                opts = [radios.nth(i).get_attribute("data-value") or "" for i in range(radios.count())]
                pick = answer_choice(question, [o for o in opts if o], facts)
                if pick:
                    radios.nth(opts.index(pick[0])).click(timeout=5000)
                    report["filled"] += 1
                else:
                    report["skipped"].append(question)

            elif checks.count():
                opts = [checks.nth(i).get_attribute("data-answer-value") or "" for i in range(checks.count())]
                picks = answer_choice(question, [o for o in opts if o], facts, multi=True)
                for p in picks:
                    checks.nth(opts.index(p)).click(timeout=5000)
                if picks:
                    report["filled"] += 1
                else:
                    report["skipped"].append(question)

            elif listbox.count():
                listbox.first.click(timeout=5000)
                page.wait_for_timeout(300)
                opt_nodes = block.locator('div[role="option"]')
                opts = [(opt_nodes.nth(i).get_attribute("data-value") or "") for i in range(opt_nodes.count())]
                real = [o for o in opts if o]
                pick = answer_choice(question, real, facts)
                if pick:
                    opt_nodes.nth(opts.index(pick[0])).click(timeout=5000)
                    report["filled"] += 1
                else:
                    page.keyboard.press("Escape")
                    report["skipped"].append(question)

            else:
                field = block.locator(_TEXT_SEL)
                if field.count() == 0:
                    continue          # date pickers, file uploads, grids: left for you
                answer = answer_text(question, facts)
                if answer:
                    field.first.fill(answer, timeout=5000)
                    report["filled"] += 1
                else:
                    report["skipped"].append(question)
        except Exception as e:
            report["skipped"].append(f"(error on a question: {e!r})")


CDP_PORT = 9222


def _chrome_exe():
    cands = [os.environ.get("FORM_FILLER_CHROME", ""),
             r"C:\Program Files\Google\Chrome\Application\chrome.exe",
             r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
             os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
             r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"]
    return next((c for c in cands if c and os.path.exists(c)), None)


def _port_open() -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", CDP_PORT)) == 0


def _open_page(pw, url: str):
    """Starts a NORMAL Chrome (own profile, so your logins are saved) and
    attaches to it. A normal Chrome lets you sign in to Google; Google
    blocks sign-in inside Playwright-launched browsers."""
    exe = _chrome_exe()
    if exe:
        if not _port_open():
            BROWSER_DIR.mkdir(exist_ok=True)
            extra = os.environ.get("FORM_FILLER_EXTRA_ARGS", "").split()
            subprocess.Popen([exe, f"--remote-debugging-port={CDP_PORT}",
                              f"--user-data-dir={BROWSER_DIR}", "--no-first-run",
                              "--no-default-browser-check", *extra, "about:blank"])
            for _ in range(40):
                if _port_open():
                    break
                time.sleep(0.5)
        browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{CDP_PORT}")
        ctx = browser.contexts[0]
        page = ctx.new_page()
        page.goto(url)
        return page
    # no Chrome/Edge found: fall back to Playwright's own browser
    BROWSER_DIR.mkdir(exist_ok=True)
    ctx = pw.chromium.launch_persistent_context(str(BROWSER_DIR), headless=False)
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    page.goto(url)
    return page


def _run(url: str, say):
    from playwright.sync_api import sync_playwright
    report = {"filled": 0, "skipped": []}
    pw = sync_playwright().start()
    try:
        page = _open_page(pw, url)

        if "accounts.google.com" in page.url:
            say("This form needs a Google login. Please sign in in the window I opened.")
        page.wait_for_selector('div[role="listitem"]', timeout=180000)

        facts = _facts()
        for _ in range(10):                       # up to 10 pages
            _fill_page(page, facts, report)
            nxt = page.get_by_role("button", name="Next")
            if nxt.count():
                nxt.first.click(timeout=5000)
                page.wait_for_timeout(1200)
            else:
                break

        msg = f"I filled {report['filled']} answers."
        if report["skipped"]:
            msg += f" I left {len(report['skipped'])} for you. Please review and submit."
        else:
            msg += " Please review and submit."
        say(msg)
        print("[form_filler] skipped:", report["skipped"])
        page.wait_for_event("close", timeout=0)   # keep the window open until you close it
    except Exception as e:
        import logging, traceback
        logging.getLogger("jarvis").error("form_filler failed: %r\n%s", e, traceback.format_exc())
        print("[form_filler] error:", repr(e))
        if "Executable doesn't exist" in str(e) or "playwright install" in str(e):
            say("I need a browser installed first. Run python, dash m, playwright install chromium.")
        else:
            say(f"Sorry, I couldn't fill the form. {type(e).__name__}. Check the log.")
    finally:
        try:
            pw.stop()
        except Exception:
            pass
        _busy.clear()


# ---------------------------------------------------------------------
# Entry point used by Jarvis
# ---------------------------------------------------------------------

def _clipboard() -> str:
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
                             capture_output=True, text=True, timeout=5)
        return (out.stdout or "").strip()
    except Exception:
        return ""


def start_from_clipboard(say) -> str:
    """Reads the form link from the clipboard and starts filling in the
    background. Returns the sentence for Jarvis to speak right now."""
    if _busy.is_set():
        return "I'm already filling a form."
    url = _clipboard()
    if not re.match(r"https?://(docs\.google\.com/forms|forms\.gle)/", url):
        return "Copy the Google Form link first, then ask me again."
    _busy.set()
    threading.Thread(target=_run, args=(url, say), daemon=True).start()
    return "Opening the form and filling it in."
