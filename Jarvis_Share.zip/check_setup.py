"""check_setup.py -- run by setup.bat. Prints PASS / FAIL for the things that
differ between PCs, with the fix for each one."""
import os
import platform
import sys
from pathlib import Path

HERE = Path(__file__).parent
results = []


def report(name, ok, fix=""):
    results.append(ok)
    print(("  PASS  " if ok else "  FAIL  ") + name)
    if not ok and fix:
        print("        -> " + fix)


print("Jarvis setup check")
print("-" * 40)

report("Python 3.11", sys.version_info[:2] == (3, 11),
       "Install Python 3.11.9 and run setup.bat again.")
report("Windows 10 or 11", platform.system() == "Windows" and int(platform.release() or 0) >= 10,
       "Jarvis only runs on Windows 10/11.")

try:
    from dotenv import load_dotenv
    load_dotenv(HERE / ".env")
except Exception:
    pass
key = os.environ.get("GEMINI_API_KEY", "").strip()
report("Gemini API key in .env", bool(key) and not key.lower().startswith("paste"),
       "Open .env in Notepad and paste your key after GEMINI_API_KEY=  (free: https://aistudio.google.com/apikey)")

# Live Gemini call (this is also what "look at my screen" uses)
if key and not key.lower().startswith("paste"):
    try:
        from google import genai
        _c = genai.Client(api_key=key)
        _r = _c.models.generate_content(model="gemini-3.1-flash-lite", contents="Reply with the word OK")
        report("Gemini answers (screen questions + chat)", bool(getattr(_r, "text", "")),
               "The key was rejected or has no access. Create a new key at https://aistudio.google.com/apikey")
    except Exception as e:
        report("Gemini answers (screen questions + chat)", False,
               f"{str(e)[:120]}  -> check the key and your internet connection.")

for mod, label in (("faster_whisper", "Speech recognition (faster-whisper)"),
                   ("speech_recognition", "Microphone library"),
                   ("pyaudio", "PyAudio"),
                   ("edge_tts", "Voice (edge-tts)"),
                   ("pygame", "Audio playback (pygame)"),
                   ("win32com.client", "pywin32"),
                   ("winocr", "Screen OCR (winocr)"),
                   ("google.genai", "Gemini library")):
    try:
        __import__(mod)
        report(label, True)
    except Exception as e:
        report(label, False, f"Import failed: {e!r}. Run setup.bat again.")

try:
    import speech_recognition as sr
    mics = sr.Microphone.list_microphone_names()
    report("Microphone found", len(mics) > 0,
           "Plug in / enable a microphone: Settings > System > Sound > Input.")
except Exception as e:
    report("Microphone found", False, f"{e!r}")

# OCR: actually read a picture of text
try:
    import winocr
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (700, 160), "white")
    font = None
    for name in ("arial.ttf", "segoeui.ttf", "calibri.ttf"):
        try:
            font = ImageFont.truetype(name, 64)
            break
        except Exception:
            pass
    ImageDraw.Draw(img).text((20, 40), "Hello Jarvis", fill="black", font=font)
    ok = False
    for lang in ("en-US", "en"):
        try:
            res = winocr.recognize_pil_sync(img, lang=lang)
            text = (getattr(res, "text", None) or (res.get("text") if isinstance(res, dict) else "") or "")
            if "hello" in text.lower():
                ok = True
                break
        except Exception:
            continue
    report("Screen OCR reads text", ok,
           "Windows needs the English OCR pack. Open PowerShell as Administrator and run:\n"
           "           Add-WindowsCapability -Online -Name \"Language.OCR~~~en-US~0.0.1.0\"\n"
           "        Then run setup.bat again.")
except Exception as e:
    report("Screen OCR reads text", False, f"{e!r}")

# Optional: WhatsApp (calls / messages)
try:
    import subprocess
    out = subprocess.run(["powershell", "-NoProfile", "-Command",
                          "Get-AppxPackage -Name 5319275A.WhatsAppDesktop | Select -ExpandProperty Name"],
                         capture_output=True, text=True, timeout=30).stdout.strip()
    print("  INFO  WhatsApp (Microsoft Store) installed: " + ("yes" if out else
          "NO - calls/messages won't work until you install it from the Microsoft Store and log in"))
except Exception:
    print("  INFO  Could not check for WhatsApp (optional).")

print("-" * 40)
if all(results):
    print("Everything looks good.")
else:
    print(f"{results.count(False)} problem(s) above. Fix them, then run setup.bat again.")
