"""
fuzzy_match.py -- one shared, reusable way to match a spoken phrase
against a list of "real" names that almost never match it
character-for-character: filenames, folder names, app names, Wi-Fi
networks, contacts, to-do items, and so on.

WHY THIS EXISTS AS ITS OWN MODULE:
Every part of Jarvis that takes a spoken name and has to find the
"real" thing it refers to runs into the same handful of problems:

  - Real names are noisy. Downloaded files in particular look like
    "@Benzmovies - Jana Nayagan (2026) 1080p.WEB-DL.x264.RARBG" when
    you just said "Jana Nayagan" -- underscores, dots, brackets, tags.
  - A short spoken name is often only PART of a longer real one.
  - Speech-to-text mishears things ("draught" heard for "draft").

This started as file-search-only logic inside file_manager.py. Rather
than copy-pasting that logic into every other module that needs the
same forgiveness (app names, Wi-Fi networks, contacts, to-do items,
...), it now lives here once, and anything can import it.

STRATEGY -- three tiers, most confident first, stops at the first tier
that finds anything at all:
    1. EXACT     -- normalized target == normalized candidate
    2. SUBSTRING -- normalized target appears INSIDE a normalized
                    candidate (handles the "short name, noisy real
                    filename" case above)
    3. FUZZY     -- difflib similarity above a cutoff, for mishearings
                    with no substring relationship at all
"""

import re
import difflib


def normalize(s: str) -> str:
    """Reduces text to a comparable form: every run of punctuation
    (underscores, hyphens, dots, @, parens, brackets, etc.) becomes a
    single space, case-folded, extra whitespace collapsed. This one
    function is what lets "AES_Project_Guide" match "aes project
    guide" and "@Benzmovies - Jana Nayagan (2026)..." contain "jana
    nayagan" as a substring."""
    s = s.lower()
    s = re.sub(r'[^a-z0-9]+', ' ', s)
    return s.strip()


def _windowed_fuzzy_score(target: str, candidate: str) -> float:
    """Returns the best fuzzy similarity between `target` and any
    reasonably-sized contiguous word-window of `candidate` -- tried
    both space-joined and run-together (words concatenated with no
    spaces). Comparing a short spoken phrase against an ENTIRE long,
    noisy filename gives a misleadingly low score just from the length
    difference; this instead finds the part of the candidate that's
    actually relevant and scores against that. The run-together form
    also catches speech-to-text mashing multiple words into one with
    no space (e.g. "Jana Nayagan" heard as "jananayakan")."""
    target_words = target.split()
    cand_words = candidate.split()
    if not target_words or not cand_words:
        return 0.0

    n = len(target_words)
    best = difflib.SequenceMatcher(None, target, candidate).ratio()  # floor: whole-string
    target_joined = target.replace(" ", "")

    # Window sizes: for a single-word target (n==1, e.g. STT ran two
    # words together into one -- "jananayakan"), try sizes 1 and 2, so
    # a 2-word run-together candidate window can still match. For a
    # multi-word target (n>=2), NEVER shrink below n-1 words at once
    # such that only a fraction of the target's words fit the window
    # is fine, but never shrink all the way to 1 word -- a single
    # shared word (e.g. "certificate") can otherwise dominate the
    # score and falsely match any candidate containing just that one
    # word, even when the rest of the target ("rizwana") matches
    # nothing at all.
    window_min = n if n <= 2 else n - 1
    window_max = n + 1

    for window_size in range(window_min, window_max + 1):
        for i in range(0, max(1, len(cand_words) - window_size + 1)):
            window_words = cand_words[i:i + window_size]
            if not window_words:
                continue
            spaced = " ".join(window_words)
            joined = "".join(window_words)
            for a, b in ((target, spaced), (target, joined), (target_joined, joined)):
                ratio = difflib.SequenceMatcher(None, a, b).ratio()
                if ratio > best:
                    best = ratio
    return best


def find_best_matches(target: str, candidates, key=None, cutoff: float = 0.80, limit: int = 5):
    """Matches `target` (a spoken phrase) against `candidates` (a list
    of items -- plain strings, or anything `key` can pull a comparable
    name out of, e.g. Path objects or dicts).

    Returns a list of the ORIGINAL candidate items (not normalized
    strings) that matched, from whichever tier found something first
    -- exact, then substring, then windowed fuzzy. Returns [] if
    nothing at any tier matched.

    Args:
        target: the spoken/typed phrase to match.
        candidates: iterable of items to search.
        key: optional function extracting the comparable name from
            each candidate. Defaults to using the candidate itself
            (i.e. for a plain list of name strings).
        cutoff: fuzzy similarity threshold (0-1) for the fuzzy tier.
        limit: max number of fuzzy matches to return.
    """
    key = key or (lambda x: x)
    norm_target = normalize(target)
    if not norm_target:
        return []

    exact, substring, rest = [], [], []
    for item in candidates:
        norm_item = normalize(str(key(item)))
        if not norm_item:
            continue
        if norm_item == norm_target:
            exact.append(item)
        elif norm_target in norm_item:
            substring.append(item)
        else:
            rest.append((norm_item, item))

    if exact:
        return exact
    if substring:
        return substring

    scored = []
    for norm_item, item in rest:
        score = _windowed_fuzzy_score(norm_target, norm_item)
        if score >= cutoff:
            scored.append((score, item))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [item for _, item in scored[:limit]]


def find_best_match(target: str, candidates, key=None, cutoff: float = 0.80):
    """Convenience wrapper around find_best_matches() for callers that
    only want a single best guess (e.g. resolving a folder alias)
    rather than a disambiguation list. Returns the first match, or
    None if nothing matched at any tier."""
    matches = find_best_matches(target, candidates, key=key, cutoff=cutoff, limit=1)
    return matches[0] if matches else None
