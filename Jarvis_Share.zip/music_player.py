"""
Plays a song by name on YouTube.

Searches YouTube's own search results page and scrapes the first video
ID directly out of the raw HTML -- no YouTube Data API key, no billing,
no extra heavy dependency (just `requests`, which is already installed
for temperature.py's LibreHardwareMonitor calls). Then opens that
video's direct watch URL, which starts playing immediately in the
browser.

This is the same trick the popular `pywhatkit.playonyt()` uses under
the hood -- implemented directly here to avoid pulling in that whole
package (which also drags in pyautogui, wikipedia, etc.) for one
feature.
"""

import re
import webbrowser

import requests

SEARCH_URL = "https://www.youtube.com/results?search_query={}"


def play_song(song_name: str) -> str:
    """Searches YouTube for song_name and opens the first result so it
    starts playing immediately. Returns a spoken-friendly result
    message either way -- never raises."""
    query = requests.utils.quote(song_name)
    try:
        resp = requests.get(SEARCH_URL.format(query), timeout=5)
        resp.raise_for_status()
    except Exception as e:
        return f"I couldn't reach YouTube right now: {e}"

    match = re.search(r'"videoId":"([\w-]{11})"', resp.text)
    if not match:
        return f"I couldn't find anything for {song_name} on YouTube."

    video_id = match.group(1)
    webbrowser.open(f"https://www.youtube.com/watch?v={video_id}")
    return f"Playing {song_name}."
