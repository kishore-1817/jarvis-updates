"""
screen_commands.py -- screen-vision voice command matching.

Part of the Command Router (see command_router.py). Unlike the domains
migrated FROM the old dispatcher (clipboard, files, weather), this one
was built directly here from the start -- new features go straight
into the router pattern now rather than adding more to the old
dispatcher chain.

A handful of common exact phrasings get a direct fast-path match
below. Anything else screen-related ("why is this code showing an
error", "what does this button do") is meant to reach Gemini's
ask_about_screen_tool via normal function calling instead -- this
domain deliberately does NOT try to regex-match every possible
phrasing, since screen questions are inherently open-ended.
"""

from screen_vision import handle_screen_request, copy_screen_text

_EXACT_PHRASES = (
    "what's on my screen", "what is on my screen",
    "describe my screen", "look at my screen",
    "read my screen", "what am i looking at",
)

_COPY_TEXT_PHRASES = (
    "copy the text from my screen", "copy text from my screen",
    "copy the text on my screen", "copy screen text",
    "copy the screen text",
)


def try_handle(t: str, speak) -> bool:
    """Checks `t` (the lowercased, stripped transcript) against the
    common exact screen-vision phrasings.

    Returns True and calls speak(...) if handled. Returns False
    (without calling speak at all) if this domain doesn't recognize
    the phrase -- most screen-related questions are open-ended enough
    that they're expected to reach Gemini's tool instead, not this
    fast path.
    """
    # Checked first: the action tier (no Gemini at all) is the fastest
    # possible path, so it shouldn't have to wait behind the general
    # Q&A check below.
    if t in _COPY_TEXT_PHRASES:
        speak(copy_screen_text())
        return True

    if t in _EXACT_PHRASES:
        speak(handle_screen_request())
        return True

    return False

