"""
whatsapp_commands.py -- WhatsApp voice commands (Command Router domain).

Handles, BEFORE the old regex in jarvis_up.py's _dispatch_command():
    "message Arun saying I'll reach in 10 minutes"
    "send a message to Arun saying ..."   / "text Arun: ..." / "message Arun, ..."
    "open Arun's chat" / "open chat with Arun" / "open WhatsApp chat with Arun"

Sending is never done here: whatsapp_actions.stage_message() types the
message, then asks "Send it?" (see whatsapp_actions.py). "open WhatsApp"
and "call X" are left to the existing handlers.

Note: the router only receives the LOWERCASED transcript, so the message text
is lightly tidied (first letter + standalone 'i' capitalised) -- the old path
sent it fully lowercase.
"""

import re

import whatsapp_actions
import send_message as _sm
from send_message import resolve_contact

# Blind flow (default): search the spoken name, open whatever result is on
# top (WhatsApp's own search forgives misspellings), type the message, press
# Enter. No header/name comparison, no "Send it?" question.
# Set CONFIRM_BEFORE_SEND = True to go back to the careful flow in
# whatsapp_actions.py (verifies the chat, types, asks "Send it?", then sends).
CONFIRM_BEFORE_SEND = False

_SEP = r"(?:\s*[:,]\s*|\s+saying that\s+|\s+saying\s+|\s+and say\s+|\s+that says\s+|\s+say\s+)"
_MSG_RE = re.compile(
    r"^(?:send (?:a )?(?:whatsapp )?message to|whatsapp message to|whatsapp|message(?: to)?|text)\s+"
    r"(.+?)" + _SEP + r"(.+)$"
)
_CALL_RE = re.compile(
    r"^(?:(?:voice |whatsapp )?call|ring)\s+(.+?)(?:\s+(?:on|in|using|through)\s+whatsapp)?$"
)
_OPEN_CHAT_RES = (
    re.compile(r"^open (?:whatsapp )?chat (?:with|of|for) (.+)$"),
    re.compile(r"^open (?:whatsapp )?(.+?)(?:'s|s)? (?:whatsapp )?chat$"),
)


def _tidy(msg: str) -> str:
    msg = msg.strip()
    msg = re.sub(r"\bi\b", "I", msg)
    return msg[:1].upper() + msg[1:]


def try_handle(t: str, speak) -> bool:
    t = t.strip().rstrip(".,!?").strip()

    m = _MSG_RE.match(t)
    if m:
        contact, message = m.group(1).strip(), m.group(2).strip()
        if contact and message:
            contact = resolve_contact(contact)     # nicknames / misheard names
            if CONFIRM_BEFORE_SEND:
                speak(whatsapp_actions.stage_message(contact, _tidy(message)))
            else:
                ok = _sm.send_message(contact, _tidy(message))
                speak("Sent." if ok else
                      "I couldn't send that. Check send_message.log for what went wrong.")
            return True

    m = _CALL_RE.match(t)
    if m and m.group(1).strip():
        spoken = m.group(1).strip()
        speak(f"Calling {spoken}.")
        if not _sm.call_whatsapp_contact(resolve_contact(spoken)):
            speak("I couldn't start that call. Check send_message.log for what went wrong.")
        return True

    for rx in _OPEN_CHAT_RES:
        m = rx.match(t)
        if m and m.group(1).strip():
            who = resolve_contact(m.group(1).strip())
            if CONFIRM_BEFORE_SEND:
                speak(whatsapp_actions.open_chat(who))
            else:
                speak("Opened." if _sm.send_message(who) else
                      "I couldn't open that chat. Check send_message.log.")
            return True

    return False
