"""
brain_switch.py -- which LLM Jarvis is using, plus the voice command to change it.

Say:  "change brain"            -> cycles to the next brain that is set up
      "switch brain to groq"    -> Gemini / Groq / OpenRouter / Ollama (local)
      "use local brain"         -> Ollama
      "which brain"             -> tells you the current one

The choice is saved in brain_state.json, so it survives a restart.
Keys go in .env:  GROQ_API_KEY=...   OPENROUTER_API_KEY=...
(Gemini keeps using GEMINI_API_KEY. Ollama needs no key, just `ollama serve` running.)
"""
import json
import os
import re
import urllib.request
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

PROVIDERS = ["gemini", "groq", "openrouter", "ollama"]
STATE_FILE = Path(__file__).parent / "brain_state.json"

# What Whisper tends to hear -> provider. Only matched inside a brain command.
ALIASES = {
    "gemini": "gemini", "google": "gemini", "gemma": "gemini", "jemini": "gemini",
    "groq": "groq", "grok": "groq", "grock": "groq", "rock": "groq", "croc": "groq",
    "open router": "openrouter", "openrouter": "openrouter",
    "ollama": "ollama", "olama": "ollama", "local": "ollama", "offline": "ollama",
}
SPOKEN = {"gemini": "Gemini", "groq": "Groq", "openrouter": "Open Router", "ollama": "local Ollama"}

_BRAIN_CMD = re.compile(
    r"\b(change|switch|swap|set|use|select|toggle|which|what)\b.*\b(brain|llm)\b"
    r"|\b(brain|llm)\b.*\b(change|switch|swap)\b"
    r"|\buse\s+(?:the\s+)?(?:local|offline)\s+(?:brain|model)\b")


def _load() -> str:
    try:
        name = json.loads(STATE_FILE.read_text())["active"]
        return name if name in PROVIDERS else "gemini"
    except Exception:
        return "gemini"


_active = _load()


def get_brain() -> str:
    return _active


def set_brain(name: str) -> str:
    global _active
    _active = name
    try:
        STATE_FILE.write_text(json.dumps({"active": name}))
    except Exception:
        pass
    return name


def _ollama_up() -> bool:
    try:
        host = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
        if not host.startswith("http"):
            host = "http://" + host
        urllib.request.urlopen(host + "/api/tags", timeout=0.6)
        return True
    except Exception:
        return False


def not_ready_reason(name: str):
    """None if the provider can be used right now, else a short spoken reason."""
    if name == "gemini":
        ok = os.environ.get("GEMINI_API_KEY") or (Path(__file__).parent / "gemini_api_key.txt").exists()
        return None if ok else "There is no Gemini key set."
    if name == "groq":
        return None if os.environ.get("GROQ_API_KEY") else "There is no Groq key in the env file."
    if name == "openrouter":
        return None if os.environ.get("OPENROUTER_API_KEY") else "There is no Open Router key in the env file."
    if name == "ollama":
        return None if _ollama_up() else "Ollama isn't running on this PC."
    return "Unknown brain."


def handle_brain_command(text: str):
    """Returns the spoken reply if `text` was a brain command, else None."""
    t = text.lower().strip(" .?!")
    if not _BRAIN_CMD.search(t):
        return None

    if re.search(r"\b(which|what)\b", t) and not re.search(r"\b(change|switch|swap)\b", t):
        return f"I'm using {SPOKEN[_active]}."

    wanted = None
    for alias, name in ALIASES.items():
        if re.search(r"\b" + re.escape(alias) + r"\b", t):
            wanted = name
            break

    if wanted:
        if wanted == _active:
            return f"Already on {SPOKEN[wanted]}."
        why = not_ready_reason(wanted)
        if why:
            return f"Can't switch to {SPOKEN[wanted]}. {why}"
        set_brain(wanted)
        return f"Brain switched to {SPOKEN[wanted]}."

    # No name given: cycle to the next brain that is actually usable.
    i = PROVIDERS.index(_active)
    for step in range(1, len(PROVIDERS)):
        cand = PROVIDERS[(i + step) % len(PROVIDERS)]
        if not_ready_reason(cand) is None:
            set_brain(cand)
            return f"Brain switched to {SPOKEN[cand]}."
    return "No other brain is set up yet."
