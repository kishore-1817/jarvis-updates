"""Type-to-Jarvis box. Hotkey opens a small chat box; text goes through the
same handle_command() as voice. Runs its own Tk window in its own thread, so
it never touches the HUD's thread.

Public API:
    start(on_submit, get_reply, hotkey_vks=(0x11, 0x12, 0x4A))   # Ctrl+Alt+J
        on_submit(text)  -> runs the command (called in a worker thread)
        get_reply()      -> returns the last reply text to show in the box
"""
import threading
import time
import ctypes
import tkinter as tk

# --- look & position (edit these) ---
BOX_W = 220            # width in px
MARGIN_RIGHT = 16      # gap from the right edge
MARGIN_BOTTOM = 64     # gap from the bottom (clears the taskbar)
KEY = "#010101"        # this colour is made fully see-through (don't use it for text)
SHOW_DOTS = False      # True = show the 4 corner focus dots, False = fully invisible box
DOT = 4                # corner dot size in px
DOT_ON = "#00e5ff"     # dots when the box has keyboard focus
DOT_OFF = "#4b5563"    # dots when it doesn't
FG_INPUT = "#ffffff"   # what you type
FG_REPLY = "#c9d1d9"   # Jarvis's reply
FG_BUSY = "#58a6ff"    # "thinking..." line
REPLY_SECONDS = 3       # reply fades away after this many seconds
FONT_ENTRY = ("Consolas", 10)
FONT_REPLY = ("Consolas", 9)

_open_evt = threading.Event()
_close_evt = threading.Event()
_focus_evt = threading.Event()
_box_lock = threading.Lock()
_is_open = False


def _hotkey_watcher(vks):
    if not hasattr(ctypes, "windll"):
        return
    user32 = ctypes.windll.user32

    def down():
        return all(user32.GetAsyncKeyState(vk) & 0x8000 for vk in vks)

    was = down()
    while True:
        try:
            now = down()
            if now and not was:
                if _is_open:
                    _focus_evt.set()     # pressed again while open: grab focus
                else:
                    _open_evt.set()
            was = now
        except Exception:
            pass
        time.sleep(0.05)


def _run_box(on_submit, get_reply):
    global _is_open
    _close_evt.clear()
    _focus_evt.clear()
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg=KEY)
    try:
        root.attributes("-transparentcolor", KEY)   # no box: only text + 4 dots show
    except Exception:
        pass

    reply = tk.Label(root, text="", font=FONT_REPLY, fg=FG_REPLY, bg=KEY,
                     anchor="w", justify="left", wraplength=BOX_W - 20)
    reply.pack(fill="x", padx=10, pady=(6, 0))
    entry = tk.Entry(root, font=FONT_ENTRY, bg=KEY, fg=FG_INPUT,
                     disabledbackground=KEY, disabledforeground=FG_BUSY,
                     insertbackground=FG_INPUT, insertwidth=2,
                     relief="flat", bd=0, highlightthickness=0)
    entry.pack(fill="x", padx=10, pady=(2, 6), ipady=1)

    # 4 corner dots: bright cyan = typing goes here, grey = no focus
    dots = []
    for rx, ry, anchor in (((0, 0, "nw"), (1, 0, "ne"), (0, 1, "sw"), (1, 1, "se")) if SHOW_DOTS else ()):
        d = tk.Frame(root, width=DOT, height=DOT, bg=DOT_OFF)
        d.place(relx=rx, rely=ry, anchor=anchor)
        dots.append(d)

    def set_dots(color):
        for d in dots:
            d.config(bg=color)

    entry.bind("<FocusIn>", lambda _: set_dots(DOT_ON))
    entry.bind("<FocusOut>", lambda _: set_dots(DOT_OFF))

    def grab_focus(_=None):
        # Windows blocks background apps from stealing focus. A quick Alt tap
        # lets SetForegroundWindow through (known workaround).
        try:
            u = ctypes.windll.user32
            hwnd = u.GetParent(root.winfo_id()) or root.winfo_id()
            u.keybd_event(0x12, 0, 0, 0)          # Alt down
            u.keybd_event(0x12, 0, 0x0002, 0)     # Alt up
            fg = u.GetForegroundWindow()
            me = ctypes.windll.kernel32.GetCurrentThreadId()
            fg_tid = u.GetWindowThreadProcessId(fg, None)
            u.AttachThreadInput(me, fg_tid, True)
            u.ShowWindow(hwnd, 5)
            u.BringWindowToTop(hwnd)
            u.SetForegroundWindow(hwnd)
            u.SetFocus(hwnd)
            u.AttachThreadInput(me, fg_tid, False)
        except Exception:
            pass
        root.focus_force()
        entry.focus_force()

    def place():
        # grows upward from the bottom-right corner as the reply gets longer
        root.update_idletasks()
        h = root.winfo_reqheight()
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        root.geometry(f"{BOX_W}x{h}+{sw - BOX_W - MARGIN_RIGHT}+{sh - h - MARGIN_BOTTOM}")

    place()

    busy = {"v": False}
    clear_job = {"id": None}

    def clear_reply():
        clear_job["id"] = None
        reply.config(text="")
        place()

    def cancel_clear():
        if clear_job["id"] is not None:
            root.after_cancel(clear_job["id"])
            clear_job["id"] = None

    def close(_=None):
        root.destroy()

    def poll_reply(before):
        # wait (without blocking Tk) until the command thread finishes
        if worker.is_alive():
            root.after(100, poll_reply, before)
            return
        busy["v"] = False
        text = get_reply() or "Done."
        reply.config(text=text, fg=FG_REPLY)
        place()
        cancel_clear()
        clear_job["id"] = root.after(int(REPLY_SECONDS * 1000), clear_reply)
        entry.config(state="normal")
        grab_focus()

    def submit(_=None):
        text = entry.get().strip()
        if not text or busy["v"]:
            return
        nonlocal worker
        busy["v"] = True
        cancel_clear()
        entry.delete(0, "end")
        entry.config(state="disabled")
        reply.config(text=f"> {text}\nthinking...", fg=FG_BUSY)
        place()
        worker = threading.Thread(target=on_submit, args=(text,), daemon=True)
        worker.start()
        root.after(100, poll_reply, None)

    worker = threading.Thread()

    def watch_close():
        if _close_evt.is_set():
            root.destroy()
            return
        if _focus_evt.is_set():
            _focus_evt.clear()
            grab_focus()
        root.after(100, watch_close)

    root.after(150, watch_close)
    entry.bind("<Return>", submit)
    root.bind("<Escape>", close)
    root.bind("<Button-1>", grab_focus)
    entry.bind("<Button-1>", grab_focus)
    root.after(50, grab_focus)
    root.after(250, grab_focus)
    try:
        root.mainloop()
    finally:
        with _box_lock:
            _is_open = False


def _opener(on_submit, get_reply):
    global _is_open
    while True:
        _open_evt.wait()
        _open_evt.clear()
        with _box_lock:
            if _is_open:
                continue
            _is_open = True
        try:
            _run_box(on_submit, get_reply)
        except Exception:
            with _box_lock:
                _is_open = False


def start(on_submit, get_reply, hotkey_vks=(0x11, 0x12, 0x4A)):
    """Ctrl+Alt+J by default (VK_CONTROL, VK_MENU, 'J')."""
    threading.Thread(target=_hotkey_watcher, args=(hotkey_vks,), daemon=True).start()
    threading.Thread(target=_opener, args=(on_submit, get_reply), daemon=True).start()


def stop():
    """Close an open box (if any); the hotkey/opener threads are daemons."""
    _close_evt.set()
