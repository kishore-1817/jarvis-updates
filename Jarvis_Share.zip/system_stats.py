"""System performance reporting -- CPU and RAM usage via psutil."""

import psutil


def get_performance_summary() -> str:
    """Returns a spoken-friendly summary of current CPU and RAM usage."""
    cpu_percent = psutil.cpu_percent(interval=1)  # 1s sample for an accurate reading
    ram = psutil.virtual_memory()
    ram_percent = ram.percent
    ram_used_gb = ram.used / (1024 ** 3)
    ram_total_gb = ram.total / (1024 ** 3)

    summary = (
        f"CPU usage is at {cpu_percent:.0f} percent. "
        f"Memory usage is at {ram_percent:.0f} percent, "
        f"using {ram_used_gb:.1f} of {ram_total_gb:.1f} gigabytes."
    )

    if cpu_percent > 85:
        summary += " CPU load is quite high right now -- you might want to check what's running."
    if ram_percent > 85:
        summary += " Memory is nearly full -- closing a few apps could help."

    return summary
