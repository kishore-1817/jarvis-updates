"""
Clipboard control -- read, save, and set clipboard text.

Uses win32clipboard (part of pywin32, already installed for
app_finder.py's Start Menu scanning) instead of adding a new
dependency like pyperclip.
"""

from datetime import datetime
from pathlib import Path
import ctypes
from ctypes import wintypes
import io

import win32clipboard
import win32con

SAVE_DIR = Path.home() / "Documents"


class _DROPFILES(ctypes.Structure):
    """The header Windows expects before a list of file paths for the
    CF_HDROP clipboard format -- this is what File Explorer itself
    writes when you press Ctrl+C on a file, which is why pasting a
    file copied this way works anywhere a normal file-copy would."""
    _fields_ = [
        ("pFiles", wintypes.DWORD),  # byte offset from the start of this
                                      # struct to where the file path list begins
        ("pt", wintypes.POINT),
        ("fNC", wintypes.BOOL),
        ("fWide", wintypes.BOOL),    # True = the path list is UTF-16, not ANSI
    ]


def get_clipboard_text() -> str:
    """Returns the current clipboard text, or an empty string if the
    clipboard is empty or doesn't contain text (e.g. it holds an image
    instead)."""
    try:
        win32clipboard.OpenClipboard()
        try:
            data = win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
        except TypeError:
            data = ""
        finally:
            win32clipboard.CloseClipboard()
        return data or ""
    except Exception:
        return ""


def set_clipboard_text(text: str) -> bool:
    """Sets the clipboard to the given text. Returns True on success."""
    try:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_UNICODETEXT, text)
        win32clipboard.CloseClipboard()
        return True
    except Exception:
        return False


def read_clipboard_summary(max_words: int = 60) -> str:
    """Spoken-friendly clipboard content -- truncates long content since
    reading a huge block of text aloud isn't useful."""
    text = get_clipboard_text()
    if not text.strip():
        return "Your clipboard is empty, or doesn't contain text."

    words = text.split()
    if len(words) > max_words:
        preview = " ".join(words[:max_words])
        return f"Your clipboard has {len(words)} words. It starts with: {preview}..."
    return f"Your clipboard contains: {text}"


def save_clipboard_to_file() -> str:
    """Saves the current clipboard text to a timestamped .txt file in
    Documents. Returns a spoken-friendly result message."""
    text = get_clipboard_text()
    if not text.strip():
        return "Your clipboard is empty, nothing to save."

    filename = f"clipboard_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    filepath = SAVE_DIR / filename
    try:
        filepath.write_text(text, encoding="utf-8")
        return f"Saved clipboard content to {filename} in Documents."
    except Exception as e:
        return f"I couldn't save the clipboard: {e}"


def copy_file_to_clipboard(filepath) -> bool:
    """Copies a FILE to the clipboard (CF_HDROP format) -- the same as
    pressing Ctrl+C on a file in File Explorer, so it can be pasted
    into another folder, an email attachment field, chat apps, etc.
    This is a different clipboard format than set_clipboard_text()
    (which only handles plain text), so it needs its own function
    rather than just stringifying the path."""
    try:
        path_str = str(Path(filepath).resolve())
        file_list = path_str + "\0\0"  # double-null-terminated, as CF_HDROP requires

        header_size = ctypes.sizeof(_DROPFILES)
        list_bytes = len(file_list) * ctypes.sizeof(ctypes.c_wchar)
        buf = ctypes.create_string_buffer(header_size + list_bytes)

        dropfiles = _DROPFILES.from_buffer(buf)
        dropfiles.pFiles = header_size
        dropfiles.fWide = True

        wide_list = ctypes.create_unicode_buffer(file_list)
        ctypes.memmove(ctypes.addressof(buf) + header_size, wide_list, list_bytes)

        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_HDROP, buf.raw)
        win32clipboard.CloseClipboard()
        return True
    except Exception as e:
        print(f"[clipboard_control] copy_file_to_clipboard failed: {e}")
        return False


def copy_image_to_clipboard(image) -> bool:
    """Copies a PIL Image to the clipboard as CF_DIB, so it can be
    pasted directly into any app that accepts a pasted image (Word,
    Paint, chat apps, etc.) -- not just saved to a file."""
    try:
        output = io.BytesIO()
        image.convert("RGB").save(output, "BMP")
        # CF_DIB wants just the BITMAPINFOHEADER + pixel data, not the
        # 14-byte BITMAPFILEHEADER a .bmp FILE has -- strip it.
        dib_data = output.getvalue()[14:]
        output.close()

        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_DIB, dib_data)
        win32clipboard.CloseClipboard()
        return True
    except Exception as e:
        print(f"[clipboard_control] copy_image_to_clipboard failed: {e}")
        return False
