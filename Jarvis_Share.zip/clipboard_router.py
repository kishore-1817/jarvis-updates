"""
Clipboard domain router -- owns every voice command related to the
clipboard (read, save-to-file, copy text/file in) and decides on its
own whether a given command belongs to it.

This is the first domain pulled out of jarvis_up.py's single
_dispatch_command() function as part of the Command Router refactor
(roadmap item #67). The pattern every other domain module (files,
apps, system, keyboard, ...) will follow is the same:

    handle(t) -> str | None

    - Returns the spoken-reply string if this domain recognized and
      already EXECUTED the command.
    - Returns None if this domain doesn't own this command, so the
      caller in jarvis_up.py can keep checking other domains.

jarvis_up.py stays responsible for actually calling speak() with the
result -- this module only matches commands and runs the clipboard
actions, so it has no dependency on jarvis_up.py itself (no circular
import) and can be unit-tested on its own.

ORDERING NOTE (carried over from the old inline block, still true):
this module must be checked BEFORE the file-manager domain. The file
manager's "copy X to <folder>" pattern treats any \\w+ word as a valid
folder name, including the literal word "clipboard" -- so "copy hello
world to clipboard" would otherwise be misread as "copy a file called
'hello world' into a folder called clipboard" before ever reaching the
logic here. Whoever wires up the domain list in jarvis_up.py needs to
put clipboard ahead of files.
"""

import re

from file_manager import find_file
from clipboard_control import (
    get_clipboard_text, set_clipboard_text,
    read_clipboard_summary, save_clipboard_to_file,
    copy_file_to_clipboard, copy_image_to_clipboard,
)

# --- Exact-phrase commands -------------------------------------------
# Anything with no variable part (no filename, no free text to copy)
# goes here as a straight dict lookup -- fastest and clearest path,
# same idea as the "Command Registry" pattern.

READ_PHRASES = (
    "what's in my clipboard", "what is in my clipboard",
    "read my clipboard", "read clipboard", "check my clipboard",
)

SAVE_PHRASES = (
    "save my clipboard", "save the clipboard",
    "save clipboard to a file", "save clipboard as a text file",
)

# --- Variable-phrase command ------------------------------------------
# "copy X" / "set clipboard to X" [optionally "...to clipboard"] --
# needs a regex since X is free text (or a filename).
_SET_RE = re.compile(r"(?:copy|set clipboard to) (.+?)(?: to (?:the )?clipboard)?$")


def _handle_set(t: str) -> str:
    match = _SET_RE.match(t)
    target = match.group(1).strip()

    # If the target resolves to a real file (e.g. "my resume"), copy
    # the FILE itself (CF_HDROP) -- same as Ctrl+C on it in Explorer.
    # Only fall back to literal text if no matching file exists, so
    # "copy hello world" (no such file) still works as plain text.
    found_file = find_file(target)
    if found_file is not None:
        success = copy_file_to_clipboard(found_file)
        return (f"Copied {found_file.name} to clipboard." if success
                else f"I couldn't copy {found_file.name} to the clipboard.")

    success = set_clipboard_text(target)
    return "Copied to clipboard." if success else "I couldn't set the clipboard."


def handle(t: str) -> str | None:
    """t is the already-lowercased, stripped command text (same as the
    `t` variable in jarvis_up.py's _dispatch_command). Returns the
    spoken-reply string if handled, else None."""
    if t in READ_PHRASES:
        return read_clipboard_summary()

    if t in SAVE_PHRASES:
        return save_clipboard_to_file()

    set_match = _SET_RE.match(t)
    if set_match and ("clipboard" in t or t.startswith("copy ")):
        return _handle_set(t)

    return None
