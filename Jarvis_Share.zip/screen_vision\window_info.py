"""
window_info.py -- L0: which window/app is currently active.

Cheapest, fastest tier -- no screenshot, no OCR, no network. Same
win32gui.GetForegroundWindow() pattern already used elsewhere in this
project (call_contact.py, send_message.py) to remember/restore the
previous window.
"""

import win32gui
import win32process
import psutil


def get_active_window_info() -> dict:
    """Returns {"title": str, "process_name": str} for whatever window
    currently has focus. Never raises -- returns empty strings on
    failure rather than crashing the pipeline over this cheap first step."""
    try:
        hwnd = win32gui.GetForegroundWindow()
        title = win32gui.GetWindowText(hwnd)

        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        process_name = psutil.Process(pid).name()

        return {"title": title, "process_name": process_name}
    except Exception:
        return {"title": "", "process_name": ""}
