"""
action_types.py -- shared vocabulary for the Action Engine (SEE -> LOCATE ->
ACT -> VERIFY). Small on purpose: a status enum, a result object, and one
logging helper so every action logs the same ACTION_* lines into the
existing jarvis.log (logger "jarvis.action" propagates to "jarvis").
"""

import logging
import time
from dataclasses import dataclass, field
from enum import Enum

log = logging.getLogger("jarvis.action")


class ActionStatus(str, Enum):
    SUCCESS = "SUCCESS"                    # done AND verified
    FAILED = "FAILED"
    NOT_FOUND = "NOT_FOUND"                # target (app/contact/control) not found
    TIMEOUT = "TIMEOUT"
    NEEDS_CONFIRMATION = "NEEDS_CONFIRMATION"
    CANCELLED = "CANCELLED"
    AMBIGUOUS = "AMBIGUOUS"                # several candidates -- must ask the user
    UNVERIFIED = "UNVERIFIED"              # action ran but could not be proven


@dataclass
class ActionResult:
    status: ActionStatus
    message: str = ""                      # spoken-friendly sentence
    detail: str = ""                       # for the log
    method: str = ""                       # how it was done (UIA / OCR / keyboard ...)
    elapsed: float = 0.0
    data: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.status == ActionStatus.SUCCESS


def log_event(event: str, text: str = "", **fields):
    """ACTION_REQUEST / ACTION_PLANNING / ACTION_LOCATING / ACTION_EXECUTING /
    ACTION_VERIFYING / ACTION_SUCCESS / ACTION_FAILURE."""
    extra = " | ".join(f"{k.upper()}={v}" for k, v in fields.items() if v not in (None, ""))
    log.info("%s: %s%s", event, text, f" | {extra}" if extra else "")


class Stopwatch:
    def __init__(self):
        self.t0 = time.monotonic()

    def lap(self) -> float:
        return round(time.monotonic() - self.t0, 2)
