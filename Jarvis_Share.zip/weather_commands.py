"""
weather_commands.py -- weather-related voice command matching.

Part of the Command Router refactor (see command_router.py). The
actual weather lookup (wttr.in call) lives in weather.py -- this file
is purely the voice-command layer on top of it.
"""

import re

from weather import get_weather

_WEATHER_LOCATION_RE = re.compile(
    r"(?:what's|what is|how's|how is)?\s*(?:the )?weather(?: in| for) (.+)$"
)


def try_handle(t: str, speak) -> bool:
    """Checks `t` (the lowercased, stripped transcript) against every
    weather command this domain knows.

    Returns True and calls speak(...) if handled. Returns False
    (without calling speak at all) if this domain doesn't recognize
    the phrase, so the router can try the next domain.
    """
    if t in ("what's the weather", "what is the weather", "weather",
              "how's the weather", "how is the weather"):
        speak(get_weather())
        return True

    match = _WEATHER_LOCATION_RE.match(t)
    if match:
        speak(get_weather(match.group(1).strip()))
        return True

    return False
