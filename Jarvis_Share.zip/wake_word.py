"""
Wake-word gating for the desktop assistant.

Wake word: "hey Jarvis" ("hey R R" is switched off -- see _WAKE_PATTERNS).
Two ways to trigger a command:
    "hey Jarvis"              -> assistant says "Yes?" and listens
                                  separately for your next sentence
    "hey Jarvis, open chrome" -> runs immediately in one breath

There's no dedicated wake-word model here -- the utterance is transcribed
offline with faster-whisper (shared with jarvis_up.py) and the text is
checked for the wake word. Set WAKE_ENGINE = "google" to use Google instead.

WHY THIS FILE MATCHES THE WAY IT DOES
  * The transcript is lowercased before checking. The old check compared it
    with "hey R R" (capital R), which can therefore never match -- that is
    why Jarvis stopped waking up.
  * Speech engines write spoken letters in many ways ("hey rr", "hey r r",
    "hey are are", "hey R.R."), so the match accepts those sound-alikes.
  * Anything it hears that does NOT match is logged to jarvis.log as
    WAKE_HEARD, so a new spelling can be added to WAKE_ALIASES in seconds
    instead of guessing. Network/Google failures are logged too (they used
    to fail silently, which also looks like "not activating").

TIMEOUT: bounded (not None) specifically so the caller's loop gets
control back every few seconds even during silence -- this is what
lets a global hotkey (Ctrl+Alt+J) checked in that same loop actually
be responsive, instead of potentially blocking forever waiting for any
speech to start.
"""

import difflib
import logging
import os
import re
import time

import numpy as np
import speech_recognition as sr

logger = logging.getLogger("jarvis")

# Shown / spoken in prompts ("Say hey R R to activate"). Matching does NOT use
# this string directly -- see _WAKE_RE and WAKE_ALIASES below.
WAKE_WORD = "hey Jarvis"
LISTEN_TIMEOUT = 4  # seconds of silence before returning control to the caller

# Extra exact phrases that should also wake Jarvis, lowercase. Add whatever
# WAKE_HEARD lines in jarvis.log show Google actually writing, e.g. "hey arar".
WAKE_ALIASES = []

# One spoken "R" as Google may write it
_ONE_R = r"(?:r|are|ar|arr|err)"
_SEP = r"[\s,.\-]*"
# "hey" + either a glued "rr"/"rrr", or two single R sounds in a row
_WAKE_RE = re.compile(
    rf"\b(?:hey|hay)\b{_SEP}(?:rr+\b|{_ONE_R}\b{_SEP}{_ONE_R}\b)"
)
# "hey jarvis" (still needs the "hey", so just mentioning Jarvis doesn't wake it)
# Includes sound-alikes the speech engines tend to write for "Jarvis".
_JARVIS_RE = re.compile(
    rf"\b(?:hey|hay|a)\b{_SEP}(?:jarvis|jarvas|jervis|travis|jar vis|jar this|jar is)\b"
)
# "hey R R" is intentionally NOT active. To bring it back: (_JARVIS_RE, _WAKE_RE)
_WAKE_PATTERNS = (_JARVIS_RE,)

# Which engine hears the wake word: "whisper" (offline faster-whisper, same
# setup as jarvis_up.py) or "google" (needs internet).
WAKE_ENGINE = "whisper"

# Shared from jarvis_up.py via set_whisper_model(). If it's never called, a
# small model is loaded lazily on the first wake-word listen.
WAKE_WHISPER_MODEL_NAME = "base.en"
_whisper_model = None


def set_whisper_model(model):
    """Called by jarvis_up.py once its Whisper model is loaded (avoids loading twice)."""
    global _whisper_model
    _whisper_model = model


def _get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel
        _whisper_model = WhisperModel(
            WAKE_WHISPER_MODEL_NAME, device="cpu", compute_type="int8",
            cpu_threads=max(4, (os.cpu_count() or 4) // 2))
    return _whisper_model


# Whisper hallucinates these from silence/noise.
_WHISPER_JUNK = {"you", "thank you", "thanks", "thanks for watching", "bye", "okay",
                 "so", "the", "uh", "um", "hmm", ""}


def _whisper_wake_text(audio: sr.AudioData):
    """Transcribes one captured utterance with Whisper; returns lowercase text."""
    raw = audio.get_raw_data(convert_rate=16000, convert_width=2)
    audio_np = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    segments, _ = _get_whisper_model().transcribe(
        audio_np,
        language="en",
        beam_size=1,                       # greedy: wake check should be fast
        temperature=0.0,
        initial_prompt="Hey Jarvis, open chrome.",   # spells "Jarvis" correctly
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=400),
        condition_on_previous_text=False,
    )
    text = " ".join(s.text for s in segments
                    if not (s.no_speech_prob > 0.6 and s.avg_logprob < -1.0))
    text = text.strip().lower()
    return "" if text.strip(" .,!?") in _WHISPER_JUNK else text


_last_net_error_log = None   # monotonic time of the last logged network error

# Fuzzy fallback: "hey" + 1-2 words that SOUND like "jarvis" (speech engines
# sometimes write "jar this", "job is", "service"...). Needs the "hey" first, so
# ordinary sentences don't wake it.
_FUZZY_MIN_RATIO = 0.6
_FUZZY_EXTRA = {"job is", "service", "jarbis", "jarvice", "charvis"}
_HEY = {"hey", "hay", "a", "hi", "hate"}


def _fuzzy_jarvis(text: str):
    """Returns the text after a fuzzy 'hey jarvis', or None."""
    words = re.findall(r"[a-z']+", text)
    for i, w in enumerate(words[:3]):
        if w not in _HEY:
            continue
        for n in (1, 2):
            cand = words[i + 1:i + 1 + n]
            if len(cand) < n:
                continue
            joined = " ".join(cand)
            ratio = difflib.SequenceMatcher(None, "jarvis", "".join(cand)).ratio()
            if ratio >= _FUZZY_MIN_RATIO or joined in _FUZZY_EXTRA:
                return " ".join(words[i + 1 + n:])
    return None


def find_wake(text: str):
    """Checks a lowercase transcript for the wake word.

    Returns None if it isn't there, otherwise whatever was said AFTER it
    ("" if the wake word was said alone).
    """
    matches = [m for m in (p.search(text) for p in _WAKE_PATTERNS) if m]
    if matches:
        m = min(matches, key=lambda x: x.start())      # whichever was said first
        return text[m.end():].lstrip(" ,.-").strip()
    for alias in WAKE_ALIASES:
        alias = alias.lower().strip()
        if alias and alias in text:
            return text.replace(alias, "", 1).lstrip(" ,.-").strip()
    return _fuzzy_jarvis(text)


def listen_for_wake_word(recognizer: sr.Recognizer, mic: sr.Microphone, timeout: float = LISTEN_TIMEOUT):
    """
    Listens for one utterance (bounded by `timeout`) and checks it for
    the wake word.

    Returns:
        None         -- nothing usable heard in this window (silence,
                         unrecognizable speech, or no wake word);
                         caller should just loop again
        ""           -- wake word heard ALONE; caller should prompt and
                         listen again for the actual command
        "<command>"  -- wake word heard WITH a command in the same
                         breath; caller should run this command immediately
    """
    global _last_net_error_log

    with mic as source:
        try:
            audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=5)
        except sr.WaitTimeoutError:
            return None

    if WAKE_ENGINE == "whisper":
        try:
            text = _whisper_wake_text(audio)
        except Exception as e:
            logger.warning(f"WAKE: Whisper failed: {e!r}")
            return None
        if not text:
            return None
        remainder = find_wake(text)
        if remainder is None:
            logger.info(f"WAKE_HEARD (no match): {text!r}")
            return None
        return remainder

    try:
        text = recognizer.recognize_google(audio).lower().strip()
    except sr.UnknownValueError:
        return None                       # noise / unintelligible: normal
    except sr.RequestError as e:
        # Google unreachable or refusing the request: Jarvis can't hear the
        # wake word at all. Log it (at most every 30 s) instead of failing silently.
        now = time.monotonic()
        if _last_net_error_log is None or now - _last_net_error_log > 30:
            _last_net_error_log = now
            logger.warning(f"WAKE: Google speech request failed, wake word can't be heard: {e!r}")
        return None

    remainder = find_wake(text)
    if remainder is None:
        if text:
            logger.info(f"WAKE_HEARD (no match): {text!r}")
        return None
    return remainder
