"""
ocr.py -- L1: local text extraction from a screenshot via Windows'
own OCR engine (Windows.Media.Ocr), reached through the `winocr`
package. No network call, no API cost.

pip install winocr

Changes from the original: failures are now LOGGED (they used to be
swallowed silently, which made "no text found" impossible to debug),
the result is read defensively (object with .text / .lines, or dict),
and several language tags are tried since Windows only OCRs languages
that are installed on the PC.
"""

import logging

import winocr

logger = logging.getLogger("jarvis.ocr")

# Tried in order until one returns text.
_LANGS = ("en-US", "en")


def _result_text(result) -> str:
    if result is None:
        return ""
    if isinstance(result, dict):
        text = result.get("text") or ""
        if not text:
            lines = result.get("lines") or []
            text = "\n".join((ln.get("text", "") if isinstance(ln, dict) else getattr(ln, "text", ""))
                             for ln in lines)
        return text
    text = getattr(result, "text", None)
    if text:
        return text
    lines = getattr(result, "lines", None)
    if lines:
        return "\n".join(getattr(ln, "text", "") for ln in lines)
    return ""


def extract_text(image) -> str:
    """Runs local OCR on a PIL Image, returns the extracted text as one
    string. Returns "" if OCR finds nothing or fails (never raises), but
    now logs why."""
    for lang in _LANGS:
        try:
            result = winocr.recognize_pil_sync(image, lang=lang)
            text = _result_text(result).strip()
            logger.info("OCR lang=%s image=%s chars=%d result_type=%s",
                        lang, getattr(image, "size", "?"), len(text), type(result).__name__)
            print(f"[OCR] lang={lang} size={getattr(image, 'size', '?')} "
                  f"chars={len(text)} result_type={type(result).__name__}")
            if text:
                return text
        except Exception as e:
            logger.warning("OCR failed lang=%s: %r", lang, e, exc_info=True)
            print(f"[OCR] lang={lang} FAILED: {e!r}")
    return ""
