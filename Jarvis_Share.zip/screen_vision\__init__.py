"""
screen_vision -- lets Jarvis look at and understand the screen.

Public API (everything else in this package is an internal tier,
not meant to be imported directly from outside):

    handle_screen_request(question: str) -> str
        General screen Q&A. Runs L0 -> L1 -> math shortcut -> L2/L3,
        escalating only as far as actually needed. Use for "what's on
        my screen", "why is this showing an error", "explain this", etc.

    copy_screen_text() -> str
        The action tier: OCR the screen, copy the extracted text
        straight to the clipboard. No Gemini call at all.

See pipeline.py for the escalation logic itself.
"""

from .pipeline import handle_screen_request, copy_screen_text

__all__ = ["handle_screen_request", "copy_screen_text"]
