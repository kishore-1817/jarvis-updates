"""
Keyboard control -- lets Jarvis type text and press keys/hotkeys into
whatever window currently has focus. Uses clipboard pasting for high
accuracy without character dropping or duplication on Windows.
"""

import time

try:
    import keyboard
    _KEYBOARD_CONTROL_AVAILABLE = True
except Exception:
    _KEYBOARD_CONTROL_AVAILABLE = False

try:
    import win32gui
    _WIN32GUI_AVAILABLE = True
except Exception:
    _WIN32GUI_AVAILABLE = False

from clipboard_control import get_clipboard_text, set_clipboard_text

_KEY_ALIASES = {
    "escape": "esc",
    "return": "enter",
    "spacebar": "space",
    "control": "ctrl",
    "windows key": "windows",
    "page up": "page up",
    "page down": "page down",
}

# Jarvis's global End-key kill switch (in jarvis_up.py) must not fire when
# Jarvis itself presses End ("press end", "shift end", ...). Pressing a combo
# that contains "end" arms this short guard window, which the watcher checks.
_end_guard_until = 0.0


def end_key_guard_active() -> bool:
    return time.monotonic() < _end_guard_until


_UNAVAILABLE_MSG = ("Keyboard control isn't available -- the `keyboard` "
                     "package isn't installed. Run: pip install keyboard")


def _active_window_title() -> str:
    """Best-effort title of whatever window currently has focus."""
    if not _WIN32GUI_AVAILABLE:
        return ""
    try:
        return win32gui.GetWindowText(win32gui.GetForegroundWindow())
    except Exception:
        return ""


def type_text(text: str) -> str:
    """Types text accurately into whatever window currently has focus."""
    if not _KEYBOARD_CONTROL_AVAILABLE:
        return _UNAVAILABLE_MSG

    window_title = _active_window_title()

    try:
        # Save previous clipboard content to restore later
        old_clip = get_clipboard_text()

        # Inject text into clipboard and paste with Ctrl+V
        if set_clipboard_text(text):
            time.sleep(0.05)
            keyboard.send("ctrl+v")
            time.sleep(0.05)

            # Restore original clipboard content
            if old_clip:
                set_clipboard_text(old_clip)
        else:
            # Fallback to direct key simulation if clipboard fails
            keyboard.write(text, delay=0.03)

        if window_title:
            return f"Typed into '{window_title}': {text}"
        return f"Typed: {text}"
    except Exception as e:
        return f"I couldn't type that: {e}"


def press_keys(spoken: str) -> str:
    """Presses a key or key combo, e.g. 'enter', 'ctrl c', 'alt tab'."""
    if not _KEYBOARD_CONTROL_AVAILABLE:
        return _UNAVAILABLE_MSG

    words = spoken.strip().lower().split()
    if not words:
        return "I didn't catch which key to press."

    keys = [_KEY_ALIASES.get(w, w) for w in words]
    combo = "+".join(keys)

    global _end_guard_until
    if "end" in keys:
        _end_guard_until = time.monotonic() + 1.0   # arm before the key goes out
    try:
        keyboard.press_and_release(combo)
        if "end" in keys:
            _end_guard_until = time.monotonic() + 0.5   # cover key-up delay
        return f"Pressed {combo}."
    except Exception as e:
        return f"I couldn't press that: {e}"