"""
Windows Voice Assistant (Jarvis) -- opens real apps by voice
--------------------------------------------------------------
SETUP (run once in Command Prompt / PowerShell):

    pip install SpeechRecognition pyttsx3 pywin32 pipwin
    pipwin install pyaudio

    (pyaudio sometimes fails with plain pip on Windows -- pipwin fixes
     that. If pipwin also fails, download a matching PyAudio wheel from
     https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio and
     `pip install that_file.whl`)

    Speech recognition (offline Whisper):
    pip install faster-whisper
    (the Whisper model downloads itself the first time Jarvis runs)

    New for PC control features:
    pip install pycaw comtypes screen-brightness-control
    (volume commands need pycaw+comtypes; brightness commands need
     screen-brightness-control. Everything else -- restart, sleep,
     recycle bin, show desktop, battery, storage, focus assist, wifi --
     works with libraries already installed.)

RUN:
    python jarvis.py

    On first run, it scans your Start Menu + registry for installed
    apps (~a few seconds) and caches the result to app_paths.json. It
    only does this once -- after that it just loads the cache. Say
    "rescan apps" any time you install new software to refresh it.

USAGE:
    Say things like: "open chrome", "close chrome", "open notepad",
    "open discord", "open file manager", "open downloads",
    "copy report to desktop", "move photo to documents",
    "search for pizza recipes", "what time is it", "rescan apps",
    "exit"/"quit"/"goodbye" to close the program.

    PC control: "restart", "sleep", "mute"/"unmute", "volume up"/"down",
    "set volume to 50", "empty the recycle bin", "show desktop",
    "what's my battery", "how much storage do I have",
    "brightness up"/"down", "set brightness to 70",
    "turn on/off do not disturb", "what network am I on",
    "connect to wifi <name>" (only for networks already saved on this PC),
    "turn on/off wifi", "turn on/off bluetooth" (both need Administrator),
    "turn on/off night light" (unverified best-effort, see code comment).

    File commands look for the named file (with or without extension) in
    your Downloads, Desktop, and Documents folders, in that order, and
    copy/move it into: desktop, documents, downloads, pictures, music, videos.

    Anything that doesn't match a built-in command is sent to Gemini
    for a real conversational answer (see llm_brain.py).

NO MORE HARDCODED APP PATHS:
    App locations are auto-discovered per machine (see app_finder.py)
    instead of hardcoded -- this file no longer needs editing when you
    move to a different laptop.
"""

import sys
import os


# pythonw.exe (no console) can leave sys.stdout/stderr as None on some
# Python versions -- any print() or library that writes to them would
# then crash silently with no visible error. Guard against that before
# anything else runs.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

import speech_recognition as sr
import subprocess
import webbrowser
import psutil
import datetime
import shutil
import re
import ctypes
import time
import winreg
import threading
import queue
from pathlib import Path
from PIL import ImageGrab
import difflib
import hashlib

# --- LOCAL OFFLINE SPEECH RECOGNITION ---
import numpy as np

# Model size is the biggest accuracy lever. On CPU:
#   "tiny.en"  = fastest of all, mangles names (0.3s)
#   "base.en"  = fast, mishears names/numbers more often (0.7s)  <- default now
#   "small.en" = better accuracy (2.2s on this PC -- measured with whisper_bench.py)
#   "medium.en" or "distil-large-v3" = most accurate, slower (needs a decent CPU)
# small.en cost ~2.2s PER COMMAND whether you spoke 1.5s or 6s, and neither
# beam size nor more threads made it faster, so the model size is the lever.
WHISPER_MODEL_NAME = "base.en"
# Two-pass: when base.en is not confident in what it heard, the same clip is
# re-run on this bigger model (adds ~2s, only on those clips). Set the model
# to None to turn the second pass off. conf= is logged on every STT_TIMING
# line so the threshold can be tuned from real data (closer to 0 = fallback
# more often; -1.0 = rarely).
WHISPER_FALLBACK_MODEL = "small.en"
WHISPER_FALLBACK_LOGPROB = -0.7
# 5 = most accurate (current), 1 = greedy/fastest. Lowering it trades
# accuracy for transcription speed -- decide from the STT_TIMING log lines.
WHISPER_BEAM_SIZE = 5

try:
    from faster_whisper import WhisperModel
    print(f"Loading local Whisper model '{WHISPER_MODEL_NAME}' (first run downloads it)...")
    whisper_model = WhisperModel(WHISPER_MODEL_NAME, device="cpu", compute_type="int8",
                                 cpu_threads=max(4, (os.cpu_count() or 4) // 2))
    _WHISPER_AVAILABLE = True
except Exception as e:
    print(f"Faster-Whisper not available, falling back to Google: {e}")
    _WHISPER_AVAILABLE = False

# Splash progress: Whisper model loaded (the slowest startup step)
try:
    from jarvis_splash import signal_progress
    signal_progress(50)
except Exception:
    pass

_whisper_fallback = None                 # bigger model, loaded in the background (see main())
_last_stt_info = {"model": WHISPER_MODEL_NAME, "conf": None, "fallback": False}


def _load_whisper_fallback():
    """Loads the bigger model in a background thread so startup isn't
    delayed; until it's ready the fast model's answer is simply used."""
    global _whisper_fallback
    if not (_WHISPER_AVAILABLE and WHISPER_FALLBACK_MODEL
            and WHISPER_FALLBACK_MODEL != WHISPER_MODEL_NAME):
        return
    try:
        _whisper_fallback = WhisperModel(
            WHISPER_FALLBACK_MODEL, device="cpu", compute_type="int8",
            cpu_threads=max(4, (os.cpu_count() or 4) // 2))
        logger.info(f"Whisper fallback model '{WHISPER_FALLBACK_MODEL}' ready")
    except Exception as e:
        logger.warning(f"Whisper fallback model unavailable: {e!r}")


# Whisper "hears" these from silence/noise -- never real commands.
_WHISPER_JUNK = {"you", "thank you", "thanks", "thanks for watching", "bye", "okay",
                 "so", "the", "uh", "um", "hmm", ""}

# Whisper invents text on noise/silence, often echoing its own initial_prompt
# (contact names, saved keys) in a loop -- seen in the log as "tola, tola, ..."
# and "tarun prasad's birthday" x20. Real speech is ~2-3 words/second.
_GHOST_PHRASES = ("thanks for watching", "thank you for watching", "please subscribe")


def _is_hallucination(text: str, audio_seconds: float = None) -> bool:
    toks = re.findall(r"[a-z0-9']+", (text or "").lower())
    if not toks:
        return False
    low = text.lower()
    if any(p in low for p in _GHOST_PHRASES):
        return True
    # 1) impossible speech rate
    if audio_seconds and len(toks) >= 6 and len(toks) / audio_seconds > 5.0:
        return True
    # 2) looping text: few distinct words repeated over and over
    if len(toks) >= 8 and len(set(toks)) / len(toks) < 0.35:
        return True
    # 3) same word 5+ times in a row
    run = 1
    for a, b in zip(toks, toks[1:]):
        run = run + 1 if a == b else 1
        if run >= 5:
            return True
    return False


def _contacts_hint() -> str:
    """Your WhatsApp contact names (from send_message.KNOWN_CONTACTS), so
    Whisper spells them correctly instead of 'balaji the rice'."""
    try:
        from send_message import KNOWN_CONTACTS
        return "WhatsApp contacts: " + ", ".join(KNOWN_CONTACTS) + ". "
    except Exception:
        return ""


def _whisper_prompt() -> str:
    """Vocabulary hint: Whisper spells words in this prompt correctly
    ('mail ID' instead of 'mail lady'). Pulls your saved keys live."""
    try:
        keys = ", ".join(memory.get_all_keys()[:20])
    except Exception:
        keys = ""
    return ("Jarvis voice commands: open, close, type my personal mail id, "
            "type my college mail id, type my mobile number, type my home address, "
            "send message, call, WhatsApp, volume, brightness, screenshot, "
            "rescan apps, set a timer, remind me, screen recording, write the code, "
            "check my unread mail, any new emails, read my latest email, search my email, "
            "what's on my calendar, send it, cancel, change brain, "
            "fix the code, run the code, the question on my screen, fill this form. " + _contacts_hint() + keys)


# Words Whisper keeps confusing with "code" when talking about programming.
_MISHEARD_FIXES = [
    (re.compile(r"\b(?:written|unwritten|in ?red|on ?red) (?:back|mails?|male)\b", re.I), "unread mail"),
    (re.compile(r"\b(lines? of|rest of the|remaining|complete|finish|fix|correct|java|python|c\+\+) (?:quotes?|coat|cord|could)\b", re.I), r"\1 code"),
    (re.compile(r"\b(write|type|paste|generate|give me|show me) (the |this |that |my |a )?(remaining |full |whole |complete |java |python )?(?:quotes?|coat|cord)\b", re.I), r"\1 \2\3code"),
    (re.compile(r"\b(?:quotes?|coat) (for|of|in|on) (the|this|that|my) (question|problem|screen|editor)\b", re.I), r"code \1 \2 \3"),
]


def _fix_misheard(text: str) -> str:
    for pattern, repl in _MISHEARD_FIXES:
        text = pattern.sub(repl, text)
    return re.sub(r"\s{2,}", " ", text).strip()


def _run_whisper(model, audio_np):
    """One transcription pass. Returns (text, mean avg_logprob or None)."""
    segments, _ = model.transcribe(
        audio_np,
        language="en",
        beam_size=WHISPER_BEAM_SIZE,       # was 1 (greedy) -> noticeably more accurate
        temperature=0.0,
        initial_prompt=_whisper_prompt(),
        vad_filter=True,                   # ignore silence/noise -> no phantom "You"
        vad_parameters=dict(min_silence_duration_ms=400),
        condition_on_previous_text=False,
    )
    kept = [s_ for s_ in segments
            if not (s_.no_speech_prob > 0.6 and s_.avg_logprob < -1.0)
            and getattr(s_, "compression_ratio", 0.0) <= 2.4]   # >2.4 = repetitive loop
    text = " ".join(s_.text for s_ in kept).strip()
    conf = (sum(s_.avg_logprob for s_ in kept) / len(kept)) if kept else None
    return text, conf


def transcribe_audio(audio: sr.AudioData) -> str:
    """Converts audio to text using offline Whisper, falls back to Google if missing."""
    if _WHISPER_AVAILABLE:
        raw = audio.get_raw_data(convert_rate=16000, convert_width=2)
        audio_np = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0

        text, conf = _run_whisper(whisper_model, audio_np)
        used, fell_back = WHISPER_MODEL_NAME, False
        audio_seconds = len(audio_np) / 16000.0
        if _is_hallucination(text, audio_seconds):
            logger.info("STT_HALLUCINATION dropped (fast model): %r", text[:80])
            _last_stt_info.update(model=used, conf=conf, fallback=False)
            return ""

        # Fast model unsure? Re-check the same clip with the bigger one.
        if (text and conf is not None and conf < WHISPER_FALLBACK_LOGPROB
                and _whisper_fallback is not None):
            text2, conf2 = _run_whisper(_whisper_fallback, audio_np)
            logger.info("STT_FALLBACK conf=%.2f fast=%r bigger=%r", conf, text, text2)
            if text2 and _is_hallucination(text2, audio_seconds):
                logger.info("STT_HALLUCINATION dropped (fallback model): %r", text2[:80])
                _last_stt_info.update(model=WHISPER_FALLBACK_MODEL, conf=conf2, fallback=True)
                return ""
            if text2:
                text, conf, used, fell_back = text2, conf2, WHISPER_FALLBACK_MODEL, True

        _last_stt_info.update(model=used, conf=conf, fallback=fell_back)
        if text.lower().strip(" .,!?") in _WHISPER_JUNK:
            return ""
        # One word repeated 3+ times ("no, no, no, no") is Whisper hallucinating
        # on noise, not a command -- don't send it to Gemini (wastes quota + time).
        _toks = re.findall(r"[a-z']+", text.lower())
        if len(_toks) >= 3 and len(set(_toks)) == 1:
            return ""
        return _fix_misheard(text)
    else:
        return _interrupt_recognizer.recognize_google(audio)
# ----------------------------------------

# Neural TTS (edge-tts) -- much more natural voice than pyttsx3, and
# since synthesis happens on Microsoft's servers it's fast even on a
# CPU-only laptop. Needs internet; falls back to pyttsx3 if unavailable
# (no connection, library missing, etc.) so the assistant never goes
# silent just because this failed.
try:
    import asyncio
    import tempfile
    import edge_tts
    import pygame
    pygame.mixer.init()  # pre-warm here, once, instead of paying this cost
                          # on your very first spoken reply mid-conversation
    _EDGE_TTS_AVAILABLE = True
except Exception:
    _EDGE_TTS_AVAILABLE = False

JARVIS_VOICE = "en-GB-LibbyNeural"      # female. For a male Jarvis try "en-GB-RyanNeural"
JARVIS_SPEECH_RATE = "+20%"

# --- keeping ONE voice -------------------------------------------------------
# Jarvis only ever speaks with JARVIS_VOICE (edge-tts). There is NO offline
# fallback voice: if edge-tts fails, it is retried, and if it still fails the reply
# is only printed/logged -- Jarvis never switches to a different voice.
TTS_EDGE_RETRIES = 2          # extra attempts after the first one
TTS_RETRY_DELAY = 0.5         # seconds between attempts

from app_finder import load_app_index, find_app_path, build_app_index
from system_stats import get_performance_summary
from temperature import get_temperature_summary
from corrections import correct_text
from wake_word import listen_for_wake_word, WAKE_WORD
from music_player import play_song
from system_control import (
    shutdown_pc, cancel_shutdown, restart_pc, sleep_pc, lock_pc,
    set_volume_percent, adjust_volume, set_mute,
    empty_recycle_bin, show_desktop, get_battery_status, get_storage_summary,
    set_brightness_percent, adjust_brightness,
    focus_assist_on, focus_assist_off,
    get_current_wifi, connect_to_wifi, set_wifi_radio, set_bluetooth_radio,
    night_light_on, night_light_off,
)
import file_manager
from file_manager import (
    FOLDERS, HOME, resolve_folder_key, open_folder, find_file,
    copy_or_move_file, copy_or_move_to_path_command,
    find_command, open_command, rename_command, delete_command,
    create_folder_command, delete_folder_command,
    list_files_command, search_folder_command,
    show_location_command, duplicate_command,
)
import llm_brain
import brain_switch
import google_tools
from llm_brain import ask_llm, ask_llm_stream
import memory
import lessons
from call_contact import call_contact
import command_router
try:
    import hud  # optional ambient HUD (hud.py); every call is safe/non-blocking
except Exception:
    import types as _types
    _noop = lambda *a, **k: None
    hud = _types.SimpleNamespace(
        start=_noop, stop=_noop, set_state=_noop, success=_noop, heard=_noop,
        move_mode=_noop, reset_position=_noop, set_theme=_noop, next_theme=_noop,
        hide=_noop, show=_noop,
        resolve_theme=lambda text: None, current_theme=lambda: None,
        speaking_start=_noop, speaking_end=_noop,
        executing_begin=_noop, executing_end=_noop,
        wrap_tool=lambda f: f, wrap_tools=lambda fs: fs)
from send_message import send_message, resolve_contact
from weather import get_weather
from local_math import try_math_command
from screen_vision import handle_screen_request, copy_screen_text
from keyboard_control import type_text, press_keys
from clipboard_control import (
    get_clipboard_text, set_clipboard_text,
    read_clipboard_summary, save_clipboard_to_file,
    copy_file_to_clipboard, copy_image_to_clipboard,
)

SPOKEN_APP_CORRECTIONS = {
    "cloud": "claude",
}

BUILTIN_COMMANDS = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "calc": "calc.exe",
    "paint": "mspaint.exe",
    "file explorer": "explorer.exe",
    "explorer": "explorer.exe",
    "task manager": "taskmgr.exe",
    "settings": "start ms-settings:",
    "control panel": "control.exe",
    "cmd": "start cmd",
    "command prompt": "start cmd",
    "chrome": "start chrome",
    "google chrome": "start chrome",
    "edge": "start msedge",
    "microsoft edge": "start msedge",
    "whatsapp": "start whatsapp:",
    "camera": "start microsoft.windows.camera:",
}

PROCESS_NAMES = {
    "notepad": "notepad.exe",
    "calculator": "CalculatorApp.exe",
    "calc": "CalculatorApp.exe",
    "paint": "mspaint.exe",
    "file explorer": "explorer.exe",
    "explorer": "explorer.exe",
    "task manager": "Taskmgr.exe",
    "cmd": "cmd.exe",
    "command prompt": "cmd.exe",
    "chrome": "chrome.exe",
    "google chrome": "chrome.exe",
    "edge": "msedge.exe",
    "microsoft edge": "msedge.exe",
    "whatsapp": "WhatsApp.Root.exe",
    "camera": "WindowsCamera.exe",
}

print("Indexing installed apps (first run only, cached after)...")
APP_INDEX = load_app_index()
print(f"Indexed {len(APP_INDEX)} apps.")

ERROR_LOG_PATH = Path(__file__).parent / "jarvis_error.log"

import logging
from logging.handlers import RotatingFileHandler

LOG_PATH = Path(__file__).parent / "jarvis.log"

logger = logging.getLogger("jarvis")
logger.setLevel(logging.DEBUG)
logger.propagate = False

if not logger.handlers:
    _file_handler = RotatingFileHandler(LOG_PATH, maxBytes=2_000_000, backupCount=2, encoding="utf-8")
    _file_handler.setLevel(logging.DEBUG)
    _file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    logger.addHandler(_file_handler)

STATE_STANDBY = "STANDBY"
STATE_LISTENING = "LISTENING"
STATE_THINKING = "THINKING"
STATE_EXECUTING = "EXECUTING"
STATE_SPEAKING = "SPEAKING"
STATE_ERROR = "ERROR"

_current_state = STATE_STANDBY
_speak_lock = threading.Lock()

STOP_PHRASES = {"stop", "stop talking", "shut up", "quiet", "be quiet",
                "jarvis stop", "silence", "okay stop", "hey"}

_interrupt_recognizer = sr.Recognizer()
_shared_mic = None
_mic_lock = threading.Lock()
_interrupt_hit = threading.Event()   # set when the user says "stop" mid-speech


# Replies shorter than this are over before anyone could say "stop", so the
# stop-word listener isn't started for them (its shutdown cost 0.3-1.0s after
# every reply -- longer than the reply itself for "Yes?" / "Opening chrome").
_INTERRUPT_MIN_SPEECH_SECONDS = 1.6


def _recognize_unless_stopped(audio, stop_event: threading.Event):
    """Runs Google recognition in a helper thread and gives up the moment
    stop_event is set, so the listener never sits waiting on the network
    after the reply has finished. Returns the text, or None."""
    result = {}

    def _work():
        try:
            result["text"] = _interrupt_recognizer.recognize_google(audio)
        except Exception:
            result["text"] = None

    t = threading.Thread(target=_work, daemon=True)
    t.start()
    while t.is_alive():
        if stop_event.is_set():
            return None
        t.join(timeout=0.05)
    return result.get("text")


def _interrupt_listener(stop_event: threading.Event):
    if _shared_mic is None:
        return

    got_lock = False
    while not stop_event.is_set() and not got_lock:
        got_lock = _mic_lock.acquire(blocking=False)
        if not got_lock:
            time.sleep(0.15)

    if not got_lock:
        return

    try:
        with _shared_mic as source:
            while not stop_event.is_set():
                try:
                    audio = _interrupt_recognizer.listen(source, timeout=0.5, phrase_time_limit=1.5)
                except sr.WaitTimeoutError:
                    continue

                if stop_event.is_set():
                    return

                heard_raw = _recognize_unless_stopped(audio, stop_event)
                if heard_raw is None:
                    continue
                heard = heard_raw.lower().strip(" .,!?")

                logger.debug(f"INTERRUPT_LISTEN heard={heard!r}")
                if heard in STOP_PHRASES or any(p in heard.split() for p in STOP_PHRASES):
                    logger.info(f"INTERRUPT: heard {heard!r} mid-speech, stopping playback")
                    hud.set_state("INTERRUPTED")
                    _interrupt_hit.set()
                    try:
                        pygame.mixer.music.stop()
                    except Exception:
                        pass
                    return
    except Exception as e:
        logger.debug(f"interrupt listener error: {e!r}")
    finally:
        _mic_lock.release()

_last_spoken = ""
_tts_time_accum = 0.0
_last_command_used_llm = False


# Jarvis states forwarded to the HUD. EXECUTING and SPEAKING are deliberately
# NOT forwarded: the HUD gets those from the real events (a tool actually
# running / audio playback actually starting), not from this variable.
_HUD_FORWARD = {
    STATE_STANDBY: "STANDBY",
    STATE_LISTENING: "LISTENING",
    STATE_THINKING: "THINKING",
    STATE_ERROR: "ERROR",
}


def _hud_mirror(new_state: str):
    try:
        name = _HUD_FORWARD.get(new_state)
        if name is None:
            return
        if name == "LISTENING" and file_manager.has_pending():
            name = "CONFIRMATION"  # waiting for the user's yes/no
        hud.set_state(name)
    except Exception:
        pass


def _hud_command_done():
    try:
        if file_manager.has_pending():
            hud.set_state("CONFIRMATION")
        else:
            hud.success()
    except Exception:
        pass


def set_state(new_state: str):
    global _current_state
    _hud_mirror(new_state)
    if new_state != _current_state:
        logger.debug(f"State: {_current_state} -> {new_state}")
        _current_state = new_state


def get_state() -> str:
    return _current_state


# Short replies repeat a lot ("Yes?", "Opening chrome", "Closed chrome.").
# Each fresh synthesis costs a new connection to Microsoft (~0.8-2s in the
# logs), so finished clips are kept on disk and replayed instantly. Only
# short replies are cached, newest 200 kept. It's a local folder of audio
# of recent short replies -- delete tts_cache/ any time, it rebuilds itself.
_TTS_CACHE_DIR = Path(__file__).parent / "tts_cache"
_TTS_CACHE_MAX_FILES = 200
_TTS_CACHE_MAX_WORDS = 14


# edge-tts pads short clips with trailing silence (measured with tts_diag.py:
# "Yes?" is 0.34s of speech inside a 1.87s file, 1.4s of it silence), and
# playback used to wait for all of it. We find where the speech really ends
# and stop shortly after. Set _TRIM_ENABLED = False to restore full playback.
_TRIM_ENABLED = True
_TRIM_THRESHOLD = 300    # 16-bit amplitude below this counts as silence
_TRIM_MARGIN = 0.20      # seconds kept after the last audible sound


def _speech_end_seconds(path):
    """Seconds into the clip where speech ends (+ margin), or None if the
    clip can't be analysed or there's nothing worth trimming."""
    if not _TRIM_ENABLED:
        return None
    try:
        snd = pygame.mixer.Sound(str(path))
        freq, _fmt, chans = pygame.mixer.get_init()
        arr = np.frombuffer(snd.get_raw(), dtype=np.int16).astype(np.int32)
        if chans > 1:
            arr = np.abs(arr[: len(arr) // chans * chans].reshape(-1, chans)).max(axis=1)
        else:
            arr = np.abs(arr)
        n = max(1, freq // 100)                      # 10 ms frames
        frames = arr[: len(arr) // n * n].reshape(-1, n).max(axis=1)
        loud = np.where(frames > _TRIM_THRESHOLD)[0]
        if len(loud) == 0:
            return None
        end = (loud[-1] + 1) * 0.01 + _TRIM_MARGIN
        return end if end < snd.get_length() - 0.15 else None
    except Exception as e:
        logger.debug(f"speech-end analysis failed: {e!r}")
        return None


def _tts_cache_path(text: str) -> Path:
    key = hashlib.sha1(
        f"{JARVIS_VOICE}|{JARVIS_SPEECH_RATE}|{text}".encode("utf-8")
    ).hexdigest()[:24]
    return _TTS_CACHE_DIR / f"{key}.mp3"


def _tts_cache_hit(text: str):
    p = _tts_cache_path(text)
    try:
        if p.exists() and p.stat().st_size > 1000:
            return p
    except OSError:
        pass
    return None


def _tts_cache_store(text: str, src_path):
    """Best-effort copy of a freshly synthesized clip into the cache."""
    if len(text.split()) > _TTS_CACHE_MAX_WORDS:
        return
    try:
        if os.path.getsize(src_path) <= 1000:
            return
        _TTS_CACHE_DIR.mkdir(exist_ok=True)
        dest = _tts_cache_path(text)
        tmp = dest.with_suffix(".tmp")
        shutil.copyfile(src_path, tmp)
        os.replace(tmp, dest)
        files = sorted(_TTS_CACHE_DIR.glob("*.mp3"), key=lambda f: f.stat().st_mtime)
        for old in files[:-_TTS_CACHE_MAX_FILES]:
            old.unlink(missing_ok=True)
    except Exception as e:
        logger.debug(f"tts cache store failed: {e!r}")


def _synthesize_to_file(text: str, path, timing=None):
    async def _go():
        communicate = edge_tts.Communicate(text, JARVIS_VOICE, rate=JARVIS_SPEECH_RATE)
        with open(path, "wb") as f:
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    if timing is not None and timing["first_chunk_at"] is None:
                        timing["first_chunk_at"] = time.monotonic()
                    f.write(chunk["data"])
    asyncio.run(_go())


def _prewarm_tts_cache():
    """Background, at startup: pre-build the fixed phrases Jarvis says most
    so even the first use of each is instant."""
    if not _EDGE_TTS_AVAILABLE:
        return
    phrases = ["Yes?", "Standing by.", "Copied.", "Pasted.", "Done.", "Goodbye!"]
    for phrase in phrases:
        if _tts_cache_hit(phrase) is not None:
            continue
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(suffix=".mp3")
            os.close(fd)
            _synthesize_to_file(phrase, tmp)
            _tts_cache_store(phrase, tmp)
        except Exception as e:
            logger.debug(f"tts prewarm failed for {phrase!r}: {e!r}")
        finally:
            if tmp:
                try:
                    os.remove(tmp)
                except Exception:
                    pass


def _speak_edge_tts(text: str) -> bool:
    tmp_path = None
    cached_path = None
    try:
        timing = {"first_chunk_at": None}
        t_start = time.monotonic()

        cached_path = _tts_cache_hit(text)
        if cached_path is not None:
            cache_state = "hit"
            play_path = cached_path
        else:
            cache_state = "miss"
            tmp_fd, tmp_path = tempfile.mkstemp(suffix=".mp3")
            os.close(tmp_fd)
            _synthesize_to_file(text, tmp_path, timing)
            _tts_cache_store(text, tmp_path)
            play_path = tmp_path
        t_after_synthesis = time.monotonic()

        if not pygame.mixer.get_init():
            pygame.mixer.init()
        t_before_load = time.monotonic()
        pygame.mixer.music.load(str(play_path))
        t_after_load = time.monotonic()

        _t_trim0 = time.monotonic()
        end_s = _speech_end_seconds(play_path)
        trim_calc = time.monotonic() - _t_trim0
        cut_ms = int(end_s * 1000) if end_s else None

        _stop_event = threading.Event()
        _interrupt_thread = None
        if end_s is None or end_s > _INTERRUPT_MIN_SPEECH_SECONDS:
            _interrupt_thread = threading.Thread(
                target=_interrupt_listener, args=(_stop_event,), daemon=True
            )
            _interrupt_thread.start()

        hud.speaking_start()
        pygame.mixer.music.play()
        t_playback_start = time.monotonic()
        while pygame.mixer.music.get_busy():
            if cut_ms is not None and pygame.mixer.music.get_pos() >= cut_ms:
                pygame.mixer.music.stop()      # skip the padded silence
                break
            time.sleep(0.02)
        t_playback_end = time.monotonic()
        pygame.mixer.music.unload()

        _stop_event.set()
        _t_join_start = time.monotonic()
        if _interrupt_thread is not None:
            _interrupt_thread.join(timeout=1.0)
        teardown = time.monotonic() - _t_join_start

        first_chunk_at = timing["first_chunk_at"] or t_after_synthesis
        logger.info(
            "TTS_TIMING cache=%s words=%d connect_to_first_chunk=%.2fs "
            "full_synthesis_and_download=%.2fs pygame_load=%.2fs "
            "playback=%.2fs cut_at=%s trim_calc=%.3fs teardown=%.2fs total=%.2fs",
            cache_state,
            len(text.split()),
            first_chunk_at - t_start,
            t_after_synthesis - t_start,
            t_after_load - t_before_load,
            t_playback_end - t_playback_start,
            f"{end_s:.2f}s" if end_s else "none",
            trim_calc,
            teardown,
            t_playback_end - t_start,
        )
        return True
    except Exception as e:
        logger.warning(f"edge-tts failed: text={text!r} error={e!r}")
        if cached_path is not None:
            # a corrupt cached clip would otherwise fail on every use
            try:
                cached_path.unlink()
            except Exception:
                pass
        return False
    finally:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except Exception:
                pass


_typed_tls = threading.local()      # set only inside typed_command()
_typed_reply_text = ""


def speak(text: str):
    global _last_spoken, _tts_time_accum
    buf = getattr(_typed_tls, "buf", None)
    if buf is not None:                 # typed command: show the reply, don't speak it
        _last_spoken = text
        buf.append(text)
        print(f"Assistant (typed): {text}")
        logger.info(f"REPLY (typed): {text}")
        return
    with _speak_lock:
        _last_spoken = text
        previous_state = get_state()
        set_state(STATE_SPEAKING)
        print(f"Assistant: {text}")
        logger.info(f"SPEAK: {text}")
        _tts_call_start = time.monotonic()
        try:
            if not _EDGE_TTS_AVAILABLE:
                logger.warning("edge-tts not available: reply not spoken (no fallback voice by design)")
                return
            for attempt in range(1 + TTS_EDGE_RETRIES):
                if _speak_edge_tts(text):
                    return
                if attempt < TTS_EDGE_RETRIES:
                    logger.info(f"edge-tts failed; retry {attempt + 1} of {TTS_EDGE_RETRIES}")
                    time.sleep(TTS_RETRY_DELAY)
            logger.warning(f"edge-tts failed after {1 + TTS_EDGE_RETRIES} attempts: reply not spoken")
        finally:
            hud.speaking_end()
            _tts_time_accum += time.monotonic() - _tts_call_start
            set_state(previous_state)

STREAM_REPLIES = True        # False -> old behaviour: wait for the whole reply, then speak
_STREAM_QUEUE_SIZE = 3       # clips synthesized ahead of the one playing


def _synthesize_clip(text: str):
    """Audio clip for `text`: (path, is_temp), or (None, False) if every
    attempt failed. Same voice, cache and retry rules as speak()."""
    cached = _tts_cache_hit(text)
    if cached is not None:
        return cached, False
    for attempt in range(1 + TTS_EDGE_RETRIES):
        fd, tmp = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)
        try:
            _synthesize_to_file(text, tmp)
            _tts_cache_store(text, tmp)
            return tmp, True
        except Exception as e:
            logger.warning(f"edge-tts failed (stream): text={text!r} error={e!r}")
            try:
                os.remove(tmp)
            except Exception:
                pass
            if attempt < TTS_EDGE_RETRIES:
                time.sleep(TTS_RETRY_DELAY)
    return None, False


def _drop_clip(path, is_temp):
    if path is not None and is_temp:
        try:
            os.remove(path)
        except Exception:
            pass


def speak_llm_stream(text: str):
    """Asks Gemini and speaks the reply sentence by sentence while it is
    still being written. A worker thread pulls sentences from the LLM and
    synthesizes them ahead of time; this thread plays them back to back.
    Saying "stop" halts playback and abandons the rest of the reply."""
    global _last_spoken, _tts_time_accum
    cancel = threading.Event()
    sentences = ask_llm_stream(text, should_stop=cancel.is_set)

    if getattr(_typed_tls, "buf", None) is not None or not _EDGE_TTS_AVAILABLE:
        full = " ".join(sentences).strip()
        speak(full)
        return full

    audio_q = queue.Queue(maxsize=_STREAM_QUEUE_SIZE)

    def _producer():
        try:
            for sentence in sentences:
                if cancel.is_set():
                    break
                path, is_temp = _synthesize_clip(sentence)
                audio_q.put((sentence, path, is_temp))
        except Exception as e:
            logger.error(f"stream producer failed: {e!r}", exc_info=True)
        finally:
            audio_q.put(None)

    worker = threading.Thread(target=_producer, daemon=True)
    worker.start()

    item = audio_q.get()          # waits for Gemini's first sentence + its audio
    if item is None:
        return ""

    spoken_parts = []
    stop_event = threading.Event()
    listener = None
    _interrupt_hit.clear()
    t_speech_start = time.monotonic()
    previous_state = None
    try:
        with _speak_lock:
            set_state(STATE_EXECUTING)
            previous_state = get_state()
            set_state(STATE_SPEAKING)
            hud.speaking_start()
            idx = 0
            while item is not None:
                sentence, path, is_temp = item
                spoken_parts.append(sentence)
                print(f"Assistant: {sentence}")
                logger.info(f"SPEAK: {sentence}")
                if path is not None and not _interrupt_hit.is_set():
                    try:
                        if not pygame.mixer.get_init():
                            pygame.mixer.init()
                        pygame.mixer.music.load(str(path))
                        end_s = _speech_end_seconds(path)
                        cut_ms = int(end_s * 1000) if end_s else None
                        if listener is None and (
                                idx > 0 or not audio_q.empty() or end_s is None
                                or end_s > _INTERRUPT_MIN_SPEECH_SECONDS):
                            listener = threading.Thread(
                                target=_interrupt_listener, args=(stop_event,), daemon=True)
                            listener.start()
                        pygame.mixer.music.play()
                        while pygame.mixer.music.get_busy():
                            if cut_ms is not None and pygame.mixer.music.get_pos() >= cut_ms:
                                pygame.mixer.music.stop()   # skip padded silence
                                break
                            time.sleep(0.02)
                        pygame.mixer.music.unload()
                    except Exception as e:
                        logger.warning(f"stream playback failed for {sentence!r}: {e!r}")
                _drop_clip(path, is_temp)
                idx += 1
                if _interrupt_hit.is_set():
                    cancel.set()
                    break
                item = audio_q.get()
    finally:
        stop_event.set()
        if listener is not None:
            listener.join(timeout=1.0)
        if _interrupt_hit.is_set():
            cancel.set()
        # discard anything synthesized but not played, until the worker ends
        try:
            while True:
                leftover = audio_q.get(timeout=3.0)
                if leftover is None:
                    break
                _drop_clip(leftover[1], leftover[2])
        except queue.Empty:
            pass
        worker.join(timeout=1.0)
        hud.speaking_end()
        _tts_time_accum += time.monotonic() - t_speech_start
        if previous_state is not None:
            set_state(previous_state)
        _last_spoken = " ".join(spoken_parts)
    return _last_spoken


def fuzzy_match_app(spoken_name: str) -> str:
    """Finds the closest matching app name using fuzzy logic."""
    spoken_name = spoken_name.strip().lower()
    
    # Combine built-ins and discovered apps into one list
    all_apps = list(BUILTIN_COMMANDS.keys()) + list(APP_INDEX.keys())
    
    # Find the single best match with at least 70% similarity
    matches = difflib.get_close_matches(spoken_name, all_apps, n=1, cutoff=0.7)
    
    if matches:
        return matches[0]
    return spoken_name


def is_app_known(spoken_name: str) -> bool:
    name = spoken_name.strip().lower()
    name = SPOKEN_APP_CORRECTIONS.get(name, name)
    return name in BUILTIN_COMMANDS or find_app_path(name, APP_INDEX) is not None


def open_app(name: str) -> bool:
    name = fuzzy_match_app(name)

    cmd = BUILTIN_COMMANDS.get(name)

    if not cmd:
        cmd = find_app_path(name, APP_INDEX)

    if not cmd:
        return False

    try:
        subprocess.Popen(cmd, shell=True)
        return True
    except Exception as e:
        print(f"Error launching {name}: {e}")
        return False


def _normalize(name: str) -> str:
    return re.sub(r'[^a-z0-9]', '', name.lower())


def find_running_processes(spoken_name: str):
    target = _normalize(spoken_name)
    if not target:
        return []

    seen = set()
    matches = []
    for proc in psutil.process_iter(['name']):
        try:
            pname = proc.info['name'] or ""
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        if not pname or pname in seen:
            continue
        norm = _normalize(Path(pname).stem)
        if not norm:
            continue
        if target == norm or target in norm or norm in target:
            seen.add(pname)
            matches.append(pname)
    return matches


def _extract_exe_name(cmd: str) -> str:
    match = re.match(r'"([^"]+)"', cmd)
    path_str = match.group(1) if match else cmd.split()[0]
    return Path(path_str).name


def close_app(name: str) -> str:
    name = fuzzy_match_app(name)

    exe_name = PROCESS_NAMES.get(name)

    if not exe_name:
        running = find_running_processes(name)
        if running:
            exe_name = running[0]

    if not exe_name:
        cmd = find_app_path(name, APP_INDEX)
        if cmd:
            exe_name = _extract_exe_name(cmd)

    if not exe_name:
        return f"I don't know how to close {name}."

    try:
        result = subprocess.run(
            ["taskkill", "/IM", exe_name, "/F"],
            capture_output=True, text=True,
        )
    except Exception as e:
        return f"Something went wrong trying to close {name}: {e}"

    if result.returncode == 0:
        return f"Closed {name}."
    else:
        return f"{name} doesn't seem to be running."


def take_screenshot() -> str:
    try:
        img = ImageGrab.grab()
        dest_folder = FOLDERS.get("pictures")
        if not dest_folder or not dest_folder.exists():
            dest_folder = HOME
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = dest_folder / f"screenshot_{timestamp}.png"
        img.save(filepath)

        copied = copy_image_to_clipboard(img)
        if copied:
            return "Screenshot saved and copied."
        return "Screenshot saved, but not copied."
    except Exception as e:
        return f"Something went wrong taking the screenshot: {e}"


from system_control import SHUTDOWN_DELAY_SECONDS


def open_app_tool(app_name: str) -> str:
    if open_app(app_name):
        return f"Opened {app_name}."
    return f"Could not find an app called {app_name} on this machine."


def close_app_tool(app_name: str) -> str:
    return close_app(app_name)


def is_app_installed_tool(app_name: str) -> str:
    if is_app_known(app_name):
        return f"Yes, {app_name} is installed and I can open it."
    return (f"I don't see {app_name} in my index. It might be installed "
            f"under a different name, or say 'rescan apps' if you just "
            f"installed it.")


def app_count_tool() -> str:
    return f"I currently know {len(APP_INDEX) + len(BUILTIN_COMMANDS)} applications on this machine."


def open_folder_tool(folder_name: str) -> str:
    key = resolve_folder_key(folder_name.strip().lower())
    if key in FOLDERS and open_folder(key):
        return f"Opened the {folder_name} folder."
    return f"I don't recognize the folder {folder_name}."


def move_or_copy_file_tool(filename: str, destination_folder: str, move: bool = False) -> str:
    key = resolve_folder_key(destination_folder.strip().lower())
    if key not in FOLDERS:
        return f"I don't recognize the folder {destination_folder}."
    return copy_or_move_file(filename, key, move=move)


def copy_or_move_to_path_tool(filename: str, destination: str, move: bool = False) -> str:
    return file_manager.copy_or_move_to_path_command(filename, destination, move=move)


def find_file_tool(filename: str) -> str:
    return find_command(filename)


def open_file_tool(filename: str) -> str:
    return open_command(filename)


def rename_file_tool(old_name: str, new_name: str) -> str:
    return rename_command(old_name, new_name)


def delete_file_tool(filename: str) -> str:
    return delete_command(filename)


def create_folder_tool(folder_name: str, parent_folder: str = "desktop") -> str:
    return create_folder_command(folder_name, parent_folder)


def delete_folder_tool(folder_name: str) -> str:
    return delete_folder_command(folder_name)


def list_files_tool(folder_name: str) -> str:
    return list_files_command(folder_name)


def search_folder_tool(extension: str, folder_name: str) -> str:
    return search_folder_command(extension, folder_name)


def show_file_location_tool(filename: str) -> str:
    return show_location_command(filename)


def duplicate_file_tool(filename: str) -> str:
    return duplicate_command(filename)


def take_screenshot_tool() -> str:
    return take_screenshot()


def lock_pc_tool() -> str:
    return lock_pc()


def shutdown_pc_tool() -> str:
    return shutdown_pc()


def cancel_shutdown_tool() -> str:
    return cancel_shutdown()


def get_system_performance_tool() -> str:
    return get_performance_summary()


def get_cpu_temperature_tool() -> str:
    return get_temperature_summary()


def play_song_tool(song_name: str) -> str:
    return play_song(song_name)


def restart_pc_tool() -> str:
    return restart_pc()


def sleep_pc_tool() -> str:
    return sleep_pc()


def set_volume_tool(percent: int) -> str:
    return set_volume_percent(percent)


def mute_tool() -> str:
    return set_mute(True)


def unmute_tool() -> str:
    return set_mute(False)


def empty_recycle_bin_tool() -> str:
    return empty_recycle_bin()


def show_desktop_tool() -> str:
    return show_desktop()


def get_battery_tool() -> str:
    return get_battery_status()


def get_storage_tool() -> str:
    return get_storage_summary()


def set_brightness_tool(percent: int) -> str:
    return set_brightness_percent(percent)


def focus_assist_on_tool() -> str:
    return focus_assist_on()


def focus_assist_off_tool() -> str:
    return focus_assist_off()


def get_current_wifi_tool() -> str:
    return get_current_wifi()


def connect_to_wifi_tool(network_name: str) -> str:
    return connect_to_wifi(network_name)


def wifi_radio_on_tool() -> str:
    return set_wifi_radio(True)


def wifi_radio_off_tool() -> str:
    return set_wifi_radio(False)


def bluetooth_on_tool() -> str:
    return set_bluetooth_radio(True)


def bluetooth_off_tool() -> str:
    return set_bluetooth_radio(False)


def night_light_on_tool() -> str:
    return night_light_on()


def night_light_off_tool() -> str:
    return night_light_off()


def remember_name_tool(name: str) -> str:
    name = name.strip().title()
    memory.set_preference("name", name)
    llm_brain.refresh_persona()
    return f"Got it, I'll remember your name is {name}."


def get_name_tool() -> str:
    name = memory.get_preference("name")
    if not name:
        return "I don't know your name yet. You can tell me by saying 'my name is' followed by your name."
    return f"Your name is {name}."


def remember_fact_tool(key: str, value: str) -> str:
    key = key.strip().lower()
    value = value.strip()
    memory.set_preference(key, value)
    llm_brain.refresh_persona()
    return f"Got it, I'll remember your {key} is {value}."


def recall_fact_tool(key: str) -> str:
    key = key.strip().lower()
    value = memory.get_preference(key)
    if not value:
        return f"I don't know your {key} yet."
    return f"Your {key} is {value}."


def add_note_tool(text: str) -> str:
    memory.add_note(text)
    return "Noted."


def list_notes_tool() -> str:
    notes = memory.list_notes(limit=5)
    if not notes:
        return "You don't have any notes saved."
    memory.context.set_last_list(notes, kind="notes")
    spoken = "; ".join(n["text"] for n in notes)
    return f"Your recent notes: {spoken}"


def add_todo_tool(text: str) -> str:
    memory.add_todo(text)
    return f"Added {text} to your to-do list."


def list_todos_tool() -> str:
    todos = memory.list_todos(include_done=False, limit=10)
    if not todos:
        return "Your to-do list is empty."
    memory.context.set_last_list(todos, kind="todos")
    spoken = "; ".join(f"{i+1}. {t['text']}" for i, t in enumerate(todos))
    return f"Here's what's on your list: {spoken}"


def complete_todo_tool(item_description_or_ordinal: str) -> str:
    resolved = memory.context.resolve_ordinal(item_description_or_ordinal)
    if resolved and memory.context.last_list_kind == "todos":
        if memory.complete_todo(resolved["id"]):
            return f"Marked '{resolved['text']}' as done."

    needle = item_description_or_ordinal.strip().lower()
    for todo in memory.list_todos(include_done=False, limit=50):
        if needle in todo["text"].lower():
            memory.complete_todo(todo["id"])
            return f"Marked '{todo['text']}' as done."
    return f"I couldn't find a to-do matching '{item_description_or_ordinal}'."


def add_reminder_tool(text: str, minutes_from_now: int) -> str:
    remind_at = datetime.datetime.now() + datetime.timedelta(minutes=minutes_from_now)
    memory.add_reminder(text, remind_at)
    return f"Reminder set for {minutes_from_now} minutes."


def list_reminders_tool() -> str:
    reminders = memory.list_upcoming_reminders(limit=10)
    if not reminders:
        return "You don't have any reminders set."
    spoken = "; ".join(
        f"{r['text']} at {r['remind_at']}" for r in reminders
    )
    return f"Upcoming reminders: {spoken}"


def _speak_due_reminders():
    for reminder in memory.get_due_reminders():
        speak(f"Reminder: {reminder['text']}")
        memory.mark_reminder_fired(reminder["id"])


_active_timers = {}
_timer_lock = threading.Lock()
_next_timer_id = 1


def _format_duration(seconds: int) -> str:
    seconds = int(round(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    if secs and not hours:
        parts.append(f"{secs} second{'s' if secs != 1 else ''}")
    return " and ".join(parts) if parts else "0 seconds"


def _fire_timer(timer_id: int):
    with _timer_lock:
        info = _active_timers.pop(timer_id, None)
    if info is None:
        return
    label = info["label"]
    if label:
        speak(f"Your {label} timer is done.")
    else:
        speak("Your timer is done.")


def start_timer_tool(duration_seconds: int, label: str = "") -> str:
    global _next_timer_id
    duration_seconds = max(1, int(duration_seconds))
    label = label.strip()

    with _timer_lock:
        timer_id = _next_timer_id
        _next_timer_id += 1
        t = threading.Timer(duration_seconds, _fire_timer, args=(timer_id,))
        t.daemon = True
        _active_timers[timer_id] = {
            "label": label,
            "ends_at": time.time() + duration_seconds,
            "timer": t,
        }
    t.start()

    spoken_duration = _format_duration(duration_seconds)
    if label:
        return f"Timer set for {spoken_duration}: {label}."
    return f"Timer set for {spoken_duration}."


def list_timers_tool() -> str:
    with _timer_lock:
        timers = list(_active_timers.values())
    if not timers:
        return "You don't have any timers running."
    now = time.time()
    parts = []
    for info in timers:
        remaining = _format_duration(max(0, info["ends_at"] - now))
        label = f" ({info['label']})" if info["label"] else ""
        parts.append(f"{remaining} remaining{label}")
    return "Active timers: " + "; ".join(parts)


def cancel_timer_tool(label: str = "") -> str:
    label = label.strip().lower()
    with _timer_lock:
        if not _active_timers:
            return "You don't have any timers running."

        if label:
            match_id = next(
                (tid for tid, info in _active_timers.items()
                 if info["label"].lower() == label),
                None,
            )
            if match_id is None:
                return f"I couldn't find a timer called '{label}'."
        else:
            match_id = max(_active_timers.keys())

        info = _active_timers.pop(match_id)

    info["timer"].cancel()
    return f"Cancelled the {info['label']} timer." if info["label"] else "Timer cancelled."


def call_contact_tool(contact_name: str) -> str:
    contact_name = resolve_contact(contact_name)
    success = call_contact(contact_name)
    if success:
        return f"Calling {contact_name} on WhatsApp."
    return f"I couldn't complete the call to {contact_name} — check the console for details."


def send_whatsapp_message_tool(contact_name: str, message: str) -> str:
    contact_name = resolve_contact((contact_name or "").strip(" ,.:;!?-\"'"))
    logger.info(f"SEND_MESSAGE tool contact={contact_name!r} message={message!r}")
    success = send_message(contact_name, message)
    if success:
        return f"Sent to {contact_name}: {message}"
    return f"I couldn't send that message to {contact_name} — check the console for details."


def get_weather_tool(location: str = "") -> str:
    return get_weather(location)


def ask_about_screen_tool(question: str = "") -> str:
    return handle_screen_request(question)


def copy_screen_text_tool() -> str:
    return copy_screen_text()


def type_text_tool(text: str) -> str:
    return type_text(text)


def toggle_screen_recording_tool() -> str:
    """Starts or stops screen recording of the active window by pressing
    Win+Alt+R (Windows Game Bar). Same key toggles on and off. Needs Game Bar
    enabled in Windows settings and a normal app window focused (not the desktop)."""
    VK_LWIN, VK_MENU, VK_R, KEYUP = 0x5B, 0x12, 0x52, 0x0002
    try:
        for vk in (VK_LWIN, VK_MENU, VK_R):
            ctypes.windll.user32.keybd_event(vk, 0, 0, 0)
        for vk in (VK_R, VK_MENU, VK_LWIN):
            ctypes.windll.user32.keybd_event(vk, 0, KEYUP, 0)
        return "Toggled screen recording."
    except Exception as e:
        return f"I couldn't toggle screen recording: {e}"


def paste_code_tool(code: str, replace_existing: bool = False) -> str:
    """Inserts code into the focused editor by PASTING it (clipboard + Ctrl+V).
    Use this instead of type_text_tool for any code: code editors auto-indent
    and auto-close brackets while typing, which corrupts typed code.
    code: the complete code to insert, with normal indentation.
    replace_existing: True to select everything in the editor first (Ctrl+A)
    and overwrite it; False to insert at the cursor."""
    if not set_clipboard_text(code):
        return "I couldn't put the code on the clipboard."
    time.sleep(0.2)
    if replace_existing:
        press_keys("ctrl a")
        time.sleep(0.2)
    press_keys("ctrl v")
    return "Pasted." + (" Replaced old code." if replace_existing else "")


def press_keys_tool(keys: str) -> str:
    return press_keys(keys)


def read_clipboard_tool() -> str:
    return read_clipboard_summary()


def save_clipboard_tool() -> str:
    return save_clipboard_to_file()


def set_clipboard_tool(text: str) -> str:
    success = set_clipboard_text(text)
    return "Copied." if success else "I couldn't set the clipboard."


def copy_file_to_clipboard_tool(filename: str) -> str:
    path = find_file(filename)
    if path is None:
        return f"I couldn't find a file called {filename}."
    success = copy_file_to_clipboard(path)
    return "Copied." if success else f"I couldn't copy {path.name} to the clipboard."


# HUD: wrap every *_tool plus the direct action helpers used by the local
# dispatcher. Wrapped functions keep their name/signature/docstring, so the
# Gemini tool schema is unchanged. Falls back to the original on any problem.
_HUD_ACTION_NAMES = (
    "open_app", "close_app", "take_screenshot", "play_song", "shutdown_pc",
    "restart_pc", "sleep_pc", "lock_pc", "cancel_shutdown", "set_mute",
    "set_volume_percent", "adjust_volume", "empty_recycle_bin", "show_desktop",
    "get_temperature_summary", "get_performance_summary",
)
_HUD_TARGETS = [n for n, v in list(globals().items())
                if callable(v) and n.endswith("_tool")
                and getattr(v, "__module__", None) == __name__]
_HUD_TARGETS += [n for n in _HUD_ACTION_NAMES if callable(globals().get(n))]
for _n in _HUD_TARGETS:
    try:
        globals()[_n] = hud.wrap_tool(globals()[_n])
    except Exception:
        pass

llm_brain.register_tools([
    open_app_tool,
    close_app_tool,
    is_app_installed_tool,
    app_count_tool,
    call_contact_tool,
    send_whatsapp_message_tool,
    get_weather_tool,
    ask_about_screen_tool,
    copy_screen_text_tool,
    type_text_tool,
    paste_code_tool,
    toggle_screen_recording_tool,
    press_keys_tool,
    read_clipboard_tool,
    save_clipboard_tool,
    set_clipboard_tool,
    copy_file_to_clipboard_tool,
    open_folder_tool,
    move_or_copy_file_tool,
    copy_or_move_to_path_tool,
    find_file_tool,
    open_file_tool,
    rename_file_tool,
    delete_file_tool,
    create_folder_tool,
    delete_folder_tool,
    list_files_tool,
    search_folder_tool,
    show_file_location_tool,
    duplicate_file_tool,
    take_screenshot_tool,
    lock_pc_tool,
    shutdown_pc_tool,
    cancel_shutdown_tool,
    get_system_performance_tool,
    get_cpu_temperature_tool,
    play_song_tool,
    restart_pc_tool,
    sleep_pc_tool,
    set_volume_tool,
    mute_tool,
    unmute_tool,
    empty_recycle_bin_tool,
    show_desktop_tool,
    get_battery_tool,
    get_storage_tool,
    set_brightness_tool,
    focus_assist_on_tool,
    focus_assist_off_tool,
    get_current_wifi_tool,
    connect_to_wifi_tool,
    wifi_radio_on_tool,
    wifi_radio_off_tool,
    bluetooth_on_tool,
    bluetooth_off_tool,
    night_light_on_tool,
    night_light_off_tool,
    add_note_tool,
    list_notes_tool,
    add_todo_tool,
    list_todos_tool,
    complete_todo_tool,
    add_reminder_tool,
    list_reminders_tool,
    start_timer_tool,
    list_timers_tool,
    cancel_timer_tool,
    remember_name_tool,
    get_name_tool,
    remember_fact_tool,
    recall_fact_tool,
] + google_tools.TOOLS)


# Only genuine "what's the time" questions -- NOT any sentence containing the
# word "time" (e.g. "increase your standby time", "time complexity").
_TIME_WORD_RE = re.compile(
    r"\b(?:what(?:'s| is)? (?:the )?(?:current )?time|what time|tell me the time"
    r"|(?:the )?current time|time (?:is it|now))\b(?! complexity)"
)
_COPY_SCREEN_RE = re.compile(
    r"^(?:please )?(?:copy|grab)\b"
    r"(?=.*\b(?:code|text|everything|content)\b)"
    r"(?=.*\b(?:screen|window|page|editor)\b)"
)
# "paste", "paste it", "paste the code", "paste it here" ... -> plain Ctrl+V of whatever
# is on the clipboard. Without this the LLM took "paste the code" as "write the code
# and paste it" and pasted its OWN abridged version over the clipboard.
_PASTE_RE = re.compile(r"^(?:please\s+)?paste\b(?!.*\bmy\b)(?:\W+\w+){0,6}\W*$")
_COPY_ALL_RE = re.compile(r"\b(?:entire|whole|all|full|complete|code)\b")


def _copy_focused_text() -> str:
    """Select-all + copy in the focused window (an editor gives the exact text,
    unlike OCR which scrambles columns, line numbers and menus). Returns a spoken
    reply on success, "" if the clipboard didn't change (caller falls back to OCR)."""
    try:
        sentinel = "\u200b__jarvis_copy_probe__"
        if not set_clipboard_text(sentinel):
            return ""
        press_keys("ctrl a")
        time.sleep(0.15)
        press_keys("ctrl c")
        time.sleep(0.3)
        got = get_clipboard_text() or ""
        if got.strip() and got != sentinel:
            return "Copied."
    except Exception as e:
        logger.warning(f"focused-window copy failed: {e!r}")
    return ""
_VOLUME_SET_RE = re.compile(r"set (?:the )?volume to (\d+)")
_BRIGHTNESS_SET_RE = re.compile(r"set (?:the )?brightness to (\d+)")
_WIFI_CONNECT_RE1 = re.compile(r"connect to wifi (.+)")
_WIFI_CONNECT_RE2 = re.compile(r"connect to (.+) wifi")
_NAME_RE = re.compile(r"(?:my name is|call me) (.+)")
_FACT_RE = re.compile(r"remember (?:that )?my (.+?) is (.+)")
_RECALL_RE = re.compile(r"what(?:'s| is) my (.+?)\??$")
# "what's my battery / CPU usage / storage ..." are system questions, not saved
# facts. Without this, the recall branch below answered "I don't know your
# battery yet" for any phrasing that wasn't an exact match further up.
_SYSTEM_QUERY_WORDS = {
    "battery", "cpu", "ram", "memory", "storage", "disk", "space", "temperature",
    "temp", "performance", "usage", "volume", "brightness", "wifi", "network",
    "time", "date", "day", "charge", "charging",
}


def _is_system_question(key: str) -> bool:
    words = set(re.findall(r"[a-z]+", key.lower()))
    return bool(words & _SYSTEM_QUERY_WORDS) and not _match_pref_keys(key)
_NOTE_RE1 = re.compile(r"(?:take|add|make) a note(?: that)? (.+)")
_NOTE_RE2 = re.compile(r"note that (.+)")
_NOTE_RE3 = re.compile(r"remember that (.+)")
_TODO_RE1 = re.compile(r"add (.+) to my to-?do list")
_TODO_RE2 = re.compile(r"add(?: a)? to-?do(?: item)?(?: that)? (.+)")
_TODO_RE3 = re.compile(r"i need to (.+)")
_COMPLETE_RE1 = re.compile(r"(?:mark|complete|finish) (?:the )?(.+?) (?:as )?(?:done|complete|finished)")
_COMPLETE_RE2 = re.compile(r"i (?:finished|completed|did) (.+)")
_REMINDER_RE = re.compile(r"remind me to (.+?) in (\d+) (minute|minutes|hour|hours)")
_TIMER_UNIT = r"(seconds|second|secs|sec|minutes|minute|mins|min|hours|hour|hrs|hr)"
_TIMER_RE1 = re.compile(r"(?:set|start) (?:a |an )?timer for (\d+)\s*" + _TIMER_UNIT +
                         r"(?: (?:for|called|named) (.+))?")
_TIMER_RE2 = re.compile(r"(?:set|start) (?:a |an )?(\d+)\s*" + _TIMER_UNIT +
                         r" timer(?: (?:for|called|named) (.+))?")


_HUD_MOVE_RE = re.compile(r"\b(?:move|reposition|unlock) (?:the |your )?(?:hud|widget|orb)\b")
# "return back" (or "return the hud back") puts the widget back in its default place
_HUD_RETURN_RE = re.compile(r"\breturn (?:the |your )?(?:(?:hud|widget|orb|animation) )?back\b")
# "hide animation" / "turn off the hud" / "make the hud invisible"
_HUD_HIDE_RE = re.compile(
    r"\b(?:hide|disable|remove|turn off|switch off) (?:the |your )?(?:hud|widget|animation|animations|orb)\b"
    r"|\b(?:hud|widget|animation|animations)\b.{0,12}\b(?:invisible|hidden|off)\b")
_HUD_SHOW_RE = re.compile(r"\b(?:show|unhide|enable|bring back|turn on|switch on) (?:the |your )?(?:hud|widget|animation|animations|orb)\b")
# "switch the HUD to wave", "use the orb animation", "next HUD style" ...
_HUD_VERB_RE = re.compile(r"\b(?:switch|change|set|use|select|show|go)\b")
_HUD_KEYWORD_RE = re.compile(r"\b(?:hud|widget|animation|animations|wave dock)\b")
_HUD_NEXT_RE = re.compile(r"\b(?:next|another|different)\b|\b(?:change|switch) (?:the |your )?(?:hud|widget|animation)\b")
_HUD_THEME_LABEL = {"orb": "orb", "wave": "wave dock"}


def _hud_hide() -> None:
    if hud.current_theme() == "none":
        speak("The animation is already hidden. Say show animation to bring it back.")
    else:
        hud.hide()
        speak("Animation hidden.")


def _try_hud_voice(t: str) -> bool:
    """Voice commands for the HUD itself. Handled here, before _dispatch_command,
    so the command router stays untouched."""
    try:
        tt = t.strip().lower().rstrip("?.! ")
        if _HUD_RETURN_RE.search(tt):
            hud.reset_position()
            speak("Widget reset.")
            return True
        if _HUD_MOVE_RE.search(tt):
            if hud.current_theme() == "none":
                speak("The animation is hidden. Say show animation first, then I can move it.")
            else:
                hud.move_mode()
                speak("Drag me where you want, then let go.")
            return True
        if _HUD_HIDE_RE.search(tt):
            _hud_hide()
            return True
        if _HUD_SHOW_RE.search(tt) and not hud.resolve_theme(tt):
            hud.show()
            speak("Here I am.")
            return True
        if _HUD_KEYWORD_RE.search(tt) and (_HUD_VERB_RE.search(tt) or _HUD_NEXT_RE.search(tt)):
            name = hud.resolve_theme(tt)
            if name == "none":
                _hud_hide()
                return True
            if name:
                hud.set_theme(name)
                speak(f"Switched to the {_HUD_THEME_LABEL.get(name, name)} style.")
                return True
            if _HUD_NEXT_RE.search(tt):
                hud.next_theme()
                speak("Next style.")
                return True
    except Exception as e:
        logger.warning(f"HUD voice command failed: {e!r}")
    return False


def handle_command(text: str, recognition_time: float = None) -> bool:
    global APP_INDEX, _tts_time_accum, _last_command_used_llm
    t = text.lower().strip()
    logger.info(f"COMMAND: {text!r}")
    set_state(STATE_EXECUTING)
    hud.set_state("THINKING")
    hud.heard(text)

    _tts_time_accum = 0.0
    _last_command_used_llm = False
    _dispatch_start = time.monotonic()
    lessons.begin_turn(text)   # is this a correction of the last answer?

    try:
        result = True if _try_hud_voice(t) else _dispatch_command(text, t)
        memory.log_command(text, _last_spoken)
        lessons.end_turn(text, _last_spoken)   # save the lesson, remember this turn
        memory.context.remember_turn(text, _last_spoken)

        total_dispatch_time = time.monotonic() - _dispatch_start
        dispatch_or_llm_time = total_dispatch_time - _tts_time_accum
        recognition = recognition_time or 0.0
        logger.info(
            "COMMAND_TIMING recognition=%.2fs %s=%.2fs tts=%.2fs total=%.2fs",
            recognition,
            "gemini" if _last_command_used_llm else "dispatch_exec",
            dispatch_or_llm_time,
            _tts_time_accum,
            recognition + total_dispatch_time,
        )
        _hud_command_done()
        return result
    except Exception as e:
        set_state(STATE_ERROR)
        logger.error(f"handle_command crashed on {text!r}: {e!r}", exc_info=True)
        print(f"[ERROR] {type(e).__name__}: {e}")  # shows the real cause in the console
        import traceback; traceback.print_exc()
        speak("Something went wrong running that. I've logged it and I'm still here.")
        set_state(STATE_EXECUTING)
        return True


# ---------------------------------------------------------------------
# "type my <thing>" -- fuzzy lookup of saved preferences
# ---------------------------------------------------------------------
# Speech recognition often mishears the words ("mail ID" -> "mail lady",
# "type" -> "take"), so we compare word-by-word after fixing the usual
# mishearings, instead of comparing whole strings.
_KEY_WORD_FIXES = {
    "lady": "id", "idea": "id", "eid": "id", "i": "id", "d": "id",
    "address": "id", "male": "mail", "email": "mail", "emails": "mail",
    "e-mail": "mail", "mails": "mail", "mel": "mail",
    "phone": "mobile", "cell": "mobile",
}
_KEY_STOPWORDS = {"the", "my", "your", "a", "of"}


def _key_tokens(s: str) -> set:
    s = re.sub(r"\be[\s-]mail\b", "mail", s.lower())
    words = re.findall(r"[a-z0-9]+", s)
    return {_KEY_WORD_FIXES.get(w, w) for w in words if w not in _KEY_STOPWORDS}


def _match_pref_keys(spoken_key: str) -> list:
    """Returns the saved preference key(s) that best match what was said.
    [] = no match, 1 item = confident match, 2+ = ambiguous (e.g. you have
    both 'personal mail id' and 'college mail id' and said just 'mail id')."""
    spoken = _key_tokens(spoken_key)
    if not spoken:
        return []
    scored = []
    seen = {}  # keys that mean the same thing ("college mail id" / "college email id")
    for key in memory.get_all_keys():
        kt = _key_tokens(key)
        if not kt:
            continue
        if memory.get_preference(key) in seen.get(frozenset(kt), []):
            continue  # exact duplicate (same meaning, same value) -- skip
        seen.setdefault(frozenset(kt), []).append(memory.get_preference(key))
        cover = len(spoken & kt) / len(spoken)      # how much of what I said is in the key
        ratio = difflib.SequenceMatcher(
            None, " ".join(sorted(spoken)), " ".join(sorted(kt))
        ).ratio()
        score = 0.6 * cover + 0.4 * ratio
        if cover >= 0.5 and score >= 0.6:
            scored.append((score, key))
    if not scored:
        return []
    scored.sort(reverse=True)
    best = scored[0][0]
    return [k for sc, k in scored if best - sc <= 0.05]


def _dispatch_command(text: str, t: str) -> bool:
    global APP_INDEX

    # A drafted email is waiting for "send it" / "cancel" -- see google_tools.py
    _mail_reply = google_tools.handle_pending_email(t)
    if _mail_reply:
        speak(_mail_reply)
        return True

    # "change brain", "switch brain to groq", "which brain" -- see brain_switch.py
    _brain_reply = brain_switch.handle_brain_command(t)
    if _brain_reply:
        speak(_brain_reply)
        return True

    # Mic often hears "type my ..." as "take my ..." -- repair it, but only
    # when what follows really is one of the saved keys, so a genuine
    # "take ..." command is never hijacked.
    _m = re.match(r"^(?:take|tape|tight|tyre)\s+(my\s+.+)$", t.strip().rstrip(".,!?"))
    if _m and _match_pref_keys(_m.group(1)[3:].strip()):
        t = "type " + _m.group(1)

    if file_manager.has_pending():
        pending_result = file_manager.resolve_pending(text)
        if pending_result is not None:
            speak(pending_result)
            return True

    # "copy the entire code from my screen" -> OCR the screen to the clipboard.
    # Must run BEFORE command_router, which was catching "copy ..." phrases
    # (and copying the spoken words) before this check was ever reached.
    if _COPY_SCREEN_RE.search(t):
        logger.info("ROUTE copy_screen_text (matched _COPY_SCREEN_RE)")
        reply = _copy_focused_text() if _COPY_ALL_RE.search(t) else ""
        speak(reply or copy_screen_text())
        return True

    if _PASTE_RE.match(t):
        logger.info("ROUTE paste (Ctrl+V)")
        press_keys("ctrl v")
        speak("Pasted.")
        return True

    if command_router.dispatch(t, speak):
        return True

    if t in ("how many apps do you know", "how many apps can you open",
              "how many apps do you have"):
        speak(app_count_tool())
        return True

    is_installed_match = re.match(
        r"(?:is|do you have|do i have) (.+?)(?: installed)?\??$", t
    )
    if is_installed_match and ("install" in t or t.startswith("do you have")
                                or t.startswith("do i have")):
        speak(is_app_installed_tool(is_installed_match.group(1).strip()))
        return True

    if t in ("rescan apps", "update apps", "reindex apps"):
        speak("Rescanning installed apps, one moment...")
        APP_INDEX = build_app_index()
        speak(f"Done. I found {len(APP_INDEX)} apps.")
        return True

    if "temperature" in t or "how hot" in t or t in ("check heat", "check temp"):
        speak(get_temperature_summary())
        return True

    if "performance" in t or "system status" in t or t in ("how's my pc", "how is my pc"):
        speak(get_performance_summary())
        return True

    if t in ("screenshot", "take a screenshot", "take screenshot"):
        speak(take_screenshot())
        return True

    if t in ("cancel shutdown", "stop shutdown", "abort shutdown"):
        speak(cancel_shutdown())
        return True

    if t in ("shutdown", "shut down", "shut down the pc", "shut down my pc",
              "turn off the pc", "turn off my pc", "shutdown the pc", "shutdown my pc"):
        speak(shutdown_pc())
        return True

    # Whole-word, command-shaped match only -- a bare substring test locked the
    # PC on "...the hands of a c-lock-k" (the word "clock").
    if re.fullmatch(
            r"(?:please\s+)?lock(?:\s+(?:it|(?:the\s+|my\s+|this\s+)?"
            r"(?:pc|computer|laptop|screen|system|windows)))?(?:\s+(?:now|please))?",
            t.strip(" .,!?")):
        speak(lock_pc())
        return True

    if t in ("restart", "restart the pc", "restart my pc", "reboot", "reboot the pc"):
        speak(restart_pc())
        return True

    if t in ("sleep", "go to sleep", "put the pc to sleep", "sleep mode"):
        speak(sleep_pc())
        return True

    if t in ("mute", "mute volume", "mute the volume"):
        speak(set_mute(True))
        return True

    if t in ("unmute", "unmute volume", "unmute the volume"):
        speak(set_mute(False))
        return True

    volume_set_match = _VOLUME_SET_RE.match(t)
    if volume_set_match:
        speak(set_volume_percent(int(volume_set_match.group(1))))
        return True

    if t in ("volume up", "increase volume", "turn up the volume", "louder"):
        speak(adjust_volume(10))
        return True

    if t in ("volume down", "decrease volume", "turn down the volume", "quieter"):
        speak(adjust_volume(-10))
        return True

    if t in ("empty the recycle bin", "empty recycle bin", "clear the recycle bin"):
        speak(empty_recycle_bin())
        return True

    if t in ("show desktop", "minimize everything", "minimize all windows"):
        speak(show_desktop())
        return True

    if t in ("what's my battery", "what is my battery", "battery status", "how much battery"):
        speak(get_battery_status())
        return True

    if t in ("how much storage do i have", "storage status", "disk space", "how much space do i have"):
        speak(get_storage_summary())
        return True

    brightness_set_match = _BRIGHTNESS_SET_RE.match(t)
    if brightness_set_match:
        speak(set_brightness_percent(int(brightness_set_match.group(1))))
        return True

    if t in ("brightness up", "increase brightness", "turn up the brightness", "brighter"):
        speak(adjust_brightness(10))
        return True

    if t in ("brightness down", "decrease brightness", "turn down the brightness", "dimmer"):
        speak(adjust_brightness(-10))
        return True

    if t in ("turn on do not disturb", "enable do not disturb",
              "turn on focus assist", "enable focus assist"):
        speak(focus_assist_on())
        return True

    if t in ("turn off do not disturb", "disable do not disturb",
              "turn off focus assist", "disable focus assist"):
        speak(focus_assist_off())
        return True

    if t in ("what network am i on", "what wifi am i on", "what's my wifi",
              "current wifi", "current network"):
        speak(get_current_wifi())
        return True

    wifi_connect_match = _WIFI_CONNECT_RE1.match(t) or _WIFI_CONNECT_RE2.match(t)
    if wifi_connect_match:
        speak(connect_to_wifi(wifi_connect_match.group(1).strip()))
        return True

    if t in ("turn on wifi", "turn wifi on", "enable wifi", "wifi on"):
        speak(set_wifi_radio(True))
        return True

    if t in ("turn off wifi", "turn wifi off", "disable wifi", "wifi off"):
        speak(set_wifi_radio(False))
        return True

    if t in ("turn on bluetooth", "turn bluetooth on", "enable bluetooth", "bluetooth on"):
        speak(set_bluetooth_radio(True))
        return True

    if t in ("turn off bluetooth", "turn bluetooth off", "disable bluetooth", "bluetooth off"):
        speak(set_bluetooth_radio(False))
        return True

    if t in ("turn on night light", "turn night light on", "enable night light", "night light on"):
        speak(night_light_on())
        return True

    if t in ("turn off night light", "turn night light off", "disable night light", "night light off"):
        speak(night_light_off())
        return True

    # "type <text>" -- types into whatever window currently has focus
    _TYPE_META_PHRASES = (
        "it", "it again", "that", "that again", "this", "this again",
        "again", "the code", "the code again", "it once more",
    )
    # "type the java code again", "type the solution once more" etc. are requests
    # for Jarvis to WRITE code (handled by the LLM + screen tools), not literal
    # text to type -- so don't type those words into the window.
    _TYPE_META_RE = re.compile(
        r"^(?:(?:the|that|this|my|your|a)\s+)?"
        r"(?:(?:java|python|c\+\+|c|javascript|full|whole|complete|correct|same|final|solution)\s+)*"
        r"(?:code|solution|answer|program|function|it|that|this)"
        r"(?:\s+(?:for|to)\s+(?:this|that|it|the\s+\w+))?"
        r"(?:\s+(?:again|once again|once more|now|please))?$"
    )
    # Longer requests like "type the entire java code for the question displayed
    # in my screen" -- mentions code/solution AND something on screen/problem.
    _TYPE_CODE_REQUEST_RE = re.compile(
        r"(?=.*\b(?:code|solution|answer|program|function)\b)"
        r"(?=.*\b(?:screen|question|problem|displayed|editor|leetcode|entire|whole|full|complete|remaining|again)\b)"
    )
    _type_rest = t[len("type "):].strip().rstrip(".,!?").strip() if t.startswith("type ") else ""
    if (t.startswith("type ") and _type_rest not in _TYPE_META_PHRASES
            and not _TYPE_META_RE.match(_type_rest)
            and not _TYPE_CODE_REQUEST_RE.search(_type_rest)):
        raw_target = t[len("type "):].strip()
        text_to_type = raw_target.lower().rstrip(".,!?")
        if not text_to_type:
            speak("Type what?")
            return True
        
        if text_to_type.startswith("my "):
            spoken_key = text_to_type[3:].strip()
            matches = _match_pref_keys(spoken_key)

            if len(matches) == 1:
                resolved = memory.get_preference(matches[0])
                if resolved:
                    type_text(resolved)
                    speak("Typed.")
                else:
                    speak(f"I found {matches[0]} but it's empty.")
            elif len(matches) > 1:
                speak("Which one: " + ", or ".join(matches[:3]) + "?")
            else:
                # Never type the literal words "my mail id" into someone's window.
                speak(f"I couldn't find anything saved as {spoken_key}.")
        else:
            speak(type_text(raw_target))
        return True

    # Common key-press shortcuts
    _QUICK_KEY_PHRASES = {
        "copy that": "ctrl c", "copy": "ctrl c",
        "paste that": "ctrl v", "paste": "ctrl v",
        "select all": "ctrl a",
        "undo that": "ctrl z", "undo": "ctrl z",
        "redo that": "ctrl y", "redo": "ctrl y",
        "switch window": "alt tab", "switch app": "alt tab", "switch apps": "alt tab",
        "press enter": "enter", "hit enter": "enter",
        "press escape": "esc", "press escape key": "esc",
    }
    if t in _QUICK_KEY_PHRASES:
        speak(press_keys(_QUICK_KEY_PHRASES[t]))
        return True

    if t.startswith("press "):
        keys_spoken = t[len("press "):].strip()
        if not keys_spoken:
            speak("Press what?")
            return True
        speak(press_keys(keys_spoken))
        return True

    if t.startswith("call "):
        contact_name = t[len("call "):].strip()
        if not contact_name:
            speak("Call who?")
            return True
        contact_name = resolve_contact(contact_name)
        speak(f"Calling {contact_name} on WhatsApp")
        success = call_contact(contact_name)
        if not success:
            speak(f"I couldn't complete the call to {contact_name} — check the console for details.")
        return True

    # Matched against the ORIGINAL text (case-insensitive) so the message
    # keeps the capitalization Whisper gave it, and tolerant of the commas
    # / periods Whisper puts around the name ("...Balaji The Rise, saying
    # hello"). A stray comma left on the name used to make the WhatsApp
    # search find nothing.
    message_match = re.match(
        r"(?:jarvis[\s,]+)?"
        r"(?:send (?:a )?(?:whatsapp )?(?:message|text) to|message|text) "
        r"(.+?)[\s,:;.\-]+(?:saying|that says|and say)[\s,:;]+(.+)$",
        text.strip(), re.IGNORECASE,
    )
    if message_match:
        contact_name, message_text = message_match.groups()
        contact_name = contact_name.strip(" ,.:;!?-\"'")
        message_text = message_text.strip()
        contact_name = resolve_contact(contact_name)
        logger.info(f"SEND_MESSAGE parsed contact={contact_name!r} message={message_text!r}")
        speak(f"Sending to {contact_name}")
        success = send_message(contact_name, message_text)
        if not success:
            speak(f"I couldn't send that message to {contact_name} — check the console for details.")
        return True

    if t.startswith("close "):
        app_name = t[len("close "):].strip()
        if not app_name:
            speak("Close what?")
            return True
        speak(close_app(app_name))
        return True

    if t.startswith("open "):
        spoken_folder = t[len("open "):].strip()
        folder_key = resolve_folder_key(spoken_folder)
        if folder_key in FOLDERS:
            if open_folder(folder_key):
                speak(f"Opening {spoken_folder}")
            else:
                speak(f"I couldn't find your {spoken_folder} folder.")
            return True

    if t in ("open file manager", "open files"):
        subprocess.Popen("explorer.exe", shell=True)
        speak("Opening File Explorer")
        return True

    if t.startswith("open "):
        app_name = t[len("open "):].strip()
        if open_app(app_name):
            speak(f"Opening {app_name}")
            return True
        speak(f"I don't know an app called {app_name}. Try 'rescan apps' "
              f"if you just installed it, or say 'open my {app_name}' if "
              f"you meant a file.")
        return True

    if re.search(r"\b(fill|complete)\b.*\bform\b", t):
        import form_filler
        speak(form_filler.start_from_clipboard(speak))
        return True

    if t.startswith("play "):
        song_name = t[len("play "):].strip()
        speak(play_song(song_name))
        return True

    if ((t.startswith("search for ") or t.startswith("search "))
            and not re.search(r"\b(e-?mails?|mails?|gmail|inbox)\b", t)):   # "search my email ..." -> email tool
        query = t.replace("search for ", "").replace("search ", "", 1)
        query = correct_text(query)
        webbrowser.open(f"https://www.google.com/search?q={query}")
        speak(f"Searching for {query}")
        return True

    if _TIME_WORD_RE.search(t) and "date" not in t:
        now = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"It is {now}")
        return True

    if "what's the date" in t or "what is the date" in t or "today's date" in t:
        today = datetime.datetime.now().strftime("%A, %B %d, %Y")
        speak(f"Today is {today}")
        return True

    name_match = _NAME_RE.match(t)
    if name_match:
        speak(remember_name_tool(name_match.group(1).strip()))
        return True

    fact_match = _FACT_RE.match(t)
    if fact_match:
        key, value = fact_match.groups()
        key = key.strip().lower()
        if key == "name":
            speak(remember_name_tool(value.strip()))
        else:
            speak(remember_fact_tool(key, value))
        return True

    recall_match = _RECALL_RE.match(t)
    if recall_match and not _is_system_question(recall_match.group(1)):
        key = recall_match.group(1).strip().lower()
        if key == "name":
            speak(get_name_tool())
        else:
            speak(recall_fact_tool(key))
        return True

    if t == "do you know my name":
        speak(get_name_tool())
        return True

    note_match = (_NOTE_RE1.match(t)
                  or _NOTE_RE2.match(t)
                  or _NOTE_RE3.match(t))
    if note_match:
        speak(add_note_tool(note_match.group(1).strip()))
        return True

    if t in ("what are my notes", "read my notes", "show my notes", "my notes"):
        speak(list_notes_tool())
        return True

    todo_match = (_TODO_RE1.match(t)
                  or _TODO_RE2.match(t)
                  or _TODO_RE3.match(t))
    if todo_match:
        speak(add_todo_tool(todo_match.group(1).strip()))
        return True

    if t in ("what's on my to-do list", "what is on my to-do list",
              "show my to-do list", "my to-do list", "show my todos",
              "what are my todos", "read my to-do list"):
        speak(list_todos_tool())
        return True

    complete_match = (_COMPLETE_RE1.match(t)
                       or _COMPLETE_RE2.match(t))
    if complete_match:
        speak(complete_todo_tool(complete_match.group(1).strip()))
        return True

    reminder_match = _REMINDER_RE.match(t)
    if reminder_match:
        task, amount, unit = reminder_match.groups()
        minutes = int(amount) * (60 if unit.startswith("hour") else 1)
        speak(add_reminder_tool(task.strip(), minutes))
        return True

    if t in ("what are my reminders", "show my reminders", "my reminders",
              "what reminders do i have"):
        speak(list_reminders_tool())
        return True

    timer_match = _TIMER_RE1.match(t) or _TIMER_RE2.match(t)
    if timer_match:
        amount, unit, label = timer_match.groups()
        unit = unit.lower()
        if unit.startswith("hour") or unit.startswith("hr"):
            seconds = int(amount) * 3600
        elif unit.startswith("min"):
            seconds = int(amount) * 60
        else:
            seconds = int(amount)
        speak(start_timer_tool(seconds, label or ""))
        return True

    if t in ("what are my timers", "show my timers", "my timers",
              "how much time is left on my timer", "how much time is left",
              "how long left on my timer"):
        speak(list_timers_tool())
        return True

    if t in ("cancel my timer", "cancel the timer", "stop my timer",
              "stop the timer", "cancel timer"):
        speak(cancel_timer_tool())
        return True

    math_reply = try_math_command(t)
    if math_reply is not None:
        speak(math_reply)
        return True

    global _last_command_used_llm
    _last_command_used_llm = True
    set_state(STATE_THINKING)
    if STREAM_REPLIES:
        speak_llm_stream(text)
        return True
    reply = ask_llm(text)
    set_state(STATE_EXECUTING)
    speak(reply)
    return True


EXIT_PHRASES = ("exit", "quit", "goodbye")
STANDBY_PHRASES = ("standby", "stand by", "go to standby", "go standby",
                   "go on standby", "go to stand by", "standing by")
SILENCE_TIMEOUT = 180


def run_active_session(recognizer: sr.Recognizer, mic: sr.Microphone) -> bool:
    last_activity = time.time()
    _speak_due_reminders()

    while True:
        if time.time() - last_activity > SILENCE_TIMEOUT:
            speak("Standing by.")
            set_state(STATE_STANDBY)
            return False

        try:
            set_state(STATE_LISTENING)
            _recognition_start = time.monotonic()
            with _mic_lock:
                with mic as source:
                    print("Listening for command...")
                    try:
                        audio = recognizer.listen(source, timeout=SILENCE_TIMEOUT, phrase_time_limit=6)
                    except sr.WaitTimeoutError:
                        continue

            hud.set_state("THINKING")
            _t_listen_done = time.monotonic()
            try:
                text = transcribe_audio(audio)
                audio_len = len(audio.frame_data) / float(audio.sample_rate * audio.sample_width)
                logger.info(
                    "STT_TIMING listen_incl_waiting=%.2fs audio_len=%.2fs transcribe=%.2fs "
                    "model=%s conf=%s fallback=%s",
                    _t_listen_done - _recognition_start,
                    audio_len,
                    time.monotonic() - _t_listen_done,
                    _last_stt_info["model"],
                    "n/a" if _last_stt_info["conf"] is None else f"{_last_stt_info['conf']:.2f}",
                    _last_stt_info["fallback"],
                )
                if not text:
                    continue
            except sr.RequestError as e:
                logger.warning(f"Speech recognition service error: {e!r}")
                speak("Speech recognition service is unavailable right now.")
                continue
            except Exception as e:
                logger.warning(f"Transcription failed: {e!r}")
                print("(Didn't catch that)")
                continue

            recognition_time = time.monotonic() - _recognition_start

            t = text.lower().strip()
            print(f"You said: {text}")
            logger.info(f"HEARD: {text!r}")

            if t in EXIT_PHRASES:
                speak("Goodbye!")
                return True

            if t.strip(" .,!?") in STANDBY_PHRASES:
                logger.info("STANDBY requested by voice.")
                speak("Standing by.")
                set_state(STATE_STANDBY)
                return False

            handle_command(text, recognition_time=recognition_time)
            last_activity = time.time()

        except Exception as e:
            set_state(STATE_ERROR)
            logger.error(f"run_active_session crashed: {e!r}", exc_info=True)
            speak("I hit a snag listening just now. Still here though.")
            set_state(STATE_LISTENING)


def run_standby(recognizer: sr.Recognizer, mic: sr.Microphone) -> bool:
    print(f"Waiting for '{WAKE_WORD}'...")
    set_state(STATE_STANDBY)
    try:
        result = listen_for_wake_word(recognizer, mic)
    except Exception as e:
        set_state(STATE_ERROR)
        logger.error(f"run_standby crashed listening for wake word: {e!r}", exc_info=True)
        time.sleep(1)
        set_state(STATE_STANDBY)
        return None

    if result is None:
        return None

    if result:
        logger.info(f"WAKE (with command): {result!r}")
        if result in EXIT_PHRASES:
            speak("Goodbye!")
            return False
        if result.lower().strip(" .,!?") in STANDBY_PHRASES:
            return None   # already on standby
        handle_command(result)
        return True

    logger.info("WAKE")
    hud.set_state("LISTENING")
    speak("Yes?")
    return True


def _end_key_watcher():
    """Global kill switch: pressing Ctrl+Shift+End anywhere closes Jarvis.

    Works even though Jarvis runs hidden (pythonw), uses only ctypes, and
    exits hard with os._exit so a stuck mic/TTS/HUD thread can't keep it alive.
    """
    if os.name != "nt":
        return
    VK_SHIFT, VK_CONTROL, VK_END = 0x10, 0x11, 0x23

    def _combo_down():
        k = user32.GetAsyncKeyState
        return all(k(vk) & 0x8000 for vk in (VK_CONTROL, VK_SHIFT, VK_END))

    try:
        user32 = ctypes.windll.user32
        # If the combo is already held when Jarvis starts, wait for release first.
        was_down = _combo_down()
    except Exception:
        return
    while True:
        try:
            down = _combo_down()
            if down and not was_down:
                try:
                    from keyboard_control import end_key_guard_active
                    own_press = end_key_guard_active()   # Jarvis pressed End itself
                except Exception:
                    own_press = False
                if not own_press:
                    logger.info("End key pressed - shutting down Jarvis.")
                    os._exit(0)
            was_down = down
        except Exception:
            pass
        time.sleep(0.05)


_SCREEN_ANSWER_COMMAND = "answer the question on my screen"
_screen_answer_busy = threading.Event()


SCREEN_ANSWER_SECONDS = None   # None = banner stays until next answer (right-click to close); 2.5 = auto-hide after 2.5 s


def _hud_settle_after_hotkey(prev_state: str):
    """After a Ctrl+Alt+S solve, put the HUD back on the REAL resting state.

    Why: handle_command() pushes "THINKING" straight to the HUD, and the
    hotkey thread has no listening loop above it to reset it afterwards
    (the voice path does: run_active_session sets LISTENING at the top of
    each loop). The old code only reset the HUD when the previous state was
    STANDBY, so after a hotkey solve during an active session it stayed on
    THINKING. Done twice: right now, and again ~1.5 s later in case the HUD's
    own 'success' animation restores its old state afterwards."""
    def _target():
        cur = get_state()
        if cur in (STATE_STANDBY, STATE_LISTENING):
            return cur                      # main loop already moved on; trust it
        if prev_state in (STATE_STANDBY, STATE_LISTENING):
            return prev_state
        return STATE_STANDBY

    set_state(_target())

    def _again():
        try:
            cur = get_state()
            if cur in (STATE_STANDBY, STATE_LISTENING):   # idle only; never mid-command
                _hud_mirror(cur)
        except Exception:
            pass
    t = threading.Timer(1.5, _again)
    t.daemon = True
    t.start()


def _run_screen_answer():
    """Runs "answer the question on my screen" through the normal pipeline,
    but text-only (same trick as typed_command): the reply is shown in a
    popup for SCREEN_ANSWER_SECONDS instead of being spoken."""
    prev_state = get_state()
    _typed_tls.buf = []               # speak() collects the reply instead of voicing it
    answer = ""
    try:
        handle_command(_SCREEN_ANSWER_COMMAND)
        answer = " ".join(_typed_tls.buf).strip()
    except Exception as e:
        logger.error(f"Screen-answer hotkey failed: {e!r}", exc_info=True)
    finally:
        _typed_tls.buf = None
        _screen_answer_busy.clear()
        _hud_settle_after_hotkey(prev_state)   # never leave the HUD on THINKING
    if answer:
        try:
            import answer_popup
            answer_popup.show(answer, SCREEN_ANSWER_SECONDS)
        except Exception as e:
            logger.error(f"Answer popup failed: {e!r}", exc_info=True)


def _screen_answer_key_watcher():
    """Global hotkey: Ctrl+Alt+S = say "answer the question on my screen".
    Same ctypes polling approach as _end_key_watcher (no extra packages,
    no admin rights, works under pythonw)."""
    if os.name != "nt":
        return
    VK_CONTROL, VK_MENU, VK_S = 0x11, 0x12, 0x53   # MENU = Alt

    try:
        user32 = ctypes.windll.user32

        def _combo_down():
            k = user32.GetAsyncKeyState
            return all(k(vk) & 0x8000 for vk in (VK_CONTROL, VK_MENU, VK_S))

        was_down = _combo_down()
    except Exception:
        return
    while True:
        try:
            down = _combo_down()
            if down and not was_down and not _screen_answer_busy.is_set():
                _screen_answer_busy.set()
                logger.info("HOTKEY Ctrl+Alt+S -> answer the question on my screen")
                threading.Thread(target=_run_screen_answer, daemon=True).start()
            was_down = down
        except Exception:
            pass
        time.sleep(0.05)


_shutdown_started = threading.Event()


def shutdown_jarvis(reason: str = "exit"):
    """Clean, one-shot shutdown: timers, audio, HUD, type box, logs, then exit.
    A watchdog hard-exits after 3s if any step hangs."""
    if _shutdown_started.is_set():
        return
    _shutdown_started.set()
    logger.info(f"Shutting down Jarvis ({reason}).")

    def _watchdog():
        time.sleep(3)
        os._exit(0)
    threading.Thread(target=_watchdog, daemon=True).start()

    try:                                    # pending timers
        with _timer_lock:
            for info in list(_active_timers.values()):
                try:
                    info["timer"].cancel()
                except Exception:
                    pass
            _active_timers.clear()
    except Exception:
        pass
    try:                                    # audio
        import pygame
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
            pygame.mixer.quit()
    except Exception:
        pass
    try:                                    # type box
        import jarvis_typer
        jarvis_typer.stop()
    except Exception:
        pass
    try:                                    # HUD
        hud.stop()
    except Exception:
        pass
    try:                                    # flush log handlers
        logging.shutdown()
    except Exception:
        pass
    os._exit(0)                             # main thread may be blocked on the mic


def typed_command(text: str):
    """Run a typed command through the normal pipeline, replies as text only."""
    global _typed_reply_text
    prev_state = get_state()
    _typed_tls.buf = []
    try:
        t = text.lower().strip().rstrip(" .,!?")
        if t in EXIT_PHRASES:
            _typed_tls.buf.append("Goodbye!")
            _typed_reply_text = "Goodbye!"
            t_ = threading.Timer(0.8, shutdown_jarvis, args=("typed exit",))
            t_.daemon = True
            t_.start()
            return
        handle_command(text)
        _typed_reply_text = " ".join(_typed_tls.buf).strip() or "Done."
    except Exception as e:
        logger.error(f"typed_command failed: {e!r}", exc_info=True)
        _typed_reply_text = "Something went wrong. Check the log."
    finally:
        _typed_tls.buf = None
        if prev_state == STATE_STANDBY:
            set_state(STATE_STANDBY)    # don't leave the HUD on 'executing'


def _get_typed_reply() -> str:
    return _typed_reply_text


def main():
    global _shared_mic
    threading.Thread(target=_end_key_watcher, daemon=True).start()
    threading.Thread(target=_screen_answer_key_watcher, daemon=True).start()   # Ctrl+Alt+S
    recognizer = sr.Recognizer()
    
    # 1. Add this line to make the main listener faster
    recognizer.pause_threshold = 0.8 
    
    mic = sr.Microphone(sample_rate=16000)   # Whisper works at 16 kHz: no resampling needed
    _shared_mic = mic

    # Mic trigger level follows ambient noise x this ratio (library default 1.5).
    # If the log shows many STT_TIMING lines with no HEARD (background sound keeps
    # opening 6-second recordings), set MIC_ENERGY_RATIO=2.0 in .env.
    try:
        recognizer.dynamic_energy_ratio = float(os.environ.get("MIC_ENERGY_RATIO", "1.5"))
    except ValueError:
        pass

    with mic as source:
        print("Calibrating microphone for ambient noise...")
        recognizer.adjust_for_ambient_noise(source, duration=1)

    try:
        signal_progress(75)      # mic calibrated
    except Exception:
        pass

    _interrupt_recognizer.energy_threshold = recognizer.energy_threshold
    _interrupt_recognizer.dynamic_energy_threshold = recognizer.dynamic_energy_threshold
    
    # 2. Add this line to make the interruption listener faster
    # Stop words are short, so the stop-word listener doesn't need a long
    # end-of-phrase wait. With 0.8 it lingered 0.2-1.0s after EVERY reply
    # (log: COMMAND_TIMING tts minus TTS_TIMING total), delaying the next
    # listen. non_speaking_duration must stay <= pause_threshold.
    _interrupt_recognizer.pause_threshold = 0.4
    _interrupt_recognizer.non_speaking_duration = 0.3

    hud.start()  # optional; if it fails Jarvis continues without it
    try:
        import jarvis_typer
        jarvis_typer.start(typed_command, _get_typed_reply)   # Ctrl+Alt+J
    except Exception as e:
        logger.warning(f"Type box unavailable: {e!r}")
    threading.Thread(target=_prewarm_tts_cache, daemon=True).start()
    threading.Thread(target=google_tools.warm_up, daemon=True).start()
    threading.Thread(target=_load_whisper_fallback, daemon=True).start()

    try:
        signal_progress(90)      # HUD + background threads started
    except Exception:
        pass

    logger.info("=" * 40)
    logger.info("Jarvis starting up.")

    # --- tell the splash animation that startup is finished (-> 100%, "Ready") ---
    try:
        from jarvis_splash import signal_ready
        signal_ready()
    except Exception:
        pass

    # Spoken text is hardcoded here so the TTS pronounces it right. Edit the
    # respelling below if "Kishore" still sounds off (e.g. "Kishor", "Key-shore").
    _SPOKEN_NAME = {"kishore": "Keeshore"}
    known_name = memory.get_preference("name")
    if known_name:
        spoken_name = _SPOKEN_NAME.get(known_name.strip().lower(), known_name)
        speak(f"Voice assistant ready, {spoken_name}. Say hey Jarvis to activate.")
    else:
        speak("Voice assistant ready. Say hey Jarvis to activate.")

    while True:
        entered_active = run_standby(recognizer, mic)

        if entered_active is None:
            continue

        if entered_active is False:
            break

        should_exit = run_active_session(recognizer, mic)
        if should_exit:
            break

    shutdown_jarvis("voice exit")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
        logger.info("Jarvis stopped by KeyboardInterrupt.")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"Jarvis crashed at the top level: {e!r}", exc_info=True)
        raise