"""
system_control.py -- Windows system-level controls for Jarvis: power
(shutdown/restart/sleep/lock), volume, brightness, recycle bin, show
desktop, battery, storage, Focus Assist, Wi-Fi (read/connect/radio
on-off), Bluetooth, and Night Light.

Deliberately has NO dependency on jarvis_up.py or any other Jarvis
module -- every function here is self-contained and returns a plain,
spoken-friendly string describing what happened. jarvis_up.py imports
whatever it needs from here and is responsible for actually speaking
the result and deciding which spoken phrases route to which function.

Requires (only for volume/brightness -- everything else works with
libraries the main project already needs):
    pip install pycaw comtypes screen-brightness-control
"""

import ctypes
import subprocess
import winreg
import psutil

# Optional libraries for volume/brightness control. Wrapped so the rest
# of this module still works even before these are installed -- the
# related functions just return a clear "install this" message instead
# of crashing at import time.
try:
    from ctypes import POINTER, cast
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    _VOLUME_AVAILABLE = True
except Exception:
    _VOLUME_AVAILABLE = False

try:
    import screen_brightness_control as sbc
    _BRIGHTNESS_AVAILABLE = True
except Exception:
    _BRIGHTNESS_AVAILABLE = False


# ---------------------------------------------------------------------
# Power: shutdown, restart, sleep, lock
# ---------------------------------------------------------------------

# Seconds of delay before an actual shutdown/restart -- gives a window to
# say "cancel shutdown" in case this was triggered by a misheard command.
SHUTDOWN_DELAY_SECONDS = 10


def shutdown_pc() -> str:
    """Schedules a PC shutdown after SHUTDOWN_DELAY_SECONDS, using
    Windows' own shutdown.exe (Windows shows its own countdown notice
    too). Returns a spoken-friendly result message."""
    try:
        subprocess.run(["shutdown", "/s", "/t", str(SHUTDOWN_DELAY_SECONDS)], check=True)
        return (f"Shutting down in {SHUTDOWN_DELAY_SECONDS} seconds. "
                f"Say cancel shutdown to stop it.")
    except Exception as e:
        return f"Something went wrong trying to shut down: {e}"


def cancel_shutdown() -> str:
    """Cancels a pending shutdown/restart scheduled by shutdown_pc() or
    restart_pc(). Returns a spoken-friendly result message."""
    try:
        result = subprocess.run(["shutdown", "/a"], capture_output=True, text=True)
    except Exception as e:
        return f"Something went wrong trying to cancel the shutdown: {e}"
    if result.returncode == 0:
        return "Shutdown cancelled."
    return "There doesn't seem to be a shutdown pending."


def restart_pc() -> str:
    """Schedules a PC restart after SHUTDOWN_DELAY_SECONDS, using the
    same cancellable pattern as shutdown_pc() (cancel_shutdown() works
    for a pending restart too -- Windows' shutdown.exe treats them the
    same way under the hood)."""
    try:
        subprocess.run(["shutdown", "/r", "/t", str(SHUTDOWN_DELAY_SECONDS)], check=True)
        return (f"Restarting in {SHUTDOWN_DELAY_SECONDS} seconds. "
                f"Say cancel shutdown to stop it.")
    except Exception as e:
        return f"Something went wrong trying to restart: {e}"


def sleep_pc() -> str:
    """Puts the PC into sleep (low-power) mode immediately. Unlike
    shutdown/restart, sleep has no cancellable delay -- it's near-
    instant and trivially undone by waking the PC back up, so a
    countdown isn't needed here."""
    try:
        subprocess.run(
            ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
            check=True,
        )
        return "Going to sleep."
    except Exception as e:
        return f"Something went wrong trying to sleep: {e}"


def lock_pc() -> str:
    """Locks the PC screen immediately. Pulled out into its own function
    (previously this was duplicated inline in two places in jarvis_up.py)
    so there's exactly one implementation to maintain."""
    try:
        ctypes.windll.user32.LockWorkStation()
        return "Locked the PC."
    except Exception as e:
        return f"Something went wrong locking the PC: {e}"


# ---------------------------------------------------------------------
# Volume control -- requires: pip install pycaw comtypes
# ---------------------------------------------------------------------
def _get_volume_interface():
    """Returns the Windows master volume control interface, or None if
    pycaw isn't installed. pycaw changed its API across versions --
    older releases require calling .Activate() on the raw COM device,
    newer releases expose a ready-made .EndpointVolume property
    instead. This checks for the new one first and falls back to the
    old style, so it works regardless of which version got installed."""
    if not _VOLUME_AVAILABLE:
        return None
    device = AudioUtilities.GetSpeakers()
    if hasattr(device, "EndpointVolume"):
        return device.EndpointVolume  # newer pycaw
    interface = device.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)  # older pycaw
    return cast(interface, POINTER(IAudioEndpointVolume))


def set_volume_percent(pct: int) -> str:
    """Sets system volume to an exact 0-100 percentage."""
    volume = _get_volume_interface()
    if volume is None:
        return "Volume control needs an extra library -- run: pip install pycaw comtypes"
    pct = max(0, min(100, pct))
    volume.SetMasterVolumeLevelScalar(pct / 100, None)
    return f"Volume set to {pct} percent."


def adjust_volume(step: int) -> str:
    """Nudges volume up or down by `step` percentage points (negative
    to lower)."""
    volume = _get_volume_interface()
    if volume is None:
        return "Volume control needs an extra library -- run: pip install pycaw comtypes"
    current = round(volume.GetMasterVolumeLevelScalar() * 100)
    new_level = max(0, min(100, current + step))
    volume.SetMasterVolumeLevelScalar(new_level / 100, None)
    return f"Volume {'up' if step > 0 else 'down'} to {new_level} percent."


def set_mute(muted: bool) -> str:
    """Mutes or unmutes system audio."""
    volume = _get_volume_interface()
    if volume is None:
        return "Volume control needs an extra library -- run: pip install pycaw comtypes"
    volume.SetMute(1 if muted else 0, None)
    return "Muted." if muted else "Unmuted."


# ---------------------------------------------------------------------
# Recycle bin, show desktop, battery, storage -- all built on top of
# ctypes/psutil, which the project already depends on, so no new
# libraries needed for these.
# ---------------------------------------------------------------------
def empty_recycle_bin() -> str:
    """Empties the Windows Recycle Bin, skipping the confirmation
    dialog and sound. Only affects files already in the recycle bin --
    doesn't touch anything else."""
    SHERB_NOCONFIRMATION = 0x00000001
    SHERB_NOPROGRESSUI = 0x00000002
    SHERB_NOSOUND = 0x00000004
    try:
        ctypes.windll.shell32.SHEmptyRecycleBinW(
            None, None,
            SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND,
        )
        return "Recycle bin emptied."
    except Exception as e:
        return f"Something went wrong emptying the recycle bin: {e}"


def show_desktop() -> str:
    """Simulates the Win+D keyboard shortcut to minimize/restore all
    open windows."""
    VK_LWIN, VK_D, KEYEVENTF_KEYUP = 0x5B, 0x44, 0x0002
    try:
        ctypes.windll.user32.keybd_event(VK_LWIN, 0, 0, 0)
        ctypes.windll.user32.keybd_event(VK_D, 0, 0, 0)
        ctypes.windll.user32.keybd_event(VK_D, 0, KEYEVENTF_KEYUP, 0)
        ctypes.windll.user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)
        return "Showing desktop."
    except Exception as e:
        return f"Something went wrong: {e}"


def get_battery_status() -> str:
    """Returns a spoken-friendly battery percentage and charging state.
    Desktops without a battery get a clear message instead of a crash."""
    battery = psutil.sensors_battery()
    if battery is None:
        return "This PC doesn't report a battery -- probably a desktop."
    state = "charging" if battery.power_plugged else "on battery"
    return f"Battery is at {round(battery.percent)} percent, {state}."


def get_storage_summary() -> str:
    """Returns free/total space for each detected fixed drive, as a
    spoken-friendly summary."""
    lines = []
    for part in psutil.disk_partitions(all=False):
        if "cdrom" in part.opts or not part.fstype:
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except PermissionError:
            continue
        free_gb = usage.free / (1024 ** 3)
        total_gb = usage.total / (1024 ** 3)
        drive = part.device.rstrip("\\")
        lines.append(f"{drive} has {free_gb:.0f} of {total_gb:.0f} gigabytes free")
    if not lines:
        return "Couldn't read disk usage."
    return "; ".join(lines) + "."


# ---------------------------------------------------------------------
# Brightness control -- requires: pip install screen-brightness-control
# ---------------------------------------------------------------------
def get_brightness_percent():
    """Returns current screen brightness 0-100, or None if unavailable
    (e.g. a desktop monitor without DDC/CI support, or the library
    isn't installed). sbc.get_brightness() can return either a plain
    int or a one-item list depending on the setup/version, so handle
    both instead of assuming one shape."""
    if not _BRIGHTNESS_AVAILABLE:
        return None
    try:
        result = sbc.get_brightness(display=0)
        if isinstance(result, list):
            return result[0] if result else None
        return result
    except Exception:
        return None


def set_brightness_percent(pct: int) -> str:
    """Sets screen brightness to an exact 0-100 percentage."""
    if not _BRIGHTNESS_AVAILABLE:
        return "Brightness control needs an extra library -- run: pip install screen-brightness-control"
    pct = max(0, min(100, pct))
    try:
        sbc.set_brightness(pct)
        return f"Brightness set to {pct} percent."
    except Exception as e:
        return f"Couldn't change brightness on this display: {e}"


def adjust_brightness(step: int) -> str:
    """Nudges brightness up or down by `step` percentage points."""
    if not _BRIGHTNESS_AVAILABLE:
        return "Brightness control needs an extra library -- run: pip install screen-brightness-control"
    current = get_brightness_percent()
    if current is None:
        return "Couldn't read the current brightness on this display."
    new_level = max(0, min(100, current + step))
    try:
        sbc.set_brightness(new_level)
        return f"Brightness {'up' if step > 0 else 'down'} to {new_level} percent."
    except Exception as e:
        return f"Couldn't change brightness: {e}"


# ---------------------------------------------------------------------
# Focus Assist (Do Not Disturb) -- Windows has no official public API
# for this. This edits a known but UNOFFICIAL registry value that
# Windows itself writes to when you toggle it from Settings. Microsoft
# could change its format in a future update and break this -- treat
# it as best-effort, not guaranteed long-term.
# ---------------------------------------------------------------------
_FOCUS_ASSIST_KEY = (
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache"
    r"\DefaultAccount\Current\windows.data.notifications.quiethourssettings\Current"
)

def _set_focus_assist(mode: int) -> str:
    """mode: 0 = off, 1 = priority only, 2 = alarms only."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _FOCUS_ASSIST_KEY,
                             0, winreg.KEY_ALL_ACCESS) as key:
            data, reg_type = winreg.QueryValueEx(key, "Data")
            data = bytearray(data)
            if len(data) < 19:
                return "Focus Assist setting wasn't in the expected format on this PC."
            data[18] = mode
            winreg.SetValueEx(key, "Data", 0, reg_type, bytes(data))
        return "Focus Assist turned off." if mode == 0 else "Focus Assist turned on."
    except FileNotFoundError:
        return ("Couldn't find the Focus Assist setting on this PC -- try opening "
                "it once from Windows Settings first, then ask me again.")
    except Exception as e:
        return f"Something went wrong changing Focus Assist: {e}"


def focus_assist_on() -> str:
    return _set_focus_assist(1)  # priority only


def focus_assist_off() -> str:
    return _set_focus_assist(0)


# ---------------------------------------------------------------------
# Wi-Fi -- reading the current network always works. Connecting only
# works for networks Windows already has a saved profile for (i.e. ones
# you've connected to manually at least once before), since netsh can't
# take a password inline for a brand-new network.
# ---------------------------------------------------------------------
def get_current_wifi() -> str:
    """Returns the currently connected Wi-Fi network name, if any."""
    try:
        result = subprocess.run(
            ["netsh", "wlan", "show", "interfaces"],
            capture_output=True, text=True,
        )
    except Exception as e:
        return f"Something went wrong checking Wi-Fi: {e}"
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("SSID") and "BSSID" not in stripped:
            ssid = stripped.split(":", 1)[1].strip()
            return f"You're connected to {ssid}." if ssid else "You're not connected to Wi-Fi."
    return "Couldn't determine the current Wi-Fi network."


def connect_to_wifi(name: str) -> str:
    """Connects to a Wi-Fi network by name. Only works if Windows
    already has a saved profile for it."""
    try:
        result = subprocess.run(
            ["netsh", "wlan", "connect", f"name={name}"],
            capture_output=True, text=True,
        )
    except Exception as e:
        return f"Something went wrong connecting to Wi-Fi: {e}"
    if result.returncode == 0:
        return f"Connecting to {name}."
    return (f"Couldn't connect to {name} -- make sure you've connected to it "
            f"manually at least once before so Windows has it saved.")


# ---------------------------------------------------------------------
# Wi-Fi radio on/off, Bluetooth on/off -- both need Administrator
# privileges (jarvis_up.py's _ensure_admin() requests this on startup;
# without it these return a clear failure message rather than silently
# doing nothing).
# ---------------------------------------------------------------------
def _get_wifi_interface_name() -> str:
    """Auto-detects the wireless interface's name via netsh, instead of
    assuming it's literally called 'Wi-Fi' (it usually is, but isn't
    guaranteed on every machine/language setting). Falls back to the
    literal string 'Wi-Fi' if detection fails."""
    try:
        result = subprocess.run(
            ["netsh", "interface", "show", "interface"],
            capture_output=True, text=True,
        )
        for line in result.stdout.splitlines():
            if "Wi-Fi" in line or "Wireless" in line:
                parts = line.split(None, 3)  # Admin State | State | Type | Name
                if len(parts) == 4:
                    return parts[3].strip()
    except Exception:
        pass
    return "Wi-Fi"


def set_wifi_radio(enabled: bool) -> str:
    """Turns the Wi-Fi adapter on or off entirely via netsh. Requires
    Administrator privileges -- returns a clear message if that's
    missing rather than failing silently."""
    interface_name = _get_wifi_interface_name()
    state = "enabled" if enabled else "disabled"
    try:
        result = subprocess.run(
            ["netsh", "interface", "set", "interface",
             f"name={interface_name}", f"admin={state}"],
            capture_output=True, text=True,
        )
    except Exception as e:
        return f"Something went wrong changing Wi-Fi: {e}"
    if result.returncode == 0:
        return f"Wi-Fi turned {'on' if enabled else 'off'}."
    return ("Couldn't change Wi-Fi -- this needs the terminal running "
            "as Administrator.")


def _run_powershell(cmd: str):
    return subprocess.run(
        ["powershell", "-NoProfile", "-Command", cmd],
        capture_output=True, text=True,
    )


def set_bluetooth_radio(enabled: bool) -> str:
    """Turns Bluetooth on or off by enabling/disabling the Bluetooth
    device(s) via PowerShell, auto-detected by device class rather than
    a hardcoded device ID (which varies per machine). Requires
    Administrator privileges."""
    action = "Enable-PnpDevice" if enabled else "Disable-PnpDevice"
    ps_cmd = f"Get-PnpDevice -Class Bluetooth | {action} -Confirm:$false"
    try:
        result = _run_powershell(ps_cmd)
    except Exception as e:
        return f"Something went wrong changing Bluetooth: {e}"
    if result.returncode == 0:
        return f"Bluetooth turned {'on' if enabled else 'off'}."
    return ("Couldn't change Bluetooth -- this needs the terminal running "
            "as Administrator.")


# ---------------------------------------------------------------------
# Night light -- same category as Focus Assist: an UNOFFICIAL registry
# value Windows itself writes to. UNLIKE Focus Assist, there isn't a
# verified byte offset for this one -- community reports disagree on
# the exact index/values, so what's below is a best guess, not a
# confirmed fact. If it doesn't work, run dump_night_light_state()
# before and after manually toggling Night Light from Windows Settings
# to compare the raw bytes and find the real offset on this PC:
#
#   python -c "from system_control import dump_night_light_state; print(dump_night_light_state())"
# ---------------------------------------------------------------------
_NIGHT_LIGHT_KEY = (
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache"
    r"\DefaultAccount\Current\default$windows.data.bluelightreduction"
    r".bluelightreductionstate\Current"
)

def dump_night_light_state() -> str:
    """Debug helper, not wired to a voice command: prints the raw bytes
    of the Night Light registry value so the correct toggle offset can
    be found by comparing output before/after manually switching Night
    Light on and off in Windows Settings. Run this from a Python shell,
    not by voice -- see the module comment above for the exact command."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _NIGHT_LIGHT_KEY) as key:
            data, _ = winreg.QueryValueEx(key, "Data")
            return " ".join(f"{b:02x}" for b in data)
    except Exception as e:
        return f"Couldn't read the value: {e}"


def _set_night_light(turn_on: bool) -> str:
    """Best-effort guess at toggling Night Light -- see module comment
    above. May not work on every PC; if it silently does nothing, use
    dump_night_light_state() to find the real byte offset."""
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _NIGHT_LIGHT_KEY,
                             0, winreg.KEY_ALL_ACCESS) as key:
            data, reg_type = winreg.QueryValueEx(key, "Data")
            data = bytearray(data)
            if len(data) < 25:
                return "Night Light setting wasn't in the expected format on this PC."
            data[23] = 0x15 if turn_on else 0x13  # best guess, see comment above
            winreg.SetValueEx(key, "Data", 0, reg_type, bytes(data))
        return (f"Tried turning Night Light {'on' if turn_on else 'off'} -- "
                f"check your screen to confirm it actually changed, this one's unverified.")
    except FileNotFoundError:
        return ("Couldn't find the Night Light setting on this PC -- try opening "
                "it once from Windows Settings first, then ask me again.")
    except Exception as e:
        return f"Something went wrong changing Night Light: {e}"


def night_light_on() -> str:
    return _set_night_light(True)


def night_light_off() -> str:
    return _set_night_light(False)
