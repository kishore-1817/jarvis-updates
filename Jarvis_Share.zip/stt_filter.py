"""
Rejects speech-to-text output that is almost certainly a Whisper
hallucination (invented text on noise/silence), so Jarvis ignores it
instead of acting on it.

Usage, right after transcription and before the HEARD/COMMAND log lines:

    from stt_filter import is_hallucination
    if is_hallucination(text, audio_seconds):
        text = ""            # treat it as "nothing heard"

audio_seconds is the clip length (the audio_len value in STT_TIMING).
"""

import re

_GHOST_PHRASES = (
    "thanks for watching",
    "thank you for watching",
    "please subscribe",
)


def _tokens(text: str):
    return re.findall(r"[a-z0-9']+", text.lower())


def is_hallucination(text: str, audio_seconds: float = None) -> bool:
    toks = _tokens(text or "")
    if not toks:
        return False

    low = (text or "").lower()
    if any(p in low for p in _GHOST_PHRASES):
        return True

    # 1) Impossible speech rate: normal speech is about 2-3 words/second.
    if audio_seconds and len(toks) >= 6 and len(toks) / audio_seconds > 5.0:
        return True

    # 2) Looping text: very few distinct words repeated over and over.
    if len(toks) >= 8 and len(set(toks)) / len(toks) < 0.35:
        return True

    # 3) Same word many times in a row ("friend friend friend ...").
    run = 1
    for a, b in zip(toks, toks[1:]):
        run = run + 1 if a == b else 1
        if run >= 5:
            return True

    return False


if __name__ == "__main__":
    bad = [
        ("tola, " * 75, 2.88),
        ("email id, email id, friend, friend, friend, friend, friend, friend, "
         "friend, friend, friend, friend, friend, friend, friend", 1.86),
        ("email id, personal mail id, " + "type my school address id, " * 30, 3.14),
        ("tola, tarun prasad's birthday, " * 20, 3.26),
        ("thanks for watching!", 2.11),
    ]
    good = [
        ("answer the question on my screen.", 1.86),
        ("What is 17 times 19?", 3.14),
        ("Hey Jarvis!", 3.58),
        ("ok", 1.34),
        ("What is the angle between the hands of clock at 3 15?", 4.29),
        ("3, 4, 8, 17, 33, what is the next number of the series?", 5.95),
    ]
    print("should be True :", [is_hallucination(t, s) for t, s in bad])
    print("should be False:", [is_hallucination(t, s) for t, s in good])
