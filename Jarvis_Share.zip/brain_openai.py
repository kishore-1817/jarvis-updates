"""
brain_openai.py -- Groq / OpenRouter / Ollama brains for Jarvis.

All three speak the OpenAI chat API, so one small client covers them. It does the
same things the Gemini path does: keeps a short chat history, streams the reply,
and lets the model call the SAME Python tool functions Jarvis already registers
(open app, screenshot, solve_problem_tool, ...). Tool schemas are built
automatically from each function's type hints + docstring.

pip install openai

.env (all optional overrides):
    GROQ_API_KEY=...          GROQ_MODEL=llama-3.3-70b-versatile
    OPENROUTER_API_KEY=...    OPENROUTER_MODEL=meta-llama/llama-3.3-70b-instruct:free
    OLLAMA_MODEL=qwen2.5:3b   OLLAMA_HOST=http://localhost:11434
Model names on free tiers change often -- if one 404s, just edit it in .env.
"""
import inspect
import json
import logging
import os
import re
import time
import typing

logger = logging.getLogger("jarvis")

MAX_HISTORY = 12
MAX_TOOL_ROUNDS = 5

_CFG = {
    "groq": dict(base="https://api.groq.com/openai/v1", key="GROQ_API_KEY",
                 model=("GROQ_MODEL", "llama-3.3-70b-versatile"), timeout=20),
    "openrouter": dict(base="https://openrouter.ai/api/v1", key="OPENROUTER_API_KEY",
                       model=("OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free"), timeout=30),
    "ollama": dict(base=None, key=None,
                   model=("OLLAMA_MODEL", "qwen2.5:3b"), timeout=90),
}
_clients = {}
_hist = {}     # provider -> list of messages (each brain keeps its own conversation)
_schemas = {}  # id(tools list) -> (schemas, {name: fn})


def reset():
    _hist.clear()


def _client(provider):
    if provider in _clients:
        return _clients[provider]
    from openai import OpenAI  # lazy: Jarvis still starts without the package
    c = _CFG[provider]
    if provider == "ollama":
        host = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
        if not host.startswith("http"):
            host = "http://" + host
        base, key = host + "/v1", "ollama"
    else:
        base, key = c["base"], os.environ.get(c["key"], "")
        if not key:
            raise RuntimeError(f"{c['key']} is not set")
    cl = OpenAI(base_url=base, api_key=key, timeout=c["timeout"], max_retries=0)
    _clients[provider] = cl
    return cl


def _model(provider):
    env, default = _CFG[provider]["model"]
    return os.environ.get(env, default)


# ---------------- tool schema from plain Python functions ----------------
def _json_type(tp):
    origin = typing.get_origin(tp)
    if origin is typing.Union:
        args = [a for a in typing.get_args(tp) if a is not type(None)]
        return _json_type(args[0]) if args else {"type": "string"}
    if origin in (list, tuple, set):
        return {"type": "array", "items": {"type": "string"}}
    if tp is bool:
        return {"type": "boolean"}
    if tp is int:
        return {"type": "integer"}
    if tp is float:
        return {"type": "number"}
    return {"type": "string"}


def _arg_docs(doc):
    out, cur, in_args = {}, None, False
    for line in doc.splitlines():
        s = line.strip()
        if re.match(r"^(Args|Arguments|Parameters):?$", s):
            in_args = True
            continue
        if in_args:
            if re.match(r"^(Returns|Raises|Example|Examples|Note|Notes):?$", s):
                break
            m = re.match(r"^(\w+)\s*(?:\([^)]*\))?\s*:\s*(.*)$", s)
            if m:
                cur = m.group(1)
                out[cur] = m.group(2)
            elif cur and s:
                out[cur] += " " + s
    return out


def build_tools(fns):
    """-> (openai tool schemas, {name: callable})"""
    schemas, table = [], {}
    for fn in fns:
        doc = inspect.getdoc(fn) or fn.__name__
        try:
            hints = typing.get_type_hints(fn)
        except Exception:
            hints = {}
        docs = _arg_docs(doc)
        props, req = {}, []
        for name, p in inspect.signature(fn).parameters.items():
            if p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD):
                continue
            ty = hints.get(name, str if p.default is p.empty or p.default is None else type(p.default))
            props[name] = {**_json_type(ty), "description": docs.get(name, name)}
            if p.default is p.empty:
                req.append(name)
        desc = re.split(r"\n\s*\n|\n\s*(?:Args|Arguments|Parameters):", doc)[0].replace("\n", " ").strip()
        schemas.append({"type": "function", "function": {
            "name": fn.__name__, "description": desc[:900],
            "parameters": {"type": "object", "properties": props, "required": req}}})
        table[fn.__name__] = fn
    return schemas, table


def _coerce(fn, args):
    try:
        hints = typing.get_type_hints(fn)
    except Exception:
        hints = {}
    allowed = inspect.signature(fn).parameters
    out = {}
    for k, v in (args or {}).items():
        if k not in allowed:
            continue
        tp = hints.get(k)
        if typing.get_origin(tp) is typing.Union:
            a = [x for x in typing.get_args(tp) if x is not type(None)]
            tp = a[0] if a else None
        try:
            if tp is bool and isinstance(v, str):
                v = v.strip().lower() in ("true", "1", "yes")
            elif tp is int and not isinstance(v, bool):
                v = int(float(v))
            elif tp is float:
                v = float(v)
        except Exception:
            pass
        out[k] = v
    return out


def _run_tool(table, name, raw_args):
    fn = table.get(name)
    if fn is None:
        return f"Unknown tool {name}"
    try:
        args = json.loads(raw_args) if raw_args else {}
    except Exception:
        args = {}
    try:
        res = fn(**_coerce(fn, args))
        return "" if res is None else str(res)
    except Exception as e:
        logger.error(f"tool {name} failed: {e!r}", exc_info=True)
        return f"Tool {name} failed: {e}"


# ---------------- chat ----------------
def _trim(h):
    if len(h) <= MAX_HISTORY:
        return
    h[:] = h[-MAX_HISTORY:]
    while h and h[0]["role"] != "user":   # never start on an assistant/tool message
        h.pop(0)


def stream(provider, prompt, system, tools, should_stop=None):
    """Yields raw text pieces as the model writes them. Runs tool calls in between."""
    cl = _client(provider)
    model = _model(provider)
    key = id(tools)
    if key not in _schemas:
        _schemas[key] = build_tools(tools)
    schemas, table = _schemas[key]

    h = _hist.setdefault(provider, [])
    n0 = len(h)
    h.append({"role": "user", "content": prompt})
    produced = False
    try:
        use_tools = bool(schemas)
        for _ in range(MAX_TOOL_ROUNDS):
            kw = dict(model=model, stream=True, temperature=0.4,
                      messages=[{"role": "system", "content": system}] + h)
            if use_tools:
                kw["tools"] = schemas
            if provider == "groq" and "gpt-oss" in model:
                # reasoning models "think" before answering; low keeps chat/tool turns snappy
                kw["extra_body"] = {"reasoning_effort": os.environ.get("GROQ_REASONING", "low")}
            t_start, t_first = time.time(), None
            try:
                resp = cl.chat.completions.create(**kw)
            except Exception as e:
                logger.warning(f"BRAIN_ERROR {provider} after {time.time()-t_start:.1f}s: {e!r}")
                if use_tools and ("tool_use_failed" in str(e) or "failed_generation" in str(e)):
                    logger.warning(f"{provider}: bad tool call, retrying without tools")
                    use_tools = False
                    continue
                raise
            text, calls = "", {}
            try:
                for chunk in resp:
                    if should_stop and should_stop():
                        del h[n0:]
                        return
                    if t_first is None:
                        t_first = time.time() - t_start
                    if not chunk.choices:
                        continue
                    d = chunk.choices[0].delta
                    if getattr(d, "content", None):
                        text += d.content
                        produced = True
                        yield d.content
                    for tc in (getattr(d, "tool_calls", None) or []):
                        c = calls.setdefault(tc.index, {"id": "", "name": "", "args": ""})
                        if tc.id:
                            c["id"] = tc.id
                        if tc.function:
                            if tc.function.name:
                                c["name"] = tc.function.name
                            if tc.function.arguments:
                                c["args"] += tc.function.arguments
            except Exception as e:
                if use_tools and ("tool_use_failed" in str(e) or "failed_generation" in str(e)):
                    use_tools = False
                    continue
                raise
            logger.info(f"BRAIN_TIMING {provider} model={model} first_chunk={t_first or 0:.2f}s "
                        f"round_total={time.time()-t_start:.2f}s tool_calls={len(calls)} tools_sent={len(schemas) if use_tools else 0}")
            if not calls:
                if not text.strip() and not produced:
                    raise RuntimeError(f"{provider} returned an empty reply")
                h.append({"role": "assistant", "content": text})
                _trim(h)
                return
            ordered = [calls[i] for i in sorted(calls)]
            for i, c in enumerate(ordered):
                c["id"] = c["id"] or f"call_{i}"
            h.append({"role": "assistant", "content": text or None, "tool_calls": [
                {"id": c["id"], "type": "function",
                 "function": {"name": c["name"], "arguments": c["args"] or "{}"}} for c in ordered]})
            for c in ordered:
                result = _run_tool(table, c["name"], c["args"])
                logger.info(f"TOOL[{provider}] {c['name']}({c['args']}) -> {result[:120]!r}")
                h.append({"role": "tool", "tool_call_id": c["id"], "content": result})
        # ran out of rounds without a final answer
        h.append({"role": "assistant", "content": "Done."})
        if not produced:
            yield "Done."
        _trim(h)
    except Exception:
        del h[n0:]     # don't leave a dangling user turn behind
        raise


def ask(provider, prompt, system, tools):
    return "".join(stream(provider, prompt, system, tools)).strip()
