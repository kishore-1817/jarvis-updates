"""
vision.py -- L3: sends the actual screenshot IMAGE to Gemini Vision.
The slowest, most expensive tier -- only reached when OCR (L1) didn't
get enough usable text to answer from (icons, buttons, images, pure
layout questions). This was the ONLY path the old implementation had
(sending every screenshot here regardless of question) -- now it's
the last resort, not the default, which is the whole point of this
pipeline.

Same API key/model as explain.py (L2) and llm_brain.py.

SDK NOTE (migrated 2026-09): uses the `google-genai` package
(`from google import genai`), not the older, deprecated
`google-generativeai` package -- see llm_brain.py's SDK NOTE for the
full old-vs-new API shape if you're used to the old one. PIL.Image
objects are still accepted directly in the contents list, unchanged
between the two SDKs.
"""

import os
from pathlib import Path

from google import genai
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

MODEL_NAME = "gemini-3.1-flash-lite"

_client = None


def _get_client():
    """Returns the google-genai Client, creating it once. Replaces the
    old SDK's genai.configure() + genai.GenerativeModel(model_name=...)
    pair -- the new SDK has no separate per-model object; the model
    name is only specified per-call, at generate_content() time."""
    global _client
    if _client is not None:
        return _client

    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        return None

    _client = genai.Client(api_key=api_key)
    return _client


def ask_about_image(image, question: str) -> str:
    """Answers a question by actually looking at the screenshot image.
    Returns a spoken-friendly answer, never raises."""
    client = _get_client()
    if client is None:
        return "I don't have a Gemini API key set up, so I can't look at the screen."

    prompt = question.strip() or "Describe what's currently on my screen, briefly."
    prompt += (" Answer in 1-3 short spoken sentences -- this will be read "
               "aloud, so no markdown, no lists, no asterisks.")

    try:
        # PIL.Image objects are accepted directly in the contents list --
        # the SDK converts them to an inline image part automatically,
        # same convenience the old SDK offered.
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=[prompt, image],
        )
        return response.text.strip()
    except Exception as e:
        return f"I couldn't analyze the screen: {e}"
