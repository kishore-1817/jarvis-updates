"""
clipboard_commands.py -- clipboard-related voice command matching.

Part of the Command Router refactor: this module owns ONLY the "which
phrase means what" matching for clipboard commands. The actual
clipboard mechanics (reading/writing/CF_HDROP file-copy/CF_DIB
image-copy) still live in clipboard_control.py -- this file is purely
the voice-command layer on top of it, kept separate so a future change
to matching/phrasing doesn't risk the underlying clipboard code, and
vice versa.

Checked before the file-manager domain in the router's priority order:
file_manager's "copy X to <folder>" pattern treats any word as a
possible folder name, including "clipboard" itself -- this domain
needs first refusal on clipboard-flavored phrasing so it isn't
shadowed the way it originally was (the "copy hello world to
clipboard" bug this ordering exists to prevent).
"""

import re

from clipboard_control import (
    set_clipboard_text, read_clipboard_summary,
    save_clipboard_to_file, copy_file_to_clipboard,
)
from file_manager import find_file

_SET_RE = re.compile(r"(?:copy|set clipboard to) (.+?)(?: to (?:the )?clipboard)?$")


def try_handle(t: str, speak) -> bool:
    """Checks `t` (the lowercased, stripped transcript) against every
    clipboard command this domain knows.

    Returns True and calls speak(...) if handled. Returns False
    (without calling speak at all) if this domain doesn't recognize
    the phrase, so the router can try the next domain -- or fall back
    to whatever hasn't been migrated out of jarvis_up.py yet.
    """
    if t in ("what's in my clipboard", "what is in my clipboard",
              "read my clipboard", "read clipboard", "check my clipboard"):
        speak(read_clipboard_summary())
        return True

    if t in ("save my clipboard", "save the clipboard",
              "save clipboard to a file", "save clipboard as a text file"):
        speak(save_clipboard_to_file())
        return True

    match = _SET_RE.match(t)
    if match and ("clipboard" in t or t.startswith("copy ")):
        target = match.group(1).strip()

        # If the target resolves to a real file (e.g. "my resume"),
        # copy the FILE itself (CF_HDROP) -- same as Ctrl+C on it in
        # Explorer. Only if no matching file exists do we fall back to
        # treating it as literal text to copy, so "copy hello world"
        # (no such file) still works exactly as before.
        found_file = find_file(target)
        if found_file is not None:
            success = copy_file_to_clipboard(found_file)
            speak(f"Copied {found_file.name} to clipboard." if success
                  else f"I couldn't copy {found_file.name} to the clipboard.")
            return True

        success = set_clipboard_text(target)
        speak("Copied to clipboard." if success else "I couldn't set the clipboard.")
        return True

    return False
