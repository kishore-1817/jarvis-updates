"""
capture.py -- shared screenshot capture, used by both the OCR tier
(L1) and the vision tier (L3), so there's exactly one place that grabs
the screen.
"""

from PIL import ImageGrab


def grab_screenshot():
    """Returns a PIL Image of the current screen. Raises on failure --
    callers should catch this themselves, since what to say back to
    the user differs by tier."""
    return ImageGrab.grab()
