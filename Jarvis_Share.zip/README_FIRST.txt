JARVIS - quick start (Windows 10/11 only)

1. Unzip this folder somewhere simple, e.g. C:\Jarvis  (not inside the zip).

2. Double-click  Jarvis.bat
   - If Python 3.11 is missing it installs it for you.
   - The first run needs internet and takes 5-15 minutes: it installs everything,
     asks for your free Gemini key (https://aistudio.google.com/apikey),
     and downloads the speech models.
   - After that, Jarvis starts by itself every time you double-click Jarvis.bat.

3. Say "hey Jarvis". In the Jarvis window you can Stop / Restart, run a
   Health check (microphone, OCR, key), edit .env, make a desktop shortcut,
   and tick "Launch with Windows" to start Jarvis when the PC turns on.

If the health check says Screen OCR fails: open PowerShell as Administrator and run
   Add-WindowsCapability -Online -Name "Language.OCR~~~en-US~0.0.1.0"

Optional
- Calls/messages use the WhatsApp app from the Microsoft Store (logged in). Add names to contacts.py.
- Tell Jarvis about yourself: say "remember my name is ..." (and your email, etc).
- Edit form_profile.txt with your details so Jarvis can fill Google Forms for you.

Problems? Send a screenshot of the Jarvis window to whoever sent you Jarvis.
