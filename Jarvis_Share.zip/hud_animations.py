"""
hud_animations.py -- drawing themes for the Jarvis HUD
=======================================================

hud.py owns the window, the state machine, the threads and Jarvis' API.
THIS file owns only how things look. Each theme draws the same Jarvis states
(LISTENING, THINKING, EXECUTING, SPEAKING, ...) in its own style:

    orb   Capsule with a glassy orb and a vertical line   (top-right, draggable)
    wave  Slim dock with voice bars                       (bottom-centre, draggable)
    none  Invisible - draws nothing                       ("hide animation")

Switching:   HUD_THEME in hud.py,  hotkey (HUD_THEME_HOTKEY),  or by voice
             ("switch the HUD to wave"). The choice is remembered.

Adding a theme later = one new class below + one line in THEMES. If a theme
fails to load or crashes, hud.py falls back to the previous one.

Rules every theme follows (same as the rest of the HUD):
  * create canvas items ONCE in build(), only move/recolour them per frame
  * nothing animates in STANDBY
  * never block, never touch Jarvis
"""

import json
import logging
import math
import os
import tkinter.font as tkfont

import hud as H          # config + helpers; hud.py imports this file lazily, so no cycle

log = logging.getLogger("jarvis.hud")

_clamp, _mix, _dim, _ease = H._clamp, H._mix, H._dim, H._ease
WHITE = "#ffffff"
KEY = H.KEY_COLOR


# =====================================================================
# SHARED BUILDING BLOCKS
# =====================================================================
class _Stadium:
    """A small pill (border + panel + text), e.g. the 'heard' bubble."""

    def __init__(self, cv, font, s, tag):
        self.cv, self.font, self.s, self.tag = cv, font, s, tag

        def oval(tags, fill):
            return cv.create_oval(0, 0, 1, 1, fill=fill, outline="", tags=tags, state="hidden")

        def rect(tags, fill):
            return cv.create_rectangle(0, 0, 1, 1, fill=fill, outline="", tags=tags, state="hidden")

        bt, ft = (tag, tag + "_b"), (tag,)
        self.border = [oval(bt, KEY), oval(bt, KEY), rect(bt, KEY)]
        self.fill = [oval(ft, H.PANEL_BG), oval(ft, H.PANEL_BG), rect(ft, H.PANEL_BG)]
        self.text = cv.create_text(0, 0, text="", anchor="center", font=font,
                                   fill=H.TEXT_COLOR, tags=ft, state="hidden")

    def recolor(self, col):
        self.cv.itemconfigure(self.tag + "_b", fill=_mix(H.PANEL_BG, col, 0.28))

    def place(self, text, cx, top, max_w):
        cv, s = self.cv, self.s
        pad = 11 * s
        bh = self.font.metrics("linespace") + 10 * s
        r = bh / 2.0
        w = min(self.font.measure(text) + 2 * pad, max_w)
        left, right, yc = cx - w / 2.0, cx + w / 2.0, top + r
        ri = r - max(1.0, 1.2 * s)
        for items, rad in ((self.border, r), (self.fill, ri)):
            cv.coords(items[0], left + r - rad, yc - rad, left + r + rad, yc + rad)
            cv.coords(items[1], right - r - rad, yc - rad, right - r + rad, yc + rad)
            cv.coords(items[2], left + r, yc - rad, right - r, yc + rad)
        cv.coords(self.text, cx, yc)
        cv.itemconfigure(self.text, text=text)
        cv.itemconfigure(self.tag, state="normal")
        return bh

    def hide(self):
        self.cv.itemconfigure(self.tag, state="hidden")


def _fit(font, text, max_w):
    while font.measure(text) > max_w and len(text) > 4:
        text = text[:-4] + "..."
    return text


def _heard_text(text):
    text = " ".join(str(text).split())
    if not text:
        return None
    if len(text) > H.HEARD_TEXT_MAX_CHARS:
        text = text[:H.HEARD_TEXT_MAX_CHARS - 3].rstrip() + "..."
    return "\u201c%s\u201d" % text


class Theme:
    """Base class: alpha fades, standby fade-out, dragging and saved position."""
    name = "base"
    movable = False

    def __init__(self, host):
        self.h = host
        self.cv = host.cv
        self.root = host.root
        self.s = host.scale
        self.sw, self.sh = host.sw, host.sh
        self._active = False
        self._tw = None                 # alpha tween: (a0, a1, t0, dur, then)
        self._alpha_cur = 0.02
        self._movable = False
        self._drag = None
        self._dragged = False

    # ---- a theme must provide these ----------------------------------
    def window_rect(self):
        raise NotImplementedError

    def build(self):
        raise NotImplementedError

    def show_state(self, name, spec, text, now):
        raise NotImplementedError

    def set_message(self, text, now):
        pass

    def frame(self, spec, t, now):
        pass

    def anchor(self):
        """(x, y, radius) inside the window that must stay on screen when dragged."""
        return (0, 0, 0)

    # ---- optional ------------------------------------------------------
    def show_heard(self, text, now):
        pass

    def hide_heard(self):
        pass

    def fps(self, spec):
        return spec["fps"]

    def destroy(self):
        self.cv.delete("all")

    def busy(self):
        return self._tw is not None

    # ---- helpers ---------------------------------------------------------
    def font(self, size, **kw):
        return tkfont.Font(root=self.root, family=H.FONT_FAMILY,
                           size=-max(8, round(size * self.s)), **kw)

    def _vis(self, tag, on):
        self.cv.itemconfigure(tag, state="normal" if on else "hidden")

    def _set_alpha(self, a):
        self._alpha_cur = _clamp(a, 0.02, 1.0)
        self.h.set_window_alpha(self._alpha_cur)

    def _alpha_to(self, target, dur, now, then=None):
        self._tw = (self._alpha_cur, _clamp(target, 0.02, 1.0), now, max(0.01, dur), then)

    def _step_alpha(self, now):
        tw = self._tw
        if tw is None:
            return
        a0, a1, t0, dur, then = tw
        f = _clamp((now - t0) / dur)
        self._set_alpha(a0 + (a1 - a0) * _ease(f))
        if f >= 1.0:
            self._tw = None
            if then is not None:
                then(now)

    def _standby_target(self):
        return _clamp(H.STATES["STANDBY"]["alpha"][0] * H.HUD_OPACITY, 0.02, 1.0)

    def _go_standby(self, now):
        """Fade the widget out first, then draw the idle look."""
        self.hide_heard()
        if self._active:
            self._alpha_to(0.02, H.FADE_SECONDS * 0.8, now, then=self._enter_standby)
        else:
            self._enter_standby(now)

    def _enter_standby(self, now):
        raise NotImplementedError

    def _settle_standby_alpha(self, now):
        target = self._standby_target()
        if self._alpha_cur <= 0.05 and self.h.alpha_set > 0:    # coming from the fade-out
            self._alpha_to(target, H.FADE_SECONDS, now)
        else:
            self._set_alpha(target)

    def _enter_alpha(self, p_alpha, varying, now):
        """Fade in when entering an active state (or set directly if it fades itself)."""
        if varying:
            self._set_alpha(p_alpha)
        elif abs(p_alpha - self._alpha_cur) > 0.02:
            self._alpha_to(p_alpha, H.FADE_SECONDS, now)

    # ---- dragging + saved position (movable themes) --------------------
    def pos_file(self):
        raise NotImplementedError

    def default_pos(self):
        raise NotImplementedError

    def pos_to_data(self, x, y):
        raise NotImplementedError

    def pos_from_data(self, d):
        raise NotImplementedError

    def _clamp_pos(self, x, y):
        ax, ay, r = self.anchor()
        x = min(max(int(x), int(r - ax)), int(self.sw - r - ax))
        y = min(max(int(y), int(r - ay)), int(self.sh - r - ay))
        return x, y

    def initial_pos(self):
        x, y = self.default_pos()
        if H.REMEMBER_POSITION and getattr(H, "RESTORE_SAVED_POSITION", False):
            try:
                with open(self.pos_file(), "r", encoding="utf-8") as f:
                    x, y = self.pos_from_data(json.load(f))
            except Exception:
                pass
        return self._clamp_pos(x, y)

    def _save_position(self):
        if not H.REMEMBER_POSITION:
            return
        try:
            x, y = self.h.window_xy()
            with open(self.pos_file(), "w", encoding="utf-8") as f:
                json.dump(self.pos_to_data(x, y), f)
            log.info("HUD position saved (%s theme)", self.name)
        except Exception as e:
            log.warning("HUD: could not save position: %r", e)

    def reset_position(self):
        if not self.movable:
            return
        try:
            os.remove(self.pos_file())
        except OSError:
            pass
        self.h.move_window(*self._clamp_pos(*self.default_pos()))

    def set_movable(self, on):
        """Move mode: accept the mouse so the widget can be dragged."""
        if not self.movable:
            return
        self._movable = bool(on)
        try:
            self.cv.configure(cursor="fleur" if on else "")
        except Exception:
            pass
        self.h.set_clickthrough(not on)

    def on_press(self, e):
        if self._movable:
            x, y = self.h.window_xy()
            self._drag, self._dragged = (e.x_root, e.y_root, x, y), False

    def on_motion(self, e):
        if not (self._movable and self._drag):
            return
        mx, my, x0, y0 = self._drag
        self.h.move_window(*self._clamp_pos(x0 + e.x_root - mx, y0 + e.y_root - my))
        self._dragged = True

    def on_release(self, e):
        if self._movable and self._drag and self._dragged:
            self._drag = None
            self._save_position()
            self.h.notify(("move_done",))


# =====================================================================
# THEME 1: ORB   (capsule + glassy orb + vertical line)
# =====================================================================
_N_HALO = 9
_HALO_R = tuple(0.99 - 0.49 * k / (_N_HALO - 1) for k in range(_N_HALO))
_CORE = ((0.40, 0.000, 0.000), (0.33, -0.015, -0.020), (0.25, -0.040, -0.050), (0.15, -0.070, -0.085))
_SPEC = (0.065, -0.120, -0.140)
_ARC_R = (0.92, 0.78, 0.64)
_ARC_EXT = (85, 60, 45)
_N_LINE = 9
_N_PULSE = 5
_CAP_TWEEN = 0.18


def orb_pose(spec, t):
    """What the orb should look like `t` seconds after a state started."""
    kind, sp = spec["kind"], H.ANIMATION_SPEED
    lo, hi = spec["alpha"]
    ts = t * sp
    p = {"alpha": hi, "b": 0.0, "scale": 1.0, "bloom": 0.0, "ripples": (None, None),
         "arcs": None, "pulse": None, "glint": 0.0, "border": None, "mark": None,
         "varying": False}
    if kind not in ("static", "collapse"):
        p["bloom"] = max(0.0, 1.0 - t / 0.4) ** 2          # quick "pop" when a state starts
    if kind in ("breathe", "speak", "orbit", "flow"):
        g = (ts / 3.4) % 1.0                                # occasional shine on the orb
        if g > 0.82:
            p["glint"] = math.sin(math.pi * (g - 0.82) / 0.18)
    if kind == "static":
        p["alpha"] = lo
    elif kind == "breathe":
        ph = ts / spec["period"]
        p["b"] = 0.5 - 0.5 * math.cos(2 * math.pi * ph)
        if spec["ripple"] == 2:
            p["ripples"] = (ph % 1.0, (ph + 0.5) % 1.0)
        elif spec["ripple"] == 1:
            p["ripples"] = (ph % 1.0, None)
            p["border"] = p["b"]
    elif kind == "speak":
        w = (0.5 + 0.30 * math.sin(2 * math.pi * ts / spec["period"])
                 + 0.18 * math.sin(2 * math.pi * ts / 0.37 + 1.3))
        p["b"] = _clamp(w)
        r = (ts * 1.3) % 1.0
        p["ripples"] = (r, (r + 0.5) % 1.0)
    elif kind == "orbit":
        p["b"] = 0.30
        base = 360.0 * ts / spec["period"]
        p["arcs"] = ((-base) % 360.0, (base * 1.5) % 360.0, (-base * 2.2) % 360.0)
    elif kind == "flow":
        ph = (ts / spec["period"]) % 1.0
        p["pulse"] = ph
        p["b"] = 0.30 + 0.45 * (1.0 - _ease(min(1.0, ph * 3.0)))
    elif kind == "fade":
        f = _clamp(t / spec["duration"])
        p["b"] = math.sin(math.pi * f)
        p["ripples"] = (f, None)
        p["border"] = p["b"]
        p["mark"] = "check" if f > 0.08 else None
        p["alpha"], p["varying"] = hi * (1.0 - f * f), True
    elif kind == "blink":
        f = _clamp(t / spec["duration"])
        p["b"] = 0.5 + 0.5 * math.cos(4 * math.pi * f)
        p["border"] = p["b"]
        p["mark"] = "cross"
        p["alpha"], p["varying"] = hi * (1.0 - max(0.0, f - 0.7) / 0.3), True
    elif kind == "collapse":
        f = _clamp(t / spec["duration"])
        p["b"], p["scale"] = 0.2, max(0.35, 1.0 - 0.65 * f)
        p["alpha"], p["varying"] = hi * (1.0 - f), True
    p["alpha"] = _clamp(p["alpha"] * H.HUD_OPACITY)
    return p


class OrbTheme(Theme):
    name = "orb"
    movable = True

    def __init__(self, host):
        Theme.__init__(self, host)
        s = self.s
        self.R = H.ORB_SIZE / 2.0 * s                # orb radius
        self.Hc = self.R + 5 * s                     # capsule half-height
        self.L = H.LINE_LENGTH * s
        self.text_max = 200 * s
        self.fb = self.font(10, weight="bold")
        self.fs = self.font(12)
        self.fd = self.font(9)
        self.fh = self.font(11, slant="italic")
        self.Wn = int(2 * self.Hc + self.text_max + 40 * s)
        self.Hn = int(2 * self.Hc + self.L + 22 * s)
        self.cx = self.Wn - self.Hc - 2
        self.cy = self.Hc + 2
        self._cw = None                              # capsule tween: (l0, l1, t0)
        self._cap_left = self.cx - self.Hc
        self._text_on = False
        self._brand_on = True
        self._col = H.COLORS["STANDBY"]
        self._cs = 1.0
        self._reset_keys()

    # ---- window / position -------------------------------------------
    def window_rect(self):
        x, y = self.initial_pos()
        return x, y, self.Wn, self.Hn

    def anchor(self):
        return (self.cx, self.cy, self.R)

    def pos_file(self):
        return H._POS_FILE

    def default_pos(self):
        return (self.sw - self.Wn - H.HUD_MARGIN_RIGHT * self.s, H.HUD_MARGIN_TOP * self.s)

    def pos_to_data(self, x, y):
        return {"right": round((self.sw - (x + self.Wn)) / self.s, 1), "top": round(y / self.s, 1)}

    def pos_from_data(self, d):
        return (self.sw - self.Wn - float(d["right"]) * self.s, float(d["top"]) * self.s)

    def _reset_keys(self):
        self._orb_key = None
        self._rkeys = [None, None]
        self._akeys = [None, None, None]
        self._pulse_key = None
        self._glint_key = None
        self._border_key = None
        self._mark = None

    # ---- item creation (once) --------------------------------------
    def build(self):
        cv, s, cx, cy, R, Hc = self.cv, self.s, self.cx, self.cy, self.R, self.Hc

        def oval(tags, **kw):
            return cv.create_oval(0, 0, 1, 1, tags=tags, state="hidden", **kw)

        def line(tags, width, **kw):
            return cv.create_line(0, 0, 1, 1, width=width, tags=tags, state="hidden",
                                  capstyle="round", joinstyle="round", fill=KEY, **kw)

        self._cap_outer = [oval(("cap", "capb"), fill=KEY, outline=""),
                           oval(("cap", "capb"), fill=KEY, outline=""),
                           cv.create_rectangle(0, 0, 1, 1, fill=KEY, outline="",
                                               tags=("cap", "capb"), state="hidden")]
        self._cap_inner = [oval(("cap",), fill=H.PANEL_BG, outline=""),
                           oval(("cap",), fill=H.PANEL_BG, outline=""),
                           cv.create_rectangle(0, 0, 1, 1, fill=H.PANEL_BG, outline="",
                                               tags=("cap",), state="hidden")]
        self._sheen = line(("sheen",), max(1.0, s))
        cv.itemconfigure(self._sheen, fill=_mix(H.PANEL_BG, WHITE, 0.10))

        self._halo = [oval(("orb",), fill=H.PANEL_BG, outline="") for _ in range(_N_HALO)]
        self._ring = oval(("orb",), fill="", outline=KEY, width=max(1, round(s)))
        self._ripple = [oval(("ripple",), fill="", outline=KEY, width=max(1.0, 1.4 * s))
                        for _ in range(2)]
        self._arcs = []
        for rel, ext, w in zip(_ARC_R, _ARC_EXT, (2.2, 1.7, 1.3)):
            r = R * rel
            self._arcs.append(cv.create_arc(cx - r, cy - r, cx + r, cy + r, start=0, extent=ext,
                                            style="arc", outline=KEY, width=max(1.0, w * s),
                                            tags=("arcs",), state="hidden"))
        self._core = [oval(("orb",), fill=KEY, outline="") for _ in _CORE]
        self._spec = oval(("orb",), fill=KEY, outline="")

        self._glint = [line(("glint",), max(1.0, s)) for _ in range(2)]
        pts = ((-0.15, 0.00), (-0.05, 0.11), (0.16, -0.12))
        self._check = cv.create_line(*[v for dx, dy in pts for v in (cx + dx * R, cy + dy * R)],
                                     width=max(2.0, 2.4 * s), capstyle="round", joinstyle="round",
                                     fill=WHITE, tags=("mark", "check"), state="hidden")
        self._cross = [cv.create_line(cx - 0.12 * R, cy - 0.12 * R, cx + 0.12 * R, cy + 0.12 * R,
                                      width=max(2.0, 2.4 * s), capstyle="round", fill=WHITE,
                                      tags=("mark", "cross"), state="hidden"),
                       cv.create_line(cx - 0.12 * R, cy + 0.12 * R, cx + 0.12 * R, cy - 0.12 * R,
                                      width=max(2.0, 2.4 * s), capstyle="round", fill=WHITE,
                                      tags=("mark", "cross"), state="hidden")]
        dr = max(2.2 * s, R * 0.10)
        self._dot = cv.create_oval(cx - dr, cy - dr, cx + dr, cy + dr, fill=KEY, outline="",
                                   tags=("dot",), state="hidden")

        y0 = cy + Hc
        seg = self.L / _N_LINE
        self._line = [cv.create_line(cx, y0 + k * seg, cx, y0 + (k + 1) * seg + 0.5,
                                     width=max(1.0, 1.4 * s), capstyle="round", fill=KEY,
                                     tags=("line",), state="hidden") for k in range(_N_LINE)]
        er = max(1.6 * s, 2.0)
        self._enddot = cv.create_oval(cx - er, y0 + self.L - er, cx + er, y0 + self.L + er,
                                      fill=KEY, outline="", tags=("line",), state="hidden")
        self._pulse = [oval(("pulse",), fill=KEY, outline="") for _ in range(_N_PULSE)]

        self._t_brand = cv.create_text(0, 0, text="JARVIS", anchor="e", font=self.fb,
                                       fill=H.TEXT_COLOR, tags=("txt",), state="hidden")
        self._t_status = cv.create_text(0, 0, text="", anchor="e", font=self.fs,
                                        fill=H.TEXT_COLOR, tags=("txt",), state="hidden")
        self._heard_b = [oval(("heard", "heardb"), fill=KEY, outline=""),
                         oval(("heard", "heardb"), fill=KEY, outline=""),
                         cv.create_rectangle(0, 0, 1, 1, fill=KEY, outline="",
                                             tags=("heard", "heardb"), state="hidden")]
        self._heard_f = [oval(("heard",), fill=H.PANEL_BG, outline=""),
                         oval(("heard",), fill=H.PANEL_BG, outline=""),
                         cv.create_rectangle(0, 0, 1, 1, fill=H.PANEL_BG, outline="",
                                             tags=("heard",), state="hidden")]
        self._t_heard = cv.create_text(0, 0, text="", anchor="center", font=self.fh,
                                       fill=H.TEXT_COLOR, tags=("heard",), state="hidden")
        self._t_debug = cv.create_text(cx - Hc, cy + Hc + 14 * s, text="", anchor="ne",
                                       font=self.fd, fill=H.TEXT_COLOR, state="hidden")
        self._place_capsule(self._cap_left)
        self.show_state("STANDBY", H.STATES["STANDBY"], None, 0.0)

    # ---- geometry ----------------------------------------------------
    @staticmethod
    def _circle(cv, item, x, y, r):
        cv.coords(item, x - r, y - r, x + r, y + r)

    def _place_capsule(self, left):
        cv, cx, cy, Hc, s = self.cv, self.cx, self.cy, self.Hc, self.s
        for items, r in ((self._cap_outer, Hc), (self._cap_inner, Hc - max(1.0, 1.2 * s))):
            lx = left + Hc
            self._circle(cv, items[0], lx, cy, r)
            self._circle(cv, items[1], cx, cy, r)
            cv.coords(items[2], lx, cy - r, cx, cy + r)
        x0, x1 = left + Hc * 0.95, cx - Hc * 0.30
        ys = cy - Hc + 3.2 * s
        cv.coords(self._sheen, x0, ys, max(x0, x1), ys)
        cv.itemconfigure(self._sheen, state="normal" if (self._active and x1 - x0 > 8 * s) else "hidden")
        self._cap_left = left

    def _draw_orb(self, p):
        b, scale, bloom = p["b"], p["scale"], p["bloom"]
        key = (round(b * 48), round(scale * 50), round(bloom * 20))
        if key == self._orb_key:
            return
        self._orb_key = key
        cv, cx, cy, R = self.cv, self.cx, self.cy, self.R
        hs = (0.74 + 0.26 * b + 0.22 * bloom) * scale
        for item, f in zip(self._halo, _HALO_R):
            self._circle(cv, item, cx, cy, R * f * hs)
        cs = (0.92 + 0.12 * b) * (1.0 + 0.18 * bloom) * scale
        self._cs = cs
        for item, (rr, dx, dy) in zip(self._core, _CORE):
            self._circle(cv, item, cx + dx * R * cs, cy + dy * R * cs, R * rr * cs)
        rr, dx, dy = _SPEC
        self._circle(cv, self._spec, cx + dx * R * cs, cy + dy * R * cs, R * rr * cs)
        self._circle(cv, self._ring, cx, cy, R * 0.80 * scale)

    def _recolor(self, col):
        cv = self.cv
        self._col = col
        cv.itemconfigure("capb", fill=_mix(H.PANEL_BG, col, 0.32))
        for k, item in enumerate(self._halo):
            cv.itemconfigure(item, fill=_mix(H.PANEL_BG, col, 0.05 + 0.50 * k / (_N_HALO - 1)))
        cv.itemconfigure(self._ring, outline=_mix(H.PANEL_BG, col, 0.42))
        core_cols = (_mix(H.PANEL_BG, col, 0.62), _mix(H.PANEL_BG, col, 0.86), col, _mix(col, WHITE, 0.42))
        for item, c in zip(self._core, core_cols):
            cv.itemconfigure(item, fill=c)
        cv.itemconfigure(self._spec, fill=_mix(col, WHITE, 0.88))
        for arc, f in zip(self._arcs, (1.0, 0.88, 0.74)):
            cv.itemconfigure(arc, outline=_dim(col, f))
        for k, item in enumerate(self._line):
            cv.itemconfigure(item, fill=_dim(col, 0.78 - 0.58 * k / (_N_LINE - 1)))
        cv.itemconfigure(self._enddot, fill=_dim(col, 0.34))
        for item, f in zip(self._pulse, (0.40, 0.30, 0.46, 0.64)):
            cv.itemconfigure(item, fill=_dim(col, f))
        cv.itemconfigure(self._pulse[-1], fill=_mix(col, WHITE, 0.50))
        cv.itemconfigure(self._t_brand, fill=_mix(col, WHITE, 0.35))
        cv.itemconfigure(self._dot, fill=_dim(col, 0.80))
        cv.itemconfigure("heardb", fill=_mix(H.PANEL_BG, col, 0.28))
        self._border_key = None

    # ---- state / text --------------------------------------------------
    def show_state(self, name, spec, text, now):
        cv = self.cv
        if name == "STANDBY":
            cv.itemconfigure(self._dot, fill=_dim(H.COLORS["STANDBY"], 0.80))
            self._go_standby(now)
            return

        self._active, self._tw = True, None
        self._recolor(H.COLORS[name])
        self._vis("dot", False)
        self._vis("cap", True)
        self._vis("orb", True)
        self._vis("line", True)
        self._vis("ripple", False)
        self._vis("glint", False)
        self._vis("mark", False)
        self._vis("arcs", spec["kind"] == "orbit")
        self._vis("pulse", spec["kind"] == "flow")
        self._reset_keys()
        p = orb_pose(spec, 0.0)
        self._draw_orb(p)
        self._enter_alpha(p["alpha"], p["varying"], now)
        self.set_message(text, now)
        self._place_capsule(self._cap_left)
        self.h.raise_topmost()
        if H.HUD_DEBUG:
            cv.itemconfigure(self._t_debug, text="STATE: %s | MESSAGE: %s" % (name, text or "-"),
                             state="normal")

    def _enter_standby(self, now):
        self._active = False
        self._cw = None
        self._text_on = False
        for tag in ("cap", "orb", "line", "ripple", "arcs", "pulse", "txt", "glint", "mark", "sheen"):
            self._vis(tag, False)
        self.cv.itemconfigure(self._t_debug, state="hidden")
        self._vis("dot", True)
        self._place_capsule(self.cx - self.Hc)
        self._settle_standby_alpha(now)

    def set_message(self, text, now):
        """Expand the capsule to show `text`, or collapse it to just the orb."""
        if not self._active:
            return
        cv, s = self.cv, self.s
        if not (text and H.STATUS_TEXT_ENABLED):
            self._text_on = False
            self._vis("txt", False)
            self._cap_to(self.cx - self.Hc, now)
            return
        text = _fit(self.fs, text, self.text_max)
        brand = H.MINI_INDICATOR_ENABLED
        w = self.fs.measure(text)
        if brand:
            w = max(w, self.fb.measure("JARVIS"))
        right = self.cx - self.R - 9 * s
        cv.itemconfigure(self._t_status, text=text)
        if brand:
            cv.coords(self._t_brand, right, self.cy - 8 * s)
            cv.coords(self._t_status, right, self.cy + 8 * s)
        else:
            cv.coords(self._t_status, right, self.cy)
        self._brand_on = brand
        self._text_on = True
        self._cap_to(right - w - 18 * s, now)
        if self._cw is None:
            self._show_text()
        else:
            self._vis("txt", False)

    def show_heard(self, text, now):
        if not (self._active and H.HEARD_TEXT_ENABLED):
            return
        shown = _heard_text(text)
        if not shown:
            return
        cv, s = self.cv, self.s
        pad = 11 * s
        bh = self.fh.metrics("linespace") + 10 * s
        r = bh / 2.0
        w = min(self.fh.measure(shown) + 2 * pad, self.cx - 24 * s)
        right = self.cx - 10 * s
        left = right - w
        top = self.cy + self.Hc + 12 * s
        yc = top + r
        ri = r - max(1.0, 1.2 * s)
        for items, rad in ((self._heard_b, r), (self._heard_f, ri)):
            self._circle(cv, items[0], left + r, yc, rad)
            self._circle(cv, items[1], right - r, yc, rad)
            cv.coords(items[2], left + r, yc - rad, right - r, yc + rad)
        cv.coords(self._t_heard, (left + right) / 2.0, yc)
        cv.itemconfigure(self._t_heard, text=shown)
        self._vis("heard", True)

    def hide_heard(self):
        self._vis("heard", False)

    def _show_text(self):
        if not self._text_on:
            return
        self.cv.itemconfigure(self._t_status, state="normal")
        self.cv.itemconfigure(self._t_brand, state="normal" if self._brand_on else "hidden")

    def _cap_to(self, left, now):
        left = max(0.0, left)
        if abs(left - self._cap_left) < 0.5:
            self._cw = None
            self._place_capsule(left)
        else:
            self._cw = (self._cap_left, left, now)

    # ---- per-frame work --------------------------------------------------
    def busy(self):
        return self._tw is not None or self._cw is not None

    def frame(self, spec, t, now):
        self._step_alpha(now)
        cw = self._cw
        if cw is not None:
            l0, l1, t0 = cw
            f = _clamp((now - t0) / _CAP_TWEEN)
            self._place_capsule(l0 + (l1 - l0) * _ease(f))
            if f >= 1.0:
                self._cw = None
                self._show_text()
        if spec["kind"] == "static" or not self._active:
            return

        p = orb_pose(spec, t)
        if p["varying"]:
            self._set_alpha(p["alpha"])
        self._draw_orb(p)
        cv, cx, cy, R, s, col = self.cv, self.cx, self.cy, self.R, self.s, self._col

        for i, rp in enumerate(p["ripples"]):
            if rp is None:
                if self._rkeys[i] is not None:
                    cv.itemconfigure(self._ripple[i], state="hidden")
                    self._rkeys[i] = None
                continue
            key = round(rp * 40)
            if key != self._rkeys[i]:
                self._rkeys[i] = key
                self._circle(cv, self._ripple[i], cx, cy, R * (0.36 + 0.62 * rp))
                cv.itemconfigure(self._ripple[i], state="normal",
                                 outline=_mix(H.PANEL_BG, col, 0.85 * (1.0 - rp) ** 1.3))

        if p["arcs"] is not None:
            for i, ang in enumerate(p["arcs"]):
                key = round(ang / 4)
                if key != self._akeys[i]:
                    self._akeys[i] = key
                    cv.itemconfigure(self._arcs[i], start=ang)

        if p["pulse"] is not None:
            key = round(p["pulse"] * 120)
            if key != self._pulse_key:
                self._pulse_key = key
                u = _ease(p["pulse"])
                y0 = cy + self.Hc
                y = y0 + u * self.L
                k = 1.0 - max(0.0, (p["pulse"] - 0.80) / 0.20)
                glow, t3, t2, t1, core = self._pulse
                self._circle(cv, glow, cx, y, 5.5 * s * k)
                for item, off, rad in ((t1, 6, 2.1), (t2, 12, 1.6), (t3, 18, 1.1)):
                    yy = y - off * s * k
                    if yy > y0 and k > 0.05:
                        self._circle(cv, item, cx, yy, rad * s * k)
                        cv.itemconfigure(item, state="normal")
                    else:
                        cv.itemconfigure(item, state="hidden")
                self._circle(cv, core, cx, y, 2.6 * s * k)
                fl = _clamp((p["pulse"] - 0.84) / 0.16)
                cv.itemconfigure(self._enddot, fill=_mix(_dim(col, 0.34), _mix(col, WHITE, 0.5), fl))

        g = p["glint"]
        gkey = round(g * 16)
        if gkey != self._glint_key:
            self._glint_key = gkey
            if g < 0.04:
                self._vis("glint", False)
            else:
                cs = self._cs
                gx, gy = cx + _SPEC[1] * R * cs, cy + _SPEC[2] * R * cs
                arm = R * 0.26 * g * cs
                cv.coords(self._glint[0], gx - arm, gy, gx + arm, gy)
                cv.coords(self._glint[1], gx, gy - arm, gx, gy + arm)
                for item in self._glint:
                    cv.itemconfigure(item, state="normal", fill=_mix(col, WHITE, 0.55 + 0.45 * g))

        if p["mark"] != self._mark:
            self._mark = p["mark"]
            self._vis("check", p["mark"] == "check")
            self._vis("cross", p["mark"] == "cross")

        if p["border"] is not None:
            bk = round(p["border"] * 16)
            if bk != self._border_key:
                self._border_key = bk
                cv.itemconfigure("capb", fill=_mix(H.PANEL_BG, col, 0.30 + 0.62 * p["border"]))


# =====================================================================
# THEME 2: WAVE DOCK   (slim dock at the bottom, animated voice bars)
# =====================================================================
def wave_levels(name, spec, t, n):
    """Bar heights (0..1 each), window alpha and whether alpha changes over time."""
    ts = t * H.ANIMATION_SPEED
    hi = spec["alpha"][1]
    tau = 2 * math.pi
    c = (n - 1) / 2.0
    alpha, varying = hi, False
    if name == "LISTENING":
        lv = [0.20 + 0.16 * (0.5 + 0.5 * math.sin(tau * (ts / 2.6 - i / n * 0.9))) for i in range(n)]
    elif name == "THINKING":
        u = (ts / 1.7) % 1.0
        pos = (1.0 - abs(2.0 * u - 1.0)) * (n - 1)
        lv = [0.12 + 0.78 * math.exp(-((i - pos) ** 2) / (2 * 1.7 ** 2)) for i in range(n)]
    elif name == "EXECUTING":
        pos = ((ts / 1.0) % 1.0) * (n + 3) - 2
        lv = [0.92 if abs(i - pos) < 0.8 else (0.34 if i < pos else 0.14) for i in range(n)]
    elif name == "SPEAKING":
        env = _clamp(0.55 + 0.30 * math.sin(tau * ts / 0.9) + 0.18 * math.sin(tau * ts / 0.37 + 1.3), 0.25, 1.0)
        lv = [_clamp(0.16 + 0.80 * abs(math.sin(tau * (ts * 1.15 + i * 0.37)))
                     * (0.55 + 0.45 * math.sin(tau * (ts * 0.7 + i * 0.21) + 1.0)) * env)
              for i in range(n)]
    elif name in ("CONFIRMATION", "MOVE"):
        per = 1.2 if name == "CONFIRMATION" else 1.6
        lv = [0.25 + 0.50 * (0.5 + 0.5 * math.sin(tau * ts / per))] * n
    elif name == "SUCCESS":
        f = _clamp(t / spec["duration"])
        lv = [0.18 + 0.72 * math.sin(math.pi * f) * math.exp(-((i - c) ** 2) / (2 * (n / 3.5) ** 2))
              for i in range(n)]
        alpha, varying = hi * (1.0 - f * f), True
    elif name == "ERROR":
        f = _clamp(t / spec["duration"])
        lv = [0.15 + 0.65 * (0.5 + 0.5 * math.cos(2 * tau * f))] * n
        alpha, varying = hi * (1.0 - max(0.0, f - 0.7) / 0.3), True
    elif name == "INTERRUPTED":
        f = _clamp(t / spec["duration"])
        lv = [max(0.06, 0.45 * (1.0 - f))] * n
        alpha, varying = hi * (1.0 - f), True
    else:
        lv = [0.2] * n
    return lv, _clamp(alpha * H.HUD_OPACITY), varying


class WaveTheme(Theme):
    name = "wave"
    movable = True

    def __init__(self, host):
        Theme.__init__(self, host)
        s = self.s
        self.n = max(5, int(H.WAVE_BARS))
        self.pw, self.ph = H.WAVE_WIDTH * s, 46 * s
        self.Wn = int(self.pw + 24 * s)
        self.Hn = int(self.ph + 62 * s)
        self.pl = (self.Wn - self.pw) / 2.0
        self.pt = self.Hn - self.ph - 6 * s
        self.pcy = self.pt + self.ph / 2.0
        self.bar_w = max(2.0, 3.2 * s)
        pitch = 9.5 * s
        self.bar_right = self.pl + self.pw - 26 * s
        self.bar_left = self.bar_right - (self.n - 1) * pitch
        self.pitch = pitch
        self.max_h, self.min_h = self.ph * 0.64, 3.2 * s
        self.text_x = self.pl + 22 * s
        self.text_max = (self.bar_left - 16 * s) - self.text_x
        self.fb = self.font(10, weight="bold")
        self.fs = self.font(12)
        self.fh = self.font(11, slant="italic")
        self._col = H.COLORS["STANDBY"]
        self._hs = [None] * self.n
        self._cq = [None] * self.n

    # ---- window / position -------------------------------------------
    def window_rect(self):
        x, y = self.initial_pos()
        return x, y, self.Wn, self.Hn

    def anchor(self):
        return (self.Wn / 2.0, self.pcy, 24 * self.s)

    def pos_file(self):
        return os.path.join(os.path.dirname(H._POS_FILE), "hud_position_wave.json")

    def default_pos(self):
        l, t, r, b = self.h.work_area()
        return (l + (r - l - self.Wn) / 2.0, b - self.Hn - H.WAVE_MARGIN_BOTTOM * self.s + 6 * self.s)

    def pos_to_data(self, x, y):
        dx, dy = self.default_pos()
        return {"dx": round((x - dx) / self.s, 1), "dy": round((y - dy) / self.s, 1)}

    def pos_from_data(self, d):
        dx, dy = self.default_pos()
        return (dx + float(d["dx"]) * self.s, dy + float(d["dy"]) * self.s)

    # ---- items ---------------------------------------------------------
    def build(self):
        cv, s = self.cv, self.s

        def oval(tags, fill):
            return cv.create_oval(0, 0, 1, 1, fill=fill, outline="", tags=tags, state="hidden")

        def rect(tags, fill):
            return cv.create_rectangle(0, 0, 1, 1, fill=fill, outline="", tags=tags, state="hidden")

        r = self.ph / 2.0
        ri = r - max(1.0, 1.2 * s)
        left, right = self.pl, self.pl + self.pw
        for rad, fill, tags in ((r, KEY, ("pill", "pillb")), (ri, H.PANEL_BG, ("pill",))):
            o1, o2, rc = oval(tags, fill), oval(tags, fill), rect(tags, fill)
            cv.coords(o1, left + r - rad, self.pcy - rad, left + r + rad, self.pcy + rad)
            cv.coords(o2, right - r - rad, self.pcy - rad, right - r + rad, self.pcy + rad)
            cv.coords(rc, left + r, self.pcy - rad, right - r, self.pcy + rad)
        self._sheen = cv.create_line(left + r * 0.9, self.pt + 3.2 * s, right - r * 0.9, self.pt + 3.2 * s,
                                     width=max(1.0, s), fill=_mix(H.PANEL_BG, WHITE, 0.09),
                                     capstyle="round", tags=("pill",), state="hidden")
        self._bars = [cv.create_line(self.bar_left + i * self.pitch, self.pcy - self.min_h / 2,
                                     self.bar_left + i * self.pitch, self.pcy + self.min_h / 2,
                                     width=self.bar_w, capstyle="round", fill=KEY,
                                     tags=("bars",), state="hidden") for i in range(self.n)]
        self._text = cv.create_text(self.text_x, self.pcy, text="", anchor="w", font=self.fs,
                                    fill=H.TEXT_COLOR, tags=("txt",), state="hidden")
        cx, w = self.Wn / 2.0, 14 * s
        self._idle = cv.create_line(cx - w, self.pcy, cx + w, self.pcy, width=max(2.0, 2 * s),
                                    capstyle="round", fill=KEY, tags=("idle",), state="hidden")
        self._heard = _Stadium(cv, self.fh, s, "heard")
        self.show_state("STANDBY", H.STATES["STANDBY"], None, 0.0)

    def _recolor(self, col):
        self._col = col
        self.cv.itemconfigure("pillb", fill=_mix(H.PANEL_BG, col, 0.32))
        self.cv.itemconfigure(self._idle, fill=_dim(H.COLORS["STANDBY"], 0.8))
        self._heard.recolor(col)
        self._cq = [None] * self.n

    def _bar_color(self, level):
        col = self._col
        return _mix(_dim(col, 0.55), _mix(col, WHITE, 0.35), _clamp(level))

    # ---- state / text ----------------------------------------------------
    def show_state(self, name, spec, text, now):
        if name == "STANDBY":
            self.cv.itemconfigure(self._idle, fill=_dim(H.COLORS["STANDBY"], 0.8))
            self._go_standby(now)
            return
        self._active, self._tw = True, None
        self._recolor(H.COLORS[name])
        self._vis("pill", True)
        self._vis("bars", True)
        self._vis("idle", False)
        self._hs = [None] * self.n
        lv, alpha, varying = wave_levels(name, spec, 0.0, self.n)
        self._draw_bars(lv)
        self._enter_alpha(alpha, varying, now)
        self.set_message(text, now)
        self.h.raise_topmost()

    def _enter_standby(self, now):
        self._active = False
        for tag in ("pill", "bars", "txt"):
            self._vis(tag, False)
        self._vis("idle", True)
        self._settle_standby_alpha(now)

    def set_message(self, text, now):
        if not self._active:
            return
        cv = self.cv
        if text and H.STATUS_TEXT_ENABLED:
            cv.itemconfigure(self._text, text=_fit(self.fs, text, self.text_max), font=self.fs,
                             fill=H.TEXT_COLOR, state="normal")
        elif H.MINI_INDICATOR_ENABLED:
            cv.itemconfigure(self._text, text="JARVIS", font=self.fb,
                             fill=_mix(self._col, WHITE, 0.30), state="normal")
        else:
            cv.itemconfigure(self._text, state="hidden")

    def show_heard(self, text, now):
        if not (self._active and H.HEARD_TEXT_ENABLED):
            return
        shown = _heard_text(text)
        if shown:
            bh = self._heard.place(shown, self.Wn / 2.0, self.pt - self._heard_h() - 10 * self.s,
                                   self.Wn - 16 * self.s)

    def _heard_h(self):
        return self.fh.metrics("linespace") + 10 * self.s

    def hide_heard(self):
        self._heard.hide()

    # ---- per-frame work --------------------------------------------------
    def _draw_bars(self, lv):
        cv, cy = self.cv, self.pcy
        for i, v in enumerate(lv):
            h = self.min_h + (self.max_h - self.min_h) * _clamp(v)
            hq = int(h)
            if hq != self._hs[i]:
                self._hs[i] = hq
                x = self.bar_left + i * self.pitch
                cv.coords(self._bars[i], x, cy - hq / 2.0, x, cy + hq / 2.0)
            cq = round(_clamp(v) * 10)
            if cq != self._cq[i]:
                self._cq[i] = cq
                cv.itemconfigure(self._bars[i], fill=self._bar_color(cq / 10.0))

    def frame(self, spec, t, now):
        self._step_alpha(now)
        if spec["kind"] == "static" or not self._active:
            return
        lv, alpha, varying = wave_levels(spec["name"], spec, t, self.n)
        if varying:
            self._set_alpha(alpha)
        self._draw_bars(lv)


# =====================================================================
# THEME 3: NONE   (invisible: draws nothing)
# =====================================================================
class NoneTheme(Theme):
    """Shows nothing at all: a 1-pixel, fully transparent, click-through window.
    Jarvis keeps working exactly as before; there is just no animation."""
    name = "none"
    movable = False

    def window_rect(self):
        return 0, 0, 1, 1

    def build(self):
        self.h.set_window_alpha(0.02)

    def show_state(self, name, spec, text, now):
        pass

    def fps(self, spec):
        return 1.0                      # nothing to draw: keep wake-ups to a minimum

    def busy(self):
        return False


THEMES = {"orb": OrbTheme, "wave": WaveTheme, "none": NoneTheme}
